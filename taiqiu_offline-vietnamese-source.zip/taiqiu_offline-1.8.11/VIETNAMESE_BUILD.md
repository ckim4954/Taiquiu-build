# Bản Việt hoá – Bi-a Offline

Bản chỉnh sửa này đặt tiếng Việt làm ngôn ngữ duy nhất và tự chọn tiếng Việt khi khởi động. Các phần đã Việt hoá gồm tên chế độ, hướng dẫn luật 9 bi/8 bi/Snooker/Carom 3 băng, cài đặt chính, thao tác, bảng điểm, thông báo phạm lỗi và nhãn ứng dụng Android.

## Biên dịch APK

Yêu cầu Node.js/npm, JDK 17 và Android SDK có `platforms/android-34` cùng `build-tools/34.0.0`.

```bash
cd billiards-cn
npm ci
npm run build
cd ../billiards-apk
export ANDROID_SDK=/duong/dan/toi/android-sdk
./build-apk.sh
```

APK được tạo trong thư mục `billiards-apk/`, tên bắt đầu bằng `billiards-vi-`. Bản dựng cần được cài thử trên thiết bị Android để kiểm tra hiển thị tiếng Việt, dấu và bố cục trước khi phát hành.

## Ghi chú

Dự án gốc dùng giấy phép GPL-3.0; vui lòng giữ lại giấy phép và thông tin bản quyền khi phân phối bản sửa đổi.
