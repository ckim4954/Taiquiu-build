import { Vector3 } from "three"
import { Container } from "../../container/container"
import { Aim } from "../../controller/aim"
import { Controller } from "../../controller/controller"
import { PlaceBall } from "../../controller/placeball"
import { WatchAim } from "../../controller/watchaim"
import { PlaceBallEvent } from "../../events/placeballevent"
import { RerackEvent } from "../../events/rerackevent"
import { WatchEvent } from "../../events/watchevent"
import { Ball } from "../../model/ball"
import { Outcome, OutcomeType } from "../../model/outcome"
import { Table } from "../../model/table"
import { Rack } from "../../utils/rack"
import { Rules } from "./rules"
import { R } from "../../model/physics/constants"
import { Respot } from "../../utils/respot"
import { TableGeometry } from "../../view/tablegeometry"
import { TableConfig } from "../../view/tableconfig"
import { StartAimEvent } from "../../events/startaimevent"
import { MatchResultHelper } from "../../network/client/matchresult"
import { Session } from "../../network/client/session"
import { isFirstShot } from "../../utils/utils"
import { roundVec } from "../../utils/three-utils"
import { t, foulReason } from "../../utils/i18n"
import { respotOffTable, OFF_TABLE_FOUL } from "../../utils/offtable"

export class NineBall implements Rules {
  readonly container: Container

  cueball: Ball
  currentBreak = 0
  previousBreak = 0
  rulename = "nineball"

  constructor(container: Container) {
    this.container = container
  }

  startTurn(): void {
    this.previousBreak = this.currentBreak
    this.currentBreak = 0
  }

  nextCandidateBall(_p1type?: number): Ball | undefined {
    return this.container.table.balls
      .filter((b) => b !== this.cueball && b.onTable())
      .sort((a, b) => (a.label || 0) - (b.label || 0))[0]
  }

  placeBall(target?: Vector3): Vector3 {
    const baulkline = (-R * 11) / 0.5
    if (target) {
      const max = new Vector3(TableGeometry.tableX, TableGeometry.tableY)
      const min = new Vector3(-TableGeometry.tableX, -TableGeometry.tableY)
      if (isFirstShot(this.container.recorder)) {
        max.setX(baulkline)
        min.setX(baulkline)
      }
      return target.clone().clamp(min, max)
    }
    return new Vector3(baulkline, 0, 0)
  }

  readonly asset = "models/p8.min.gltf"

  tableGeometry(): void {
    TableConfig.apply(
      this.rulename,
      TableConfig.tableSizeFromUrl(this.rulename)
    )
  }

  table(): Table {
    const table = new Table(this.rack())
    this.cueball = table.cueball
    return table
  }

  rack(): Ball[] {
    return Rack.fromInitParam(Rack.diamond())
  }

  update(outcome: Outcome[]): Controller {
    const reason = NineBall.foulReason(this.container.table, outcome)

    if (reason) {
      return this.handleFoul(outcome, reason)
    }

    if (Outcome.potCount(outcome) > 0) {
      return this.handlePot(outcome)
    }

    return this.handleMiss()
  }

  private handleFoul(outcome: Outcome[], reason: string): Controller {
    this.container.notify({
      type: "Foul",
      title: t("foul"),
      subtext: foulReason(reason),
      extra: t("ballInHand"),
    })
    this.startTurn()
    const pots = Outcome.pots(outcome)
    const nineBallPotted = pots.includes(this.container.table.balls[9])
    const cueball = this.container.table.cueball

    // v1.3.18：犯规时若同帧打进合法球（非母球、非九号），仍计入我方累计比分。
    // 修复「进球同时白球（母球）也进了，进球数未递增」bug。
    // 九号球已在 respotAndBroadcastNineBall 中处理（重新摆回桌面，不算分）。
    const nineBall = this.container.table.balls[9]
    const foulScoredPots = pots.filter((b) => b !== cueball && b !== nineBall)
    if (foulScoredPots.length > 0) {
      const session = Session.getInstance()
      session.addMyScore(foulScoredPots.length)
      const { p1: s1, p2: s2 } = session.orderedScoresForHud()
      this.container.sendScoreUpdate(s1, s2, this.currentBreak)
    }

    if (nineBallPotted) {
      this.respotAndBroadcastNineBall(outcome)
    }

    // v1.3.95：出界的母球虽已被夹回台面内侧，但它不等于「仍在台上」
    const startPos =
      cueball.onTable() && !cueball.offTable
        ? cueball.pos.clone()
        : this.placeBall()
    roundVec(startPos)
    const placeBallEvent = new PlaceBallEvent(startPos, undefined, true)
    this.container.sendEvent(placeBallEvent)

    if (this.container.isSinglePlayer) {
      return new PlaceBall(this.container, startPos)
    }
    return new WatchAim(this.container)
  }

  private handlePot(outcome: Outcome[]): Controller {
    const table = this.container.table
    const pots = Outcome.potCount(outcome)
    this.currentBreak += pots
    Session.getInstance().addMyScore(pots)

    // v1.3.59：删除进球后的 success 特效提示音（与落袋音叠加显得多余吵闹）
    // v1.3.57 注：走到这里的必然是玩家自己出的杆（电脑出杆不经 rules.update，
    // 见 boteventhandler.handleGameEnd 的注释）。落袋游戏只有一个母球，
    // table.cueball === balls[playerIndex] 在 playerIndex=0 时恒真，
    // 碰巧是正确结果——不要把电脑的胜负接到这个判定上。
    if (this.isEndOfGame(outcome)) {
      const session = Session.getInstance()
      const myCueBall = this.container.table.balls[session.playerIndex]
      const amIWinner = this.container.table.cueball === myCueBall
      return this.handleGameEnd(amIWinner)
    }

    this.container.sendEvent(new WatchEvent(table.serialise()))
    return new Aim(this.container)
  }

  handleGameEnd(isWinner: boolean, endSubtext?: string): Controller {
    return MatchResultHelper.presentGameEnd(
      this.container,
      this.rulename,
      isWinner,
      endSubtext
    )
  }

  private handleMiss(): Controller {
    const table = this.container.table
    // if no pot and no foul switch to other player
    this.container.sendEvent(new StartAimEvent())
    if (this.container.isSinglePlayer) {
      this.container.sendEvent(new WatchEvent(table.serialise()))
      this.startTurn()
      return new Aim(this.container)
    }
    return new WatchAim(this.container)
  }

  isPartOfBreak(outcome: Outcome[]): boolean {
    return Outcome.isBallPottedNoFoul(this.container.table.cueball, outcome)
  }

  isEndOfGame(outcome: Outcome[]): boolean {
    const nineBall = this.container.table.balls[9]
    const nineBallPotted = Outcome.pots(outcome).includes(nineBall)
    return nineBallPotted && !this.isFoul(outcome)
  }

  otherPlayersCueBall(): Ball {
    // only for three cushion
    return this.cueball
  }

  secondToPlay(): void {
    // only for three cushion
  }

  allowsPlaceBall(): boolean {
    return true
  }

  protected isFoul(outcome: Outcome[]): boolean {
    return NineBall.foulReason(this.container.table, outcome) !== null
  }

  foulReason(outcome: Outcome[]): string | null {
    return NineBall.foulReason(this.container.table, outcome)
  }

  getAmountScored(outcome: Outcome[]): number {
    return Outcome.potCount(outcome)
  }

  respot(outcome: Outcome[]): Ball[] {
    // v1.3.95：先把本杆出界的球放回原处（含九号球被打出界的情况）
    const moved = respotOffTable(this.container.table, outcome)
    const nineBall = this.container.table.balls[9]
    if (nineBall && Outcome.pots(outcome).includes(nineBall)) {
      Respot.nineBall(this.container.table)
      return [nineBall]
    }
    return moved
  }

  public static foulReason(table: Table, outcome: Outcome[]): string | null {
    const cueball = table.cueball

    // v1.3.95：跳台犯规（球飞出台面）—— 优先级最高
    if (Outcome.offTableBalls(outcome).length > 0) {
      return OFF_TABLE_FOUL
    }

    // 1. Cue ball potted
    if (Outcome.isCueBallPotted(cueball, outcome)) {
      return "母球落袋"
    }

    // 2. Wrong ball hit first
    const lowestBall = NineBall.getLowestBallAtStartOfShot(table, outcome)
    const firstCollision = Outcome.firstCollision(
      Outcome.cueBallFirst(cueball, outcome)
    )

    if (!firstCollision) {
      return "空杆，未击中任何球"
    }

    if (firstCollision.ballB !== lowestBall) {
      if (Session.isPracticeMode()) {
        if (
          firstCollision.ballB === table.balls[9] &&
          NineBall.hasOtherObjectBalls(table)
        ) {
          return "未先击中最小号球"
        }
      } else {
        return "未先击中最小号球"
      }
    }

    // 3. No cushion after contact
    if (Outcome.potCount(outcome) === 0) {
      // Find cushions after first collision
      const firstCollisionIndex = outcome.indexOf(firstCollision)
      const cushionsAfter = outcome
        .slice(firstCollisionIndex + 1)
        .some((o) => o.type === OutcomeType.Cushion)
      if (!cushionsAfter) {
        return "击球后无球碰库"
      }
    }

    return null
  }

  public static getLowestBallAtStartOfShot(
    table: Table,
    outcome: Outcome[]
  ): Ball | undefined {
    const potted = Outcome.pots(outcome)
    const onTable = table.balls.filter(
      (b) => b !== table.cueball && b.onTable()
    )
    const all = [...potted, ...onTable]
    all.sort((a, b) => (a.label || 0) - (b.label || 0))
    return all[0]
  }

  private static hasOtherObjectBalls(table: Table): boolean {
    return table.balls.some(
      (b) => b !== table.cueball && b !== table.balls[9] && b.onTable()
    )
  }

  private respotAndBroadcastNineBall(outcome: Outcome[]) {
    const respotted = this.respot(outcome)
    const nineBall = respotted[0]
    if (nineBall) {
      nineBall.fround()
      const respotEvent = RerackEvent.fromJson({
        balls: [nineBall.serialise()],
      })
      console.log("Respot nine ball sending rerack event", respotEvent)
      this.container.sendEvent(respotEvent)
    }
  }
}
