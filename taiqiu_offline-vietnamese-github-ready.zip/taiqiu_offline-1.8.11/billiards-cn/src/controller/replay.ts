import { HitEvent } from "../events/hitevent"
import { Vector3 } from "three"
import { ControllerBase } from "./controllerbase"
import { AimEvent } from "../events/aimevent"
import { AbortEvent, Controller, Input } from "./controller"
import { BreakEvent } from "../events/breakevent"
import { Aim } from "./aim"
import { GameEvent } from "../events/gameevent"
import { EventType } from "../events/eventtype"
import { RerackEvent } from "../events/rerackevent"
import { PlaceBallEvent } from "../events/placeballevent"
import { End } from "./end"
import { ScoreEvent } from "../events/scoreevent"
import { StationaryEvent } from "../events/stationaryevent"
import { ChatEvent } from "../events/chatevent"
import { share, shorten } from "../utils/shorten"
import { unitAtAngle } from "../utils/three-utils"
import { R } from "../model/physics/constants"
import { PocketGeometry } from "../view/pocketgeometry"
import { LOBBY_URL } from "../network/client/constants"
import { Table } from "../model/table"
import { OutcomeType } from "../model/outcome"
import { State } from "../model/ball"

interface PotInfo {
  /** 相对本杆起点的进球时间戳（ms） */
  t: number
  /** 进袋球在 balls 数组中的下标 */
  ballId: number
  /** 对应袋口在 PocketGeometry.pocketCenters 中的下标 */
  pocketIdx: number
  /**
   * v1.5.4（#70）：本杆归属 —— "player" 玩家 / "ai" 电脑。
   * 进度条上的进球吸附点按此分色（玩家蓝、AI 红），
   * 让用户一眼看出「这一杆是谁进的球」。
   */
  owner: "player" | "ai"
}

interface ShotMeta {
  /** 本杆开始前的完整球局布局快照（位置 / 状态 / 所属球袋索引） */
  layout: { pos: [number, number, number]; state: State; pocket: number }[]
  /**
   * 本杆白球在 balls 数组中的下标。
   * v1.3.59：这里**必须是下标而不是 ball.id**。ball.id 是全局自增的唯一编号，
   * rules.table() 新建出来的桌子 id 是 48~63 这种，与下标 0~15 完全对不上。
   * 字段原本就注释成「下标」，但两处赋值写的都是 .id，属于注释与实现不符。
   */
  cueballIdx: number
  /** 本杆瞄准事件（用于确定性重跑） */
  aim: AimEvent
  /** 头less 预演得到的本杆物理时长（ms） */
  duration: number
  /**
   * v1.2.9 #F3：本杆「最后碰撞/进袋时间戳 + 提前量」。物理时间越过它即进入倍速。
   * 无碰撞且无进袋时为 Infinity（整杆常速，便于看清走位/失误）。
   */
  triggerT: number | null
  /** 本杆各进袋事件（含球与袋口索引），供进度条吸附点与每进球跟踪镜头使用 */
  pots: PotInfo[]
  /** 本杆默认三点框定（白球 / 被击球 / 对应球袋），无进球或跟踪窗口外时使用 */
  defaultFocus: Vector3[]
  /**
   * v1.3.60：本杆白球实际运动轨迹的采样点（预演时顺手记录）。
   *
   * 之前的俯视框定只用「白球 → 被击球 → 袋口」三点包围圆，半径常常只有
   * 一两个 R，而白球撞完目标球后的走位往往横穿半张台——镜头锁死在三点上，
   * 白球后半程直接滚出画面，用户看到的就是「看不到白球轨迹」。
   * 这里记录真实轨迹，供 seek / 回顾时参考（v1.5.4 起跟随视角已移除，
   * cueTrack 仅保留在 shotMeta 里备查，不再驱动相机）。
   */
  cueTrack?: [number, number, number][]
  /**
   * v1.5.4（#70）：本杆归属 —— "player" 玩家（保存者本人）/"ai" 对手（电脑）。
   * 来源是录制时 Recorder 打的 ow 标记（本地 sendEvent=1 缺省，对手 eventQueue=2），
   * 进度条进球点按它分色。旧回放数据无 ow，一律视为玩家杆。
   */
  owner: "player" | "ai"
}

/**
* v1.3.93：把本杆白球轨迹采样点并入框定点集。
*
* 轨迹点按 weight 向「三点质心」收缩后再并入 —— 相当于给轨迹打了折扣的
* 取景权重，既保证白球走位不滚出画面，又不会让长台走位把镜头拉到俯视感。
*
* 采样点可能很多（预演时按固定间隔记录），这里做等距抽稀，避免把
* buildReplayAnchor 的包围圆计算和相机插值无谓地拖慢。
*
* 独立成模块级函数（而非类静态私有方法）是为了能在 harness 里直接单测。
*/
export function expandFocusWithTrack(
  base: Vector3[],
  track?: [number, number, number][]
): Vector3[] {
  if (!track || track.length === 0) return base
  // 质心（只用基础三点，作为收缩基准，避免被轨迹自身带偏）
  let cx = 0
  let cy = 0
  for (const p of base) {
    cx += p.x
    cy += p.y
  }
  cx /= base.length
  cy /= base.length
  const WEIGHT = 0.55
  // 抽稀：最多取 8 个轨迹点，均匀分布
  const step = Math.max(1, Math.ceil(track.length / 8))
  const out = base.slice()
  for (let i = 0; i < track.length; i += step) {
    const t = track[i]
    // 已与某基础点几乎重合的轨迹点无信息量，跳过
    let dup = false
    for (const p of base) {
      if (Math.hypot(p.x - t[0], p.y - t[1]) < R * 0.5) {
        dup = true
        break
      }
    }
    if (dup) continue
    out.push(
      new Vector3(
        cx + (t[0] - cx) * WEIGHT,
        cy + (t[1] - cy) * WEIGHT,
        0
      )
    )
  }
  return out
}


export class Replay extends ControllerBase {
  override get name() {
    return "Replay"
  }
  delay: number
  shots: GameEvent[]
  firstShot: GameEvent
  currentActive: 0 | 1 | 2 = 1
  timer
  init
  diagram?

  /**
   * v1.2.6 #232：回放「运动中提速」倍率（已弃用）。
   * 用户要求回放从击球到进球期间不倍速、不切换视角，故取消自动提速。
   * 倍速改由用户通过底部「倍速」按钮手动选择（见 replaySpeed）。
   */
  private static readonly REPLAY_FAST = 3

  /**
   * v1.2.9 #F3：最后一颗球碰撞 / 最后一次进袋之后，再留出这段提前量（ms）才进入
   * 倍速，让玩家看清最后一次碰撞/进袋的收尾，再快进余下「滚定」过程。
   * v1.2.17：仅用于进度条吸附点定位，不再驱动自动倍速。
   */
  private static readonly REPLAY_LEAD_MS = 80

  /**
   * v1.5.6（#81）：判定「拖到了进度条尽头」的阈值。
   * 取 0.999 而非 1.0 —— 进度条是 0~1000 的整数刻度，拖到最右端时
   * `seekEl.value` 未必恰好 1000（实测常停在 998/999），留一格余量。
   */
  private static readonly SEEK_END_FRAC = 0.999

  /**
   * v1.5.6（#81）：进度条吸附阈值（进度条比例）。松手位置与某个进球时刻的
   * 距离小于它，就吸附到该进球时刻。末端豁免判据 `1 - SEEK_SNAP_FRAC` 也用
   * 它，两处必须同源，否则会出现「刚豁免完又被吸附」的边界抖动。
   */
  private static readonly SEEK_SNAP_FRAC = 0.025

  /**
   * v1.2.17：回放全局倍速档位（用户手动选择）。
   * 取值为 1 表示常速；击球→进球的真实时间间隔不被压缩、也不被拉长。
   */
  private static readonly REPLAY_SPEEDS = [0.5, 1, 2, 4]
  private replaySpeedIndex = 1 // 默认 1x

  /**
   * v1.8.4：回放里球杆的横向放大倍数。
   *
   * 全桌斜视下每米约 150px，真实杆径 4~13mm 只有 0.6~2px，等于没有。
   * 2.6 倍后 1.5~5px，能看清是一根杆又不至于胖成棍子（实拍对比 1x/3x/4x 后取值）。
   */
  private static readonly CUE_THICK = 2.6

  // ---- v1.2.9 #F3 / #F5 状态 ----
  /** 每杆起始快照 + 预演结果（triggerT / duration / pots） */
  private shotMeta: ShotMeta[] = []
  /** 当前正在播放（或正在被拖动）的杆在 shotMeta 中的下标 */
  private currentShotIndex = -1
  /**
   * v1.5.4（#70）：本杆归属。playNextShot 从原始杆 JSON 的 ow 标记读取
   * （Recorder 录制时打的：本地玩家缺省、对手=2），供逐杆兜底记账时
   * 写入 ShotMeta.owner（整局预计算失败时的降级路径）。
   */
  private pendingOwner: "player" | "ai" = "player"
  /** 头less 预演用的独立 Table 实例（每杆复用，避免扰动实时画面） */
  private simTable: Table | null = null
  /**
   * v1.3.59：原始全量事件副本。
   * this.shots 会被 playNextShot() 用 shift() 逐步消费，一旦拖动进度条跨杆跳转，
   * 队列就与实际播放位置失配（往回拖跳杆、往前拖重播），比分 HUD 也跟着错。
   * 这里留一份不可变的原始序列，供 seekToFraction() 重建队列。
   */
  private allShots: GameEvent[] = []
  /**
   * v1.3.59：shotEventOffsets[k] = 第 k 杆（shotMeta 下标）的 AimEvent 在 allShots
   * 中的下标。一「杆」在事件流里可能占多个条目（Aim 之后还可能跟 SCORE，之前可能
   * 有 PLACEBALL / RERACK），所以不能直接拿 k 当数组下标。
   */
  private shotEventOffsets: number[] = []
  /** 用户正在拖动进度条（拖动期间冻结物理，避免与重跑冲突） */
  private userScrubbing = false
  /** 进度条与吸附点容器 */
  private seekEl: HTMLInputElement | null = null
  private snapsEl: HTMLElement | null = null
  /** 「退出回放」按钮（回放结束常驻） */
  private exitBtn: HTMLButtonElement | null = null
  private exitHandler = () => {
    document.body.classList.remove("replay-mode")
    globalThis.location.href = LOBBY_URL
  }
  /**
   * v1.3.75：用户手动暂停（与拖动进度条的临时冻结 `userScrubbing` 分开）。
   * 放在实例字段而不是直接改 `container.replayPaused`，是因为拖动进度条结束时
   * 会把 `replayPaused` 复位成 false —— 那样用户按的暂停会被一次拖动无意取消掉。
   */
  private userPaused = false
  /**
   * v1.5.8（#90）：整局播完的终局跳转只做一次。
   * handleStationary 在「帧首已静止」的判定下可能被再次触发，不设闸会反复
   * 重跑末杆（画面不变但白耗一次完整物理重跑）。
   */
  private playFinished = false
  /** v1.3.75：「暂停 / 继续」按钮引用与点击处理 */
  private pauseBtn: HTMLButtonElement | null = null
  private onPauseClick = () => {
    this.userPaused = !this.userPaused
    this.applyPauseState()
    if (this.pauseBtn) {
      this.pauseBtn.textContent = this.userPaused ? "继续" : "暂停"
      this.pauseBtn.classList.toggle("paused", this.userPaused)
    }
  }
  /** v1.3.75：把「用户暂停 ∨ 拖动中」统一写回 container，并同步按钮外观 */
  private applyPauseState(): void {
    const frozen = this.userPaused || this.userScrubbing
    this.container.replayPaused = frozen
    if (this.pauseBtn) {
      this.pauseBtn.textContent = this.userPaused ? "继续" : "暂停"
      this.pauseBtn.classList.toggle("paused", this.userPaused)
    }
  }
  /** v1.2.17 #4：全局倍速按钮引用与点击处理（点击循环切换 0.5x/1x/2x/4x） */
  private speedBtn: HTMLButtonElement | null = null
  private onSpeedClick = () => {
    if (this.speedBtn) {
      this.speedBtn.textContent = this.cycleReplaySpeed()
    }
  }
  /**
   * v1.5.5（#76）：「俯视」按钮 —— 切回原有俯视视角。
   * 与 v1.5.4 之前的回放俯视完全同源（Camera.topView，整台俯视看原点）。
   * 按下后 mode=topView，每帧由相机自身驱动；用户再次拖动画面时
   * onFreePointerDown 会按需切回自由视角。
   */
  private topBtn: HTMLButtonElement | null = null
  private onTopBtnClick = () => {
    const cam = this.container.view.camera
    // v1.8.4：从「一键回俯视」改成 far ⇄ top 两态切换 —— 默认已经是斜视，
    // 按钮要能把用户送回纯俯视，再点一次回到能看到球杆的斜视。
    const toTop = cam.mode !== cam.topView
    cam.forceMode(toTop ? cam.topView : cam.farView)
    if (this.topBtn) this.topBtn.textContent = toTop ? "全桌" : "俯视"
  }
  /**
   * v1.5.4（#70）：回放**自由视角**。
   *
   * 需求：删除原「跟随 / 俯视」二选一（跟随视角每杆自动框定机位，用户无法控制），
   * 改为用户可以任意转动/缩放的自定义机位，且必须始终对着球台。
   *
   * 实现（几何见 Camera.freeCam / replayFreeView）：
   *   - 单指拖动 → 绕球台中心转动方位角 / 俯仰角（orbitFreeBy）；
   *   - 双指捏合 / 滚轮 → 拉近拉远（zoomFreeBy）；
   *   - 注视点恒为台面中心，因此**任何角度都对着球台**。
   * 指针在 canvas 上监听，按下即按需切换相机到 free 模式。
   */
  private freeCamBound = false
  private freeCamPointers = new Map<number, { x: number; y: number }>()
  private freeCamPinchDist = 0
  private onFreePointerDown = (e: PointerEvent) => {
    const cam = this.container.view.camera
    if (cam.mode !== cam.replayFreeView) cam.forceFreeView()
    this.freeCamPointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (this.freeCamPointers.size === 2) {
      const [a, b] = [...this.freeCamPointers.values()]
      this.freeCamPinchDist = Math.hypot(a.x - b.x, a.y - b.y)
    }
    // setPointerCapture 只对「活跃指针」合法；自动化测试/合成事件传入的
    // pointerId 不是活跃指针时会抛 NotFoundError，吞掉即可（不影响手势）。
    try {
      ;(e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId)
    } catch {
      /* 合成指针或指针已释放：忽略 */
    }
  }
  private onFreePointerMove = (e: PointerEvent) => {
    const prev = this.freeCamPointers.get(e.pointerId)
    if (!prev) return
    const cam = this.container.view.camera
    const dx = e.clientX - prev.x
    const dy = e.clientY - prev.y
    this.freeCamPointers.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (this.freeCamPointers.size >= 2) {
      // 双指捏合缩放
      const [a, b] = [...this.freeCamPointers.values()]
      const d = Math.hypot(a.x - b.x, a.y - b.y)
      if (this.freeCamPinchDist > 0 && d > 0) {
        cam.zoomFreeBy(this.freeCamPinchDist / d)
      }
      this.freeCamPinchDist = d
      return
    }
    // 单指拖动旋转
    cam.orbitFreeBy(dx, dy)
  }
  private onFreePointerUp = (e: PointerEvent) => {
    this.freeCamPointers.delete(e.pointerId)
    if (this.freeCamPointers.size < 2) this.freeCamPinchDist = 0
  }
  private onFreeWheel = (e: WheelEvent) => {
    const cam = this.container.view.camera
    if (cam.mode !== cam.replayFreeView) cam.forceFreeView()
    e.preventDefault()
    cam.zoomFreeBy(e.deltaY > 0 ? 1.08 : 1 / 1.08)
  }
  /** 绑定自由视角手势（进入回放时调用一次） */
  private setupReplayFreeCam() {
    if (this.freeCamBound) return
    const el = this.container.view.canvas
    const target: HTMLElement | undefined =
      el instanceof HTMLElement ? el : (document.querySelector("canvas") as HTMLElement | undefined)
    if (!target) return
    this.freeCamBound = true
    target.addEventListener("pointerdown", this.onFreePointerDown)
    target.addEventListener("pointermove", this.onFreePointerMove)
    target.addEventListener("pointerup", this.onFreePointerUp)
    target.addEventListener("pointercancel", this.onFreePointerUp)
    target.addEventListener("pointerleave", this.onFreePointerUp)
    target.addEventListener("wheel", this.onFreeWheel, { passive: false })
  }
  private teardownReplayFreeCam() {
    if (!this.freeCamBound) return
    const el = this.container.view.canvas
    const target: HTMLElement | undefined =
      el instanceof HTMLElement ? el : (document.querySelector("canvas") as HTMLElement | undefined)
    this.freeCamBound = false
    this.freeCamPointers.clear()
    if (!target) return
    target.removeEventListener("pointerdown", this.onFreePointerDown)
    target.removeEventListener("pointermove", this.onFreePointerMove)
    target.removeEventListener("pointerup", this.onFreePointerUp)
    target.removeEventListener("pointercancel", this.onFreePointerUp)
    target.removeEventListener("pointerleave", this.onFreePointerUp)
    target.removeEventListener("wheel", this.onFreeWheel)
  }
  /** 吸附点 DOM 缓存签名，避免每帧重建 */
  private lastSnapSig = ""
  constructor(container, init, shots, _retry = false, delay = 1500, diagram?) {
    super(container)
    // v1.2.13 #replay：一进入回放立刻隐藏底部栏，避免预计算/异常导致 onFirst 未执行时
    // 底部栏仍可见。后续 onFirst 会再次设置以作保险。
    document.body.classList.add("replay-mode")
    this.init = init
    this.diagram = diagram
    this.shots = Array.isArray(shots) ? [...shots] : []
    this.firstShot = this.shots[0]
    // v1.3.59：留一份不可变副本并建立「杆 → 事件下标」映射，供拖动进度条时重建队列
    this.allShots = [...this.shots]
    this.shotEventOffsets = this.buildShotOffsets()
    console.log(`[replay] init received, shots=${this.shots.length}`)
    console.log(`init: ${JSON.stringify(init)}`)
    this.delay = diagram ? 0 : delay
    // v1.2.6 #232：回放起步为正常速度（杆间停留/相机移动用正常速度）
    this.container.timeScale = 1
    this.container.table.showTraces(true)
    try {
      this.container.table.updateFromShortSerialised(this.init)
    } catch (e) {
      console.error("[replay] updateFromShortSerialised failed:", e)
    }
    // v1.5.5（#77）：进入回放把时间轴清零 —— 语义「新回放从 0 开始」。
    // 注：最初怀疑的「init 序列化残留陈旧 time」经实机挂钩证伪（hook 初始值
    // 恒为 0），真正的污染源是 idx=-1 空闲期 Container.animate 空转推进
    // time（见 tickSeekUI 内实锤③注释）；这里清零保留作为防御性兜底。
    this.container.table.time = 0
    console.log(`shots: ${this.shots.length}`)
    console.log(`shots: ${JSON.stringify(this.shots)}`)
    // v1.8.4：**默认改用全桌斜视（farView）**。
    //
    // 旧版按 v1.5.5 的要求默认俯视。但俯视是「正上方垂直看」，球杆是水平
    // 躺在桌面上的细圆柱（直径约 4mm）—— 393px 宽的竖屏下换算只有 1px 左右，
    // 而且杆身伸出画面边缘，用户看到的就是「回放没有球杆」。
    // 斜视能看到杆身、球桌腿与场景，也更像在看比赛；需要纯战术俯视时点
    // 「俯视」按钮即可切换（onTopBtnClick 现在是 far ⇄ top 两态循环）。
    // 图解 / 开伦仍固定俯视（战术示意不需要球杆与场景）。
    const keepTop = this.diagram || this.container.rules.rulename === "threecushion"
    this.container.view.camera.forceMode(
      keepTop
        ? this.container.view.camera.topView
        : this.container.view.camera.farView
    )
    if (!this.diagram && this.container.rules.rulename != "threecushion") {
      this.setupReplayFreeCam()
    }
    // v1.2.11 #user：进入回放前预跑完整局，填满 shotMeta，
    // 使整局进度条从开局即涵盖全部杆与进球（而非逐杆叠加）。
    if (!this.diagram) {
      try {
        this.precomputeAllShots()
      } catch (e) {
        console.error("[replay] precomputeAllShots failed, fallback to incremental:", e)
        this.shotMeta = []
        this.simTable = null
      }
    }
    try {
      this.playNextShot(this.delay * 1.5)
    } catch (e) {
      console.error("[replay] playNextShot failed:", e)
    }
  }

  override onFirst() {
    console.log("[replay] onFirst fired")
    this.container.table.cue.aimInputs.setDisabled(true)
    // v1.8.4：回放是远景观赏视角，球杆按真实直径只有不到 1px —— 视觉加粗，
    // 否则用户看到的就是「回放没有球杆」（见 Cue.setVisualBoost 注释）。
    try {
      this.container.table.cue.setVisualBoost(0.006, Replay.CUE_THICK)
    } catch (e) {
      /* 纯视觉补偿，失败忽略 */
    }
    const shareButton = this.container.menu.share
    if (shareButton) {
      shareButton.onclick = () => {
        shorten(globalThis.location.href, (url) => {
          const response = share(url)
          this.container.eventQueue.push(new ChatEvent(null, response))
        })
      }
    }
    // v1.2.9 #F5：挂载回放进度条（可滑动 + 进球吸附点）
    this.setupReplaySeek()
    // v1.2.11 #user：进入回放即隐藏底部操作栏，保持全屏
    document.body.classList.add("replay-mode")
    console.log("[replay] replay-mode class present:", document.body.classList.contains("replay-mode"))
  }

  private rerackShot(shot: GameEvent, delay: number): boolean {
    if (shot?.type !== EventType.RERACK) {
      return false
    }
    const rerack = RerackEvent.fromJson((shot as RerackEvent).ballinfo)
    RerackEvent.applyBallinfoToTable(this.container.table, rerack.ballinfo)
    if (this.shots.length > 0) {
      this.playNextShot(delay)
    }
    return true
  }

  private placeBallShot(shot: GameEvent, delay: number): boolean {
    if (shot?.type !== EventType.PLACEBALL) {
      return false
    }
    const place = PlaceBallEvent.fromJson(shot)
    this.container.table.cueball.pos.copy(place.pos)
    this.container.table.cueball.setStationary()
    if (place.respot) {
      const ball = this.container.table.balls[place.respot.id]
      if (ball) {
        ball.pos.copy(place.respot.pos)
        ball.setStationary()
      }
    }
    if (this.shots.length > 0) {
      this.playNextShot(delay)
    }
    return true
  }

  private scoreShot(shot: GameEvent, delay: number): boolean {
    if (shot?.type !== EventType.SCORE) {
      return false
    }
    const score = ScoreEvent.fromJson(shot)
    score.applyToController(this)
    if (score.active !== 0) {
      this.currentActive = score.active
    }
    if (this.shots.length > 0) {
      this.playNextShot(delay)
    }
    return true
  }

  playNextShot(delay) {
    const shot = this.shots.shift()
    if (!shot) {
      return
    }
    if (
      this.rerackShot(shot, delay) ||
      this.placeBallShot(shot, delay) ||
      this.scoreShot(shot, delay)
    ) {
      return
    }

    const aim = AimEvent.fromJson(shot)
    // v1.5.4（#70）：从原始杆 JSON 读取归属标记（Recorder 录制时打的 ow），
    // 供 beginShotBookkeeping 的逐杆兜底记账使用。
    this.pendingOwner = (shot as { ow?: number }).ow === 2 ? "ai" : "player"
    this.container.setHudActivePlayer(this.currentActive)
    this.container.table.cueball = this.container.table.balls[aim.i]

    this.container.table.cueball.pos.copy(aim.pos)
    this.container.table.cue.aim = aim
    this.container.updateLastShot()
    // v1.3.58：回放同样要走「出杆即收杆」，每杆重新播放前把球杆亮回来
    this.container.table.cue.aimMode()
    this.container.table.cue.updateAimInput()
    this.container.table.cue.t = 1
  // v1.5.4（#70）：自由视角下不再每杆自动框定机位 —— 相机由用户控制，
  // 只在首次进入回放时定位（见构造函数 forceFreeView + setupReplayFreeCam）。
  clearTimeout(this.timer)
    this.timer = setTimeout(() => {
      this.container.table.proximityIndicator.hide()
      this.container.eventQueue.push(
        new HitEvent(this.container.table.cue.aim.copy())
      )
      this.timer = undefined
    }, delay)
  }

  /**
   * v1.2.6 #232：根据当前这一杆的瞄准，算出回放框定需要的三点：
   *   [0] 白球（击球点）  [1] 被击球  [2] 对应进球的球袋。
   * - 被击球：从白球沿瞄准方向做射线，取第一个会被白球碰到的球（中心线距离 ≤ 2R）。
   * - 对应球袋：被击球大致沿「白球→被击球」中心线方向被推出，
   *   取该方向上夹角最小的球袋作为目标袋（直球/近直球精确，加塞切球为近似）。
   */
  private computeFocusPoints(aim: AimEvent, table: Table = this.container.table): Vector3[] {
    const cue = table.cueball
    const cuePos = cue.pos.clone()
    const dir = unitAtAngle(aim.angle) // XY 平面单位向量

    // 找被击球：射线 (cuePos + t*dir) 上第一个被白球碰到的球
    let best: any = null
    let bestT = Infinity
    for (const b of table.balls) {
      if (b === cue || !b.onTable()) continue
      const vx = b.pos.x - cuePos.x
      const vy = b.pos.y - cuePos.y
      const t = vx * dir.x + vy * dir.y
      if (t <= 0) continue
      const perp = Math.abs(vx * dir.y - vy * dir.x)
      if (perp > 2 * R * 1.02) continue // 白球中心线够不到此球
      if (t < bestT) {
        bestT = t
        best = b
      }
    }

    let struckPos: Vector3
    if (best) {
      struckPos = best.pos.clone()
    } else {
      // 未预判到被击球（罕见）：在瞄准前方放一个虚拟点，保证框定仍有效
      struckPos = cuePos.clone().addScaledVector(dir, 8 * R)
    }

    // 目标球袋：被击球沿「白球→被击球」方向被推出，取该方向上夹角最小的球袋
    const pocketDir = struckPos.clone().sub(cuePos)
    if (pocketDir.lengthSq() < 1e-6) pocketDir.copy(dir)
    pocketDir.normalize()
    // 注意：PocketGeometry.pocketCenters 元素是 Pocket 实例，坐标在 .pos
    let bestPocket: Vector3 = PocketGeometry.pocketCenters[0].pos.clone()
    let bestDot = -Infinity
    for (const p of PocketGeometry.pocketCenters) {
      const pd = p.pos.clone().sub(struckPos)
      if (pd.lengthSq() < 1e-6) continue
      pd.normalize()
      const d = pd.x * pocketDir.x + pd.y * pocketDir.y
      if (d > bestDot) {
        bestDot = d
        bestPocket = p.pos.clone()
      }
    }

    return [cuePos, struckPos, bestPocket]
  }

  /**
   * v1.2.9 #F3 / #F5：每杆起手记账。
   * - 隔离本杆 outcome（回放中原 outcome 跨杆累积，会导致「最后事件」时间戳判定错误）；
   * - 抓取本杆起始布局快照（用于拖动进度条时确定性重跑）；
   * - 头less 预演本杆，算出 triggerT / duration / pots。
   */
  private beginShotBookkeeping() {
    this.currentShotIndex++
    const t = this.container.table
    // 隔离本杆 outcome（每杆以干净数组开始）
    t.outcome.length = 0
    // 若整局已预计算，直接复用对应杆的预计算 meta（duration / pots / defaultFocus / triggerT 已就绪）
    const existing = this.shotMeta[this.currentShotIndex]
    if (existing) {
      return
    }
    // 兜底：未预计算时（如图解模式）现场计算并追加
    if (!this.simTable) {
      this.simTable = this.container.rules.table()
    }
    const meta: ShotMeta = {
      layout: t.balls.map((b) => ({
        pos: [b.pos.x, b.pos.y, b.pos.z] as [number, number, number],
        state: b.state,
        pocket: b.pocket ? PocketGeometry.pocketCenters.indexOf(b.pocket) : -1,
      })),
      cueballIdx: t.balls.indexOf(t.cueball),
      aim: t.cue.aim.copy(),
      duration: 0,
      triggerT: null,
      pots: [],
      defaultFocus: this.computeFocusPoints(t.cue.aim),
      owner: this.pendingOwner,
    }
    // v1.5.4（#70）：逐杆兜底记账同样要兜住 precomputeShot 的物理异常，
    // 否则 handleHit 会把异常抛进 animate 循环，本杆时长缺失导致回放卡死。
    try {
      this.precomputeShot(meta)
    } catch (e) {
      console.warn("[replay] incremental precompute failed, degrade to zero-duration:", (e as Error)?.message)
      meta.duration = Math.max(meta.duration, 1e-3)
    }
    this.shotMeta.push(meta)
  }

  /**
   * v1.2.9 #F3 / #F5：用独立 simTable 头less 重跑本杆，得到：
   * - duration：本杆物理时长（ms），供进度条满程与吸附点定位；
   * - triggerT：本杆「最后碰撞/进袋 + 提前量」，物理越过它才倍速（#F3）；
   * - pots：本杆所有进袋时间戳，供进度条吸附点（#F5）。
   */
  private precomputeShot(meta: ShotMeta) {
    const sim = this.simTable!
    meta.layout.forEach((s, i) => {
      const b = sim.balls[i]
      if (!b) return
      b.pos.set(s.pos[0], s.pos[1], s.pos[2])
      b.vel.set(0, 0, 0)
      b.rvel.set(0, 0, 0)
      b.state = s.state
      b.pocket = s.pocket >= 0 ? PocketGeometry.pocketCenters[s.pocket] : undefined
    })
    // v1.3.59：这里原为 sim.balls[meta.cueballId]，而 cueballId 存的是
    // ball.id —— rules.table() 新建的桌子 id 是 48~63，按下标取值恒为
    // undefined，紧接着 sim.hit() → Cue.hit(undefined) 抛
    // "Cannot set properties of undefined (setting 'state')"。
    // precomputeAllShots 捕获该异常后整局预计算作废（shotMeta 清空），
    // 进度条因此拿不到整局总时长，只能逐杆叠加。改为存下标后此处直接按下标取。
    sim.cueball = sim.balls[meta.cueballIdx]
    sim.cue.aim = meta.aim.copy()
    sim.time = 0
    sim.outcome.length = 0
    sim.hit()
    const step = this.container.step
    let guard = 0
    // v1.3.60：顺手采样白球轨迹，供俯视框定包住整条走位（见 ShotMeta.cueTrack）。
    // 采样下限 ~30 步一次：step 通常 1~2ms、整杆数百到数千步，30 步取一点既能
    // 覆盖轨迹弯折（撞库后方向剧变）又不至于点数爆炸。上限 400 点兜底。
    const track: [number, number, number][] = []
    const cueBall = sim.cueball
    const SAMPLE_EVERY = 30
    const MAX_TRACK_POINTS = 400
    // v1.5.4（#70）：预演物理对 `Depth exceeded resolving collisions` 容错。
    // 碰撞解算 100 层不收敛时 Table.advance 会 throw —— live 游戏靠 animate 的
    // 逐帧 try-catch 自恢复，而预演是固定步长循环，一次 throw 就会整杆报废，
    // 进度条整局预计算随之作废（表现为进度条退化成逐杆叠加、吸附点丢失）。
    // 这里捕获后按「已模拟到的时间/事件」收尾，本杆数据仍然可用。
    try {
      while (!sim.allStationary() && guard++ < 500000) {
        sim.advance(step)
        if (
          cueBall &&
          guard % SAMPLE_EVERY === 0 &&
          track.length < MAX_TRACK_POINTS &&
          cueBall.onTable()
        ) {
          track.push([cueBall.pos.x, cueBall.pos.y, cueBall.pos.z])
        }
      }
      if (cueBall && track.length < MAX_TRACK_POINTS) {
        track.push([cueBall.pos.x, cueBall.pos.y, cueBall.pos.z])
      }
    } catch {
      // 碰撞解算爆栈：以当前已产生的时间与事件收尾（duration/pots 部分有效）
      console.warn("[replay] precompute sim hit Depth-exceeded, settle with partial result")
    }
    meta.cueTrack = track
    let maxTs = -1
    const pots: PotInfo[] = []
    for (const o of sim.outcome) {
      if (o.type === OutcomeType.Collision || o.type === OutcomeType.Pot) {
        if (o.timestamp > maxTs) maxTs = o.timestamp
      }
      if (o.type === OutcomeType.Pot) {
        const ballId = o.ballA ? o.ballA.id : -1
        const pocketIdx = o.ballA?.pocket
          ? PocketGeometry.pocketCenters.indexOf(o.ballA.pocket)
          : -1
        pots.push({ t: o.timestamp, ballId, pocketIdx, owner: meta.owner })
      }
    }
    meta.duration = sim.time
    // 无碰撞且无进袋 → 整杆常速（便于看清走位/失误）；否则最后事件 + 提前量后倍速
    meta.triggerT = maxTs >= 0 ? maxTs + Replay.REPLAY_LEAD_MS : Infinity
    meta.pots = pots
  }

  /**
   * v1.2.11 #user：进入回放前用独立 simTable 顺序执行全部杆，
   * 预先生成每杆的 layout / aim / duration / triggerT / pots / defaultFocus，
   * 使 gameTotals() 在回放一开始就能给出整局总时长，进度条从开局覆盖到结束，
   * 而非原先「每杆播放后才追加一段」的逐杆叠加表现。
   */
  /**
   * v1.3.59：扫描原始事件序列，算出每一杆的 AimEvent 在 allShots 中的下标。
   *
   * 判定条件与 playNextShot() 逐字一致 —— 只有「不是 RERACK / PLACEBALL / SCORE」
   * 的事件才算一杆的起点（其余三种会被 playNextShot 递归消费掉）。这样无论
   * 整局预计算是否成功、是否图解模式，映射都成立。
   */
  private buildShotOffsets(): number[] {
    const offs: number[] = []
    this.allShots.forEach((e, i) => {
      const t = e?.type
      if (
        t !== EventType.RERACK &&
        t !== EventType.PLACEBALL &&
        t !== EventType.SCORE
      ) {
        offs.push(i)
      }
    })
    return offs
  }

  private precomputeAllShots() {
    this.simTable = this.container.rules.table()
    this.simTable.updateFromShortSerialised(this.init)
    const shots = [...this.shots]
    for (let i = 0; i < shots.length; i++) {
      const shot = shots[i]
      try {
        if (shot?.type === EventType.RERACK) {
          RerackEvent.applyBallinfoToTable(
            this.simTable,
            RerackEvent.fromJson((shot as RerackEvent).ballinfo).ballinfo
          )
          continue
        }
        if (shot?.type === EventType.PLACEBALL) {
          const place = PlaceBallEvent.fromJson(shot)
          this.simTable.cueball.pos.copy(place.pos)
          this.simTable.cueball.setStationary()
          if (place.respot) {
            const b = this.simTable.balls[place.respot.id]
            if (b) {
              b.pos.copy(place.respot.pos)
              b.setStationary()
            }
          }
          continue
        }
        if (shot?.type === EventType.SCORE) {
          // 计分事件不改变球位，预演布局无需处理
          continue
        }
        // AimEvent：抓取起始布局并预演本杆
        const aim = AimEvent.fromJson(shot)
        this.simTable.cueball = this.simTable.balls[aim.i]
        this.simTable.cueball.pos.copy(aim.pos)
        this.simTable.cue.aim = aim
        const meta: ShotMeta = {
          // v1.8.4：只有「真的在袋里（落袋中 / 已入袋）」才记录袋口。
          // Ball.pocket 是个一旦写入就不再清除的引用 —— 白球被摆回来继续打时
          // 它仍指着上一个袋，若照搬进 layout，回放里一颗台中央 Rolling 的球
          // 会被 restoreShotStart 标成「已落袋」（探针实测 18 杆里有 11 杆如此），
          // 任何按 pocket 判断可见性的代码都会误判。
          layout: this.simTable.balls.map((b) => ({
            pos: [b.pos.x, b.pos.y, b.pos.z] as [number, number, number],
            state: b.state,
            pocket:
              (b.state === State.InPocket || b.state === State.Falling) && b.pocket
                ? PocketGeometry.pocketCenters.indexOf(b.pocket)
                : -1,
          })),
          cueballIdx: this.simTable.balls.indexOf(this.simTable.cueball),
          aim: aim.copy(),
          duration: 0,
          triggerT: null,
          pots: [],
          defaultFocus: this.computeFocusPoints(aim, this.simTable),
          // v1.5.4（#70）：归属来自录制时 Recorder 打的 ow 标记（2=对手/AI）
          owner: (shot as { ow?: number }).ow === 2 ? "ai" : "player",
        }
        this.precomputeShot(meta)
        this.shotMeta.push(meta)
      } catch (e) {
        console.error(`[replay] precompute shot ${i} failed, abort incremental fallback:`, e)
        // 任一杆预计算失败即放弃整局预计算，改为逐杆现场计算（进度条会回到逐杆叠加，
        // 但回放本身仍可正常播放）。
        this.shotMeta = []
        this.simTable = null
        break
      }
    }
    console.log(`[replay] precomputeAllShots done, metaCount=${this.shotMeta.length}`)
  }

  /** 将实时 Table 还原到某杆起始布局（确定性重跑起点） */
  private restoreShotStart(meta: ShotMeta) {
    const t = this.container.table
    meta.layout.forEach((s, i) => {
      const b = t.balls[i]
      if (!b) return
      b.pos.set(s.pos[0], s.pos[1], s.pos[2])
      b.vel.set(0, 0, 0)
      b.rvel.set(0, 0, 0)
      b.state = s.state
      b.pocket = s.pocket >= 0 ? PocketGeometry.pocketCenters[s.pocket] : undefined
      // v1.8.4：这两个标记不在 layout 里，但直接影响渲染 —— 上一段拖动停在
      // 一颗球出界的时刻后，offTable=true 会让球在后续画面里一直隐身；
      // wasAirborne 残留会让球被当成腾空球处理。归零保证恢复干净。
      b.offTable = false
      b.wasAirborne = false
    })
    // v1.3.59：同 precomputeShot，改为按 balls 下标取母球。
    t.cueball = t.balls[meta.cueballIdx]
    t.cue.aim = meta.aim.copy()
    t.time = 0
    t.outcome.length = 0
  }

  /**
   * v1.3.59：把待播队列重建为「从第 idx 杆的 AimEvent 之后开始」。
   *
   * 事件流形如 Aim(k) → SCORE(k) → [PLACEBALL] → Aim(k+1)，而 seekToFraction
   * 已经用 container.table.hit() 消费掉了 Aim(k)，所以队列要从 off + 1 切起。
   * 拿不到映射时（如映射表为空）保持原样，避免把情况变得更糟。
   */
  private rebuildQueueFrom(idx: number) {
    const off = this.shotEventOffsets[idx]
    if (off === undefined) {
      return
    }
    this.shots = this.allShots.slice(off + 1)
    this.restoreScoreBefore(off)
  }

  /**
   * v1.3.59：把比分 HUD 回填到「第 idx 杆开打之前」的状态。
   *
   * 比分完全由事件流里的 SCORE 事件驱动（scoreShot → handleScore →
   * updateScoreHud），重建队列后那些已播过的 SCORE 不会再走一遍，
   * 所以必须手动补一次。
   *
   * 只应用最后一个 SCORE 即可：handleScore 本质是纯 setter，
   * 其另两处副作用 —— session.p1type 赋值（有 `session.p1type === 0` 守卫、
   * 且值黏滞）和三库/沙古终局检查（有 `!replayMode` 守卫）—— 都幂等且回放下不触发。
   *
   * v1.3.60：applyToController 走的是 Replay 的 handleScore（继承自 base，
   * 调 container.updateScoreHud）。但 updateScoreHud 内部还会改 session 的「我方 /
   * 对手」顺序，回放下 playerIndex 与对局时未必一致，导致 HUD 出现「数值对了但
   * 角色反了」的情况。这里再走一次显式同步：把 SCORE.p1/p2 视为「对局时的双方
   * 数值」，按 container.view.hud / Session 的 ordered* 接口压一次，确保 HUD
   * 的 p1Score/p2Score 显示**就是这一刻应有的比分**。
   */
  private restoreScoreBefore(off: number) {
    let last: GameEvent | null = null
    for (let i = 0; i < off; i++) {
      if (this.allShots[i]?.type === EventType.SCORE) {
        last = this.allShots[i]
      }
    }
    const score = last
      ? ScoreEvent.fromJson(last)
      : new ScoreEvent(0, 0, 0, 0)
    score.applyToController(this)
    if (score.active !== 0) {
      this.currentActive = score.active
    }
    // v1.3.60 防御性兜底：直接再调一次 updateScoreHud 与一次 setText，防止
    // 上面链路任意一处因为 recordReplayer 等原因吞掉了写入、而 HUD 上分值仍停在
    // 「拖动前那一刻」。这两步幂等（值不变就不变），不影响下一杆的分数累加。
    try {
      this.container.updateScoreHud(score.p1, score.p2, score.b, score.active)
    } catch (e) {
      /* 容错：HUD 写入失败不应阻塞 seekToFraction */
    }
    try {
      const hud = this.container.hud
      if (hud?.p1Element) hud.p1Element.textContent = String(score.p1)
      if (hud?.p2Element) hud.p2Element.textContent = String(score.p2)
    } catch (e) {
      /* 容错同上 */
    }
  }

  /**
   * v1.2.9 #F5：将回放跳转到本杆进度比例 frac（0..1）处。
   * v1.2.11 #F11：frac 现为整局进度比例。需先定位到对应杆 idx，
   * 再在该杆内确定性重跑到局部目标时刻。
   * 做法：还原本杆起始布局 → 重新击球 → 确定性重跑物理到目标时刻。
   */
  private seekToFraction(frac: number) {
    const { cum, total } = this.gameTotals()
    if (total <= 0) return
    // v1.5.8（#90）：用户拖到**非尽头**才解除终局跳转闸门（拖回中段后仍要能
    // 暂停/继续，且随后的自然播完要能再次跳终局）；拖到尽头时**保持**闸门 ——
    // 终局 seek 自己会把画面与时钟对齐到位，若此时重置闸门，终局 seek 的
    // hit() 一旦跨帧产生 StationaryEvent，handleStationary 会再跑一次终局
    // 分支 → 末杆物理被反复重跑，极端情况下形成自循环（DIAG3 实测定性）。
    // 暂停按钮的恢复与闸门解耦：任何拖动都恢复（播完时它被禁用）。
    if (frac < Replay.SEEK_END_FRAC) {
      this.playFinished = false
    }
    if (this.pauseBtn && this.pauseBtn.disabled) {
      this.pauseBtn.disabled = false
    }
    // v1.3.59：清 timer 必须放在这里，不能只放在 onSeekStart。
    // onSeekEnd 同时绑在 change 上（键盘方向键 / 程序触发只走 input + change，
    // 不经过 onSeekStart），不清 timer 的话，杆间 delay 的那个 timer 到期仍会
    // push HitEvent → beginShotBookkeeping 把 currentShotIndex 再 +1，
    // 与下面刚设好的 idx 错一位，后续 shotMeta 全部串位。
    clearTimeout(this.timer)
    this.timer = undefined
    // v1.3.60：拖动跨段会让 container.eventQueue 里残留下一次「静止」事件，
    // 而 processEvents 在「allStationary」成立时立即消费 StationaryEvent → 调度
    // 下一杆。一来一回的进度条拖动会让残留下一个 StationaryEvent 把刚回填好的
    // 时序吃掉、画面停在「拖到的那一刻」但马上又前进。这里把残留事件一次性清空，
    // 拖动结束后由 resumeAfterSeek 重新发 StationaryEvent（如果还需要的话）。
    if (this.container.eventQueue) {
      this.container.eventQueue.length = 0
    }
    const target = Math.max(0, Math.min(1, frac)) * total
    // 找到 target 落在哪一杆
    /**
     * v1.8.4：改为「取最后一个起点不晚于 target 的杆」。
     *
     * 旧写法是 `target <= cum[i] + duration[i]` —— 当 target 与某杆起点
     * 只差零点几毫秒（拖动/取整的常态）时，会命中**上一杆**的末尾分支，
     * 于是画面停在上一杆打完的位置，而其中往往夹着摆球 / 重摆事件，
     * 球位和「该杆起点」相差一米以上。用户看到的就是「拖到这一段，
     * 结果是另一局的画面」。现在把杆首边界归给后一杆，并留 0.5ms 容差。
     */
    let idx = 0
    for (let i = 0; i < this.shotMeta.length; i++) {
      if (target + 0.5 >= cum[i]) {
        idx = i
      } else {
        break
      }
    }
    const meta = this.shotMeta[idx]
    if (!meta) return
    // v1.3.59：跨杆跳转时重建剩余事件队列 + 回填比分。
    // this.shots 是被 shift() 消费的队列，只改 currentShotIndex 而不重建它，
    // 会导致后续杆被跳过或重复播放，比分 HUD（靠队列里的 SCORE 事件推进）随之错位。
    // 起点是 off + 1 而不是 off —— 下面 container.table.hit() 已经把本杆的
    // AimEvent 消费掉了，用 off 会让本杆再被完整重播一次。
    if (idx !== this.currentShotIndex) {
      this.rebuildQueueFrom(idx)
    }
    // v1.8.4：把杆内目标时刻夹在本杆名义时长内。进度条取整会让 target 略微
    // 越过杆尾（落在下一杆的开头），不夹的话这一杆会被多推几十毫秒，画面与
    // 进度条对不上。
    const localTarget = Math.min(
      Math.max(0, target - cum[idx]),
      Math.max(meta.duration, 1e-3)
    )
    this.currentShotIndex = idx
    this.restoreShotStart(meta)
    this.container.table.hit()
    // v1.3.59：seek 重跑等同于一记真实出杆（确定性重跑物理到目标时刻）
    // v1.5.4（#70）：与 precomputeShot 同理，对 Depth-exceeded 物理异常容错，
    // 拖动进度条落到「碰撞解算不收敛」的杆段时按已推进到的位置收尾。
    const step = this.container.step
    let guard = 0
    // v1.5.6（#81）：拖到进度条尽头时，必须把这一杆真正跑到静止，而不是
    // 卡在「时间到达 duration」的那一瞬。
    //
    // 病灶：循环判据是 `table.time < localTarget`，而 localTarget 来自
    // 预演估算的 duration。估算值偏小时（实测拖到 100% 后 globalT 只到
    // total 的 99.6%），循环在时间到点时就退出，可球还在滚 —— 用户把进度条
    // 拉到最后，看到的却是一个「球仍在运动的中途画面」，而不是对局结束的
    // 终局台面（探针实测末尾仍有 2 颗球 inMotion）。
    //
    // 拖到尽头 = 用户想看结果，此时忽略时间上限，一路推进到 allStationary
    // （guard 仍兜底防不收敛）。非尽头的拖动保持原样，避免改变手感。
    const toEnd = frac >= Replay.SEEK_END_FRAC
    try {
      while (
        (toEnd || this.container.table.time < localTarget) &&
        !this.container.table.allStationary() &&
        guard++ < 500000
      ) {
        this.container.table.advance(step)
      }
    } catch {
      console.warn("[replay] seek advance hit Depth-exceeded, settle at current position")
    }
    // v1.5.6（#81 补）：实跑与预演的收杆时刻天然有偏差 —— 实测末杆预演记
    // 5210.9ms，而 live 桌子 3978.5ms 就静止（差 1232ms，2037 步 vs 2668 步；
    // 同一份 meta 在 simTable 上复算则与 duration 分毫不差）。球已静止、画面
    // 就是终局，可进度条按 `cum + table.time` 计算，只能读到 98.5%，看着像
    // 「没拖到底」。末尾剩下的全是「球已静止」的死时间，这里把时钟对齐到本杆
    // 名义时长，让进度条读满 100%，台面保持终局状态不变。
    if (toEnd && this.container.table.time < localTarget) {
      this.container.table.time = localTarget
    }
    this.container.table.updateBallMesh(0)
    /**
     * v1.8.4：seek 后把球杆复位成「静置瞄准」。
     *
     * `table.hit()` 会启动送杆动画（hittingAnimation=true），随后每帧累积
     * t，到 STROKE_END_T 就自动收杆 —— 用户拖完进度条停在那里看局面时，
     * 球杆会在 1.5 秒后消失。这里交给 syncReplayCue() 统一处理（它同时负责
     * 「贴住母球」与「播放中收杆」），并顺手清掉不属于当前时刻的近距离提示。
     */
    this.syncReplayCue()
    try {
      this.container.table.proximityIndicator.hide()
    } catch (e) {
      /* 容错：提示清理失败不应阻塞 seek */
    }
    // v1.5.4（#70）：自由视角下 seek 不再重定位相机 —— 镜头完全由用户控制，
    // 拖动进度条只重跑球局物理，视角保持用户当前角度不变。
    this.container.view.update(0, this.container.table.cue.aim)
    this.container.view.render()
  }

  /**
   * v1.2.11 #F11：计算整局累计时长与每杆起始偏移。
   * cum[i] = 前 i 杆时长之和；total = 所有杆时长之和。
   * 增量方案：只用已记录的 shotMeta，无需预跑整局。
   */
  private gameTotals(): { cum: number[]; total: number } {
    const cum: number[] = []
    let acc = 0
    for (const m of this.shotMeta) {
      cum.push(acc)
      acc += Math.max(m.duration, 1e-3)
    }
    return { cum, total: acc }
  }

  /**
   * v1.2.17：每帧由 container.advance 回调，返回本帧回放倍速。
   * 不再按「最后碰撞/进袋」自动提速——击球到进球的真实时间间隔
   * 完全由用户选择的全局倍速决定。
   * v1.2.27：移除 v1.2.22「击球过程中强制 1x」的限制。此前该限制使「倍速」按钮
   * 仅在杆间短暂等待生效、球运动阶段恒为 1x，用户误以为倍速失效。现全程使用用户
   * 选择的全局倍速：默认 1x（仍看清击球/碰撞/进球），选 2x/4x 即整段回放加速。
   */
  private replayTimeScale(): number {
    // v1.3.75：用户按了「暂停」→ 直接冻结（timeScale=0）。
    // 即使某处把 container.replayPaused 复位（如拖动进度条松手），
    // 用户显式按下的暂停也不会被悄悄取消。
    if (this.userPaused) return 0
    // v1.2.27：移除「击球过程中强制 1x」的限制。
    // 此前该限制让用户的倍速选择只在杆间短暂等待里生效，球运动（回放最主要内容）
    // 阶段恒为 1x，导致「倍速」按钮看起来完全无效。
    // 现全程使用用户选择的全局倍速：默认 1x（仍看清击球/碰撞/进球），用户选 2x/4x 即整体加速。
    return Replay.REPLAY_SPEEDS[this.replaySpeedIndex]
  }

  /** 用户点击底部「倍速」按钮：在 0.5x / 1x / 2x / 4x 之间循环切换 */
  private cycleReplaySpeed(): string {
    this.replaySpeedIndex =
      (this.replaySpeedIndex + 1) % Replay.REPLAY_SPEEDS.length
    return this.currentSpeedLabel()
  }

  private currentSpeedLabel(): string {
    const s = Replay.REPLAY_SPEEDS[this.replaySpeedIndex]
    return s === 0.5 ? "0.5x" : s + "x"
  }

  /** v1.2.11 #F11：每帧刷新进度条位置（整局进度）与全局进球吸附点 */
  private tickSeekUI() {
    if (!this.seekEl) return
    if (!this.userScrubbing) {
      const { cum, total } = this.gameTotals()
      if (total > 0) {
        const idx = this.currentShotIndex < 0 ? 0 : this.currentShotIndex
        // v1.5.5（#77 实锤③）：第一杆 HitEvent 到来前 currentShotIndex=-1，
        // 而 Container.advance 对静止桌面仍无条件调 table.advance（该循环
        // 没有静止守卫，Table.advance 里 `time += t*1000` 照加）——空闲期
        // table.time 以真实速率空转累积（实机挂钩实测：进回放数秒即被推到
        // 46.7s，进度条显示 65%，第一杆开打 hit() 归零后猛跳回 0 —— 即
        // 用户报的「进度条错误」）。进度条只认「已播杆累计时长 + 当前杆内
        // 物理时间」：未开杆时 time 一律视为 0，空闲期累积值不得入账。
        // v1.5.8（#90）：杆末 / 杆间的时钟空转不得计入进度。
        //
        // 病灶：`Container.advance` 的物理循环没有「本杆已结束」的上界，球
        // 停下之后 `Table.advance` 里 `time += t*1000` 仍在以真实速率累加
        // —— 杆间 delay 的几百毫秒、以及末杆播完到用户点退出之间的整段
        // 等待，全都记到了**当前这一杆**头上。DIAG2 实机抓到倒数第二杆
        // 的时钟被空转到 11115ms（该杆名义时长只有 5127ms），进度条因此
        // 顶满 1000/1000，而画面还停在倒数第二杆 —— 用户把进度条拉/看到
        // 「最后」，看到的却不是对局终局。
        //
        // v1.5.5（#77）只堵了「未开杆（idx<0）」的空转，杆内和杆间没管。
        // 这里给每杆时钟加上名义时长上界：本杆该走多久就最多算多久，
        // 超出部分一律是本杆结束后的死时间。
        const dur =
          this.shotMeta[idx] && this.shotMeta[idx].duration > 0
            ? this.shotMeta[idx].duration
            : Number.POSITIVE_INFINITY
        const shotTime =
          this.currentShotIndex < 0
            ? 0
            : Math.min(this.container.table.time, dur)
        const cur = cum[idx] + shotTime
        const frac = Math.min(cur / total, 1)
        this.seekEl.value = String(Math.round(frac * 1000))
      }
    }
    this.renderSnaps()
  }

  /** v1.2.11 #F11：渲染全局进球吸附点（所有已记录杆的 pots 平移到全局位置） */
  private renderSnaps() {
    if (!this.snapsEl) return
    const { cum, total } = this.gameTotals()
    if (total <= 0) {
      if (this.lastSnapSig !== "") {
        this.snapsEl.innerHTML = ""
        this.lastSnapSig = ""
      }
      return
    }
    // 签名：所有杆的 pots 数 + total，避免每帧重建
    let potCount = 0
    for (const m of this.shotMeta) potCount += m.pots.length
    const sig = potCount + ":" + Math.round(total) + ":" + this.shotMeta.length
    if (sig === this.lastSnapSig) return
    this.lastSnapSig = sig
    let html = ""
    for (let i = 0; i < this.shotMeta.length; i++) {
      const meta = this.shotMeta[i]
      const segDur = Math.max(meta.duration, 1e-3)
      for (const p of meta.pots) {
        const globalT = cum[i] + (p.t - Replay.REPLAY_LEAD_MS)
        const f = Math.max(0, Math.min(1, globalT / total))
        // v1.5.4（#70）：按归属分色 —— 玩家=蓝、AI=红，一眼看出谁进的球
        const cls = p.owner === "ai" ? "snap-ai" : "snap-player"
        html += `<span class="replay-snap ${cls}" style="left:${(f * 100).toFixed(2)}%"></span>`
      }
    }
    this.snapsEl.innerHTML = html
  }

  // ---- 进度条交互（拖动冻结物理、释放恢复；吸附到进球前时间点） ----
  private onSeekStart = () => {
    this.userScrubbing = true
    // v1.3.75：改用 applyPauseState，拖动结束后若用户此前按过暂停会正确恢复冻结
    this.applyPauseState()
    // 取消挂起的「下一杆」定时器：拖动重跑本杆后再次静止会重新调度一次，
    // 若不取消则原定时器仍会触发，导致下一杆被重复调度。
    clearTimeout(this.timer)
    this.timer = undefined
  }
  /**
   * v1.5.6（#80）：把进度条值吸附到最近的进球时刻。
   *
   * ⚠️ v1.8.4 起**不再被调用** —— 松手吸附会让画面跳到「另一杆的进球点」，
   * 用户看到的就是「我拖到这里，结果是另一局的画面」。拖动现在严格线性。
   * 保留实现备查（要恢复吸附只需在 onSeekEnd 里改回一行）。
   */
  protected snapFraction(frac: number): number {
    const { cum, total } = this.gameTotals()
    if (total <= 0) return frac
    const SNAP = Replay.SEEK_SNAP_FRAC // 吸附阈值（与末端豁免同源，见常量处注释）
    let best = -1
    let bestD = SNAP
    for (let i = 0; i < this.shotMeta.length; i++) {
      const meta = this.shotMeta[i]
      for (const p of meta.pots) {
        const globalT = cum[i] + (p.t - Replay.REPLAY_LEAD_MS)
        const sf = Math.max(0, Math.min(1, globalT / total))
        const d = Math.abs(frac - sf)
        if (d < bestD) {
          bestD = d
          best = sf
        }
      }
    }
    return best >= 0 ? best : frac
  }

  private onSeekInput = () => {
    if (!this.seekEl) return
    // 拖动过程保持线性：不做吸附，落点只由松手位置决定（见 snapFraction）
    this.seekToFraction(Number(this.seekEl.value) / 1000)
  }
  private onSeekEnd = () => {
    if (this.seekEl) {
      const raw = Number(this.seekEl.value) / 1000
      // v1.8.4：**取消「进球点吸附」**。
      //
      // 旧行为：松手时若落点距离某个进球时刻在 2.5% 以内，就把落点改写成
      // 那个进球点。用户的实际感受是「我拖到这里，松手后画面跳到别处」——
      // 而且被吸到的往往是**另一杆**的进球点，球局与进度条对不上，看起来
      // 就像「放的是另一局的素材」（用户报的核心现象之一）。
      // 现在拖动严格线性：拖到哪就是哪。需要快速定位进球时刻，进度条下方
      // 本来就有可点的吸附点标记（snaps），点它比拖动更精确。
      //
      // 末端仍按原逻辑顶到 1：真机拖把压不到 1000，需要它进终局分支。
      const frac = raw >= 1 - Replay.SEEK_SNAP_FRAC ? 1 : raw
      this.seekEl.value = String(Math.round(frac * 1000))
      this.seekToFraction(frac)
    }
    this.userScrubbing = false
    // v1.3.75：拖完是否恢复播放取决于用户有没有按过暂停，不能一律复位
    this.applyPauseState()
    this.resumeAfterSeek()
  }

  /**
   * v1.3.59：松手后若台面已经静止，手动把静止事件补进事件队列。
   *
   * 病根：seekToFraction 的确定性重跑循环会在 `allStationary()` 成立时提前退出，
   * 一旦拖到杆末/吸附点/整局末端，seek 结束时台面就是静止的。而 Container.advance
   * 的判据是 `!stateBefore && allStationary()`（帧首已静止则永远不成立），
   * StationaryEvent 再也产生不了 → handleStationary 永不触发 → 而它是唯一的
   * 「静止后调度下一杆」入口 → 回放就此卡死，界面上却没有任何暂停提示。
   *
   * timer === undefined 这一守卫同时挡住了重复调度，以及 change + pointerup
   * 双触发导致的两次 onSeekEnd。
   */
  private resumeAfterSeek() {
    if (!this.container.table.allStationary() || this.timer !== undefined) {
      return
    }
    const hasNext = this.shots.some((e) => {
      const t = e?.type
      return (
        t !== EventType.RERACK &&
        t !== EventType.PLACEBALL &&
        t !== EventType.SCORE
      )
    })
    if (!hasNext) {
      // 整局末端：停住即可，不要重播末杆（与回放自然结束的行为一致）
      this.container.replayPaused = true
      return
    }
    this.container.eventQueue.push(new StationaryEvent())
  }

  /**
   * v1.8.4：回放里的球杆同步（每帧调用）。
   *
   * 病灶与取舍：
   *   · 回放的 `cue.aim.pos` 是**本杆起始位置**（restoreShotStart 从 layout 还原），
   *     球一开始滚它就与母球脱钩。实测拖到中段时杆钉在 (0.98, −0.19)、母球滚到
   *     (−1.18, 0.32)，两者相距 2.2 米，杆身整根甩到桌外 —— 画面上就是「桌边
   *     一根不知从哪来的棍子」，用户读作「没有球杆」。
   *   · 播放中球在跑时也不该有杆：真实对局击完立刻收杆（retractAfterStroke），
   *     一根杵在原地的杆只会挡球路。
   *
   * 于是：
   *   1. **冻结时**（暂停 / 拖进度条 / 播完）—— 杆贴着当前母球，用本杆录制的
   *      角度/加塞/抬杆摆成瞄准姿态。这是「这一杆是怎么打的」的可读快照。
   *   2. **播放中且球在滚** —— 收杆。
   *   3. **积分板间的静止间隙**（下一杆还没开球）—— 用下一杆的角度预先把杆亮出来，
   *      让「瞄准 → 出杆」有连贯感，而不是每杆都凭空出现。
   */
  private syncReplayCue() {
    try {
      const table = this.container.table
      const cue = table.cue
      const ball = table.cueball
      const frozen = this.userPaused || this.userScrubbing || this.container.replayPaused
      let meta = this.shotMeta[this.currentShotIndex]
      if (!frozen) {
        const next = this.shotMeta[this.currentShotIndex + 1]
        // 球还在滚，或者已经没有下一杆（整局播完）—— 都收杆。
        if (!table.allStationary() || !next) {
          cue.hideCue()
          return
        }
        meta = next
      }
      // 母球不在台面上（刚进袋 / 正在落袋 / 出界）时没有「杆贴着球」可画。
      // 判据必须用 state —— Ball.pocket 是「上一次落袋」的残留引用，实测
      // 一颗在台中央 Rolling 的球也带着 pocket（见下方 layout 采集处的注释），
      // 用它判断会把 11/18 杆的杆误收起来。
      if (!ball || ball.offTable || ball.state === State.InPocket || ball.state === State.Falling) {
        cue.hideCue()
        return
      }
      if (meta) {
        cue.aim.angle = meta.aim.angle
        cue.aim.elevation = meta.aim.elevation
        cue.aim.power = meta.aim.power
        cue.aim.offset.copy(meta.aim.offset)
      }
      cue.aim.pos.copy(ball.pos)
      cue.aimMode()
      // t=0 → 送杆曲线取驻留位（strokeX=0），杆头正好贴住球面。
      cue.t = 0
      cue.moveTo(cue.aim.pos)
    } catch (e) {
      /* 纯表现层同步，任何异常都不该影响回放推进 */
    }
  }

  /** v1.2.9 #F5：挂载回放进度条 DOM 与每帧/交互回调 */
  private setupReplaySeek() {
    const bar = document.getElementById("replaySeekBar")
    this.seekEl = document.getElementById("replaySeek") as HTMLInputElement | null
    this.snapsEl = document.getElementById("replaySeekSnaps")
    if (bar) bar.removeAttribute("hidden")
    // v1.2.13 #replay：双重保险隐藏底部栏：CSS + 内联 !important
    const panel = document.getElementById("panel")
    if (panel) panel.style.setProperty("display", "none", "important")
    // v1.2.19 #2：CSS + JS 双保险隐藏右上角设置齿轮。部分环境 CSS 规则被缓存或
    // 未生效，导致回放时齿轮仍可见；这里直接用内联 style 强制隐藏。
    const menu = document.getElementById("menu")
    if (menu) menu.style.setProperty("display", "none", "important")
    this.container.replayPaused = false
    this.userScrubbing = false
    // v1.3.75：进入回放时复位手动暂停，按钮文案回到「暂停」
    this.userPaused = false
    this.lastSnapSig = ""
    // v1.3.75：挂载「暂停 / 继续」按钮（回放全程常驻，置于倍速按钮之前）
    const pause = document.getElementById(
      "replayPauseBtn"
    ) as HTMLButtonElement | null
    this.pauseBtn = pause
    if (pause) {
      pause.disabled = false
      pause.textContent = "暂停"
      pause.classList.remove("paused")
      pause.addEventListener("click", this.onPauseClick)
    }
    this.container.replayTimeScaleHook = () => this.replayTimeScale()
    this.container.replayFrameHook = () => {
      this.tickSeekUI()
      // v1.8.4：球杆跟随白球 + 播放中收起，见 syncReplayCue()。
      this.syncReplayCue()
      // v1.5.4（#70）：自由视角 —— 镜头由用户在 canvas 上拖动/缩放控制，
      // 每帧回调不再干预相机（详见 setupReplayFreeCam / Camera.replayFreeView）。
    }
    // 显示「退出回放」按钮并绑定（回放全程常驻，结束后供用户离开）
    const exit = document.getElementById("replayExitBtn") as HTMLButtonElement | null
    this.exitBtn = exit
    if (exit) {
      exit.removeAttribute("hidden")
      exit.addEventListener("click", this.exitHandler)
    }
    // v1.2.17 #4：挂载全局倍速按钮，初始化为当前倍速标签并绑定循环切换
    const speed = document.getElementById("replaySpeedBtn") as HTMLButtonElement | null
    this.speedBtn = speed
    if (speed) {
      speed.textContent = this.currentSpeedLabel()
      speed.addEventListener("click", this.onSpeedClick)
    }
    // v1.5.5（#76）：挂载「俯视」按钮 —— 一键切回原有俯视视角。
    // 自由视角下用户转乱了/想回全局视野时用；拖动画面又可再进自由视角。
    const topBtn = document.getElementById("replayTopBtn") as HTMLButtonElement | null
    this.topBtn = topBtn
    if (topBtn) {
      // v1.8.4：按钮文案跟着当前机位走 —— 默认斜视时提示「俯视」，
      // 图解/开伦默认俯视时提示「全桌」。
      topBtn.textContent =
        this.container.view.camera.mode === this.container.view.camera.topView
          ? "全桌"
          : "俯视"
      topBtn.addEventListener("click", this.onTopBtnClick)
    }
    // v1.5.4（#70）：原「视角切换按钮（跟随/俯视）」已随跟随视角一并移除，
    // 自由视角不再需要按钮 —— 直接在画面上拖动即可转向、捏合/滚轮缩放。
    // 若旧版 HTML 仍残留该按钮，则主动隐藏，避免出现一个点了没反应的死按钮。
    const cam = document.getElementById("replayCamBtn") as HTMLButtonElement | null
    if (cam) cam.setAttribute("hidden", "")
    if (this.seekEl) {
      this.seekEl.addEventListener("pointerdown", this.onSeekStart)
      this.seekEl.addEventListener("pointerup", this.onSeekEnd)
      this.seekEl.addEventListener("input", this.onSeekInput)
      this.seekEl.addEventListener("change", this.onSeekEnd)
      // v1.5.5（#77 实锤②）：拖动被打断的兜底 —— 真机上手指拖进度条时来电、
      // 下拉通知、系统手势、弹窗抢占等都会触发 pointercancel（触摸流为
      // touchcancel），此后 pointerup/touchend **不会再派发**，onSeekEnd 永不
      // 执行 → userScrubbing 永久卡在 true → 物理冻结 + 进度条停更，回放
      // 无提示停死（用户报的「偶发停止」）。cancel 是幂等收尾：与 onSeekEnd
      // 同一处理器，timer 守卫会挡掉与正常路径的重复调度。
      this.seekEl.addEventListener("pointercancel", this.onSeekEnd)
      this.seekEl.addEventListener("lostpointercapture", this.onSeekEnd)
      // 触屏兜底（部分 WebView 不派发 pointer 事件）
      this.seekEl.addEventListener("touchstart", this.onSeekStart, {
        passive: true,
      })
      this.seekEl.addEventListener("touchend", this.onSeekEnd)
      this.seekEl.addEventListener("touchcancel", this.onSeekEnd)
    }
  }

  /** v1.2.9 #F5：退出回放时隐藏进度条、解绑事件、清空每帧回调 */
  private hideReplaySeek() {
    // v1.8.4：撤掉回放的球杆视觉补偿，恢复正常比例与高度；
    // 顺带把杆亮回来 —— 回放里播放中是被 hideCue() 收起来的。
    try {
      this.container.table.cue.setVisualBoost(0, 1)
      this.container.table.cue.aimMode()
    } catch (e) {
      /* 忽略 */
    }
    const bar = document.getElementById("replaySeekBar")
    if (bar) bar.setAttribute("hidden", "")
    if (this.seekEl) {
      this.seekEl.removeEventListener("pointerdown", this.onSeekStart)
      this.seekEl.removeEventListener("pointerup", this.onSeekEnd)
      this.seekEl.removeEventListener("input", this.onSeekInput)
      this.seekEl.removeEventListener("change", this.onSeekEnd)
      this.seekEl.removeEventListener("pointercancel", this.onSeekEnd)
      this.seekEl.removeEventListener("lostpointercapture", this.onSeekEnd)
      this.seekEl.removeEventListener("touchstart", this.onSeekStart)
      this.seekEl.removeEventListener("touchend", this.onSeekEnd)
      this.seekEl.removeEventListener("touchcancel", this.onSeekEnd)
    }
    this.container.replayPaused = false
    this.userScrubbing = false
    // v1.3.75：退出回放时复位手动暂停
    this.userPaused = false
    this.container.replayTimeScaleHook = null
    this.container.replayFrameHook = null
    // v1.3.75：解绑并复位暂停按钮
    if (this.pauseBtn) {
      this.pauseBtn.removeEventListener("click", this.onPauseClick)
      this.pauseBtn.textContent = "暂停"
      this.pauseBtn.classList.remove("paused")
      this.pauseBtn = null
    }
    // 隐藏「退出回放」并解绑
    if (this.exitBtn) {
      this.exitBtn.removeEventListener("click", this.exitHandler)
      this.exitBtn.setAttribute("hidden", "")
      this.exitBtn = null
    }
    // v1.2.17 #4：解绑并复位倍速按钮
    if (this.speedBtn) {
      this.speedBtn.removeEventListener("click", this.onSpeedClick)
      this.speedBtn = null
    }
    // v1.5.5（#76）：解绑俯视按钮
    if (this.topBtn) {
      this.topBtn.removeEventListener("click", this.onTopBtnClick)
      this.topBtn = null
    }
    // v1.5.4（#70）：解绑自由视角手势（跟随/俯视按钮已移除）
    this.teardownReplayFreeCam()
    // v1.2.13 #replay：恢复底部栏显示
    const panel = document.getElementById("panel")
    if (panel) panel.style.removeProperty("display")
    // v1.2.19 #2：恢复设置齿轮显示，并用 opacity 做过渡避免突跳。
    // 先把 display 清掉让元素回到 CSS 默认 flex，下一帧再恢复 opacity。
    const menu = document.getElementById("menu")
    if (menu) {
      menu.style.removeProperty("display")
      menu.style.opacity = "0"
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          menu.style.transition = "opacity 0.18s ease"
          menu.style.opacity = "1"
          // 动画结束后清理内联样式，避免后续 hover/active 被覆盖
          setTimeout(() => {
            menu.style.removeProperty("opacity")
            menu.style.removeProperty("transition")
          }, 200)
        })
      })
    }
    document.body.classList.remove("replay-mode")
  }

  override handleHit(_: HitEvent) {
    this.container.updateLastShot()
    // v1.2.9 #F3 / #F5：每杆起手记账（隔离 outcome + 起始快照 + 头less 预演）
    this.beginShotBookkeeping()
    // v1.2.27：起步不直接写 timeScale（advance 每帧由 replayTimeScaleHook 决定，
    // 该钩子返回用户选择的全局倍速）。保留此赋值仅为兼容旧逻辑，会被每帧覆盖。
this.container.timeScale = 1
// v1.3.66：回放同样走 handleHit → hit() 出杆（镜头跟随改回每帧三点框定平滑，
// 不再做逐杆锁定 / 追袋口微调）
this.hit()
return this
}

override handleStationary(_) {
// v1.2.6 #232：球已静止，等待下一次击球。
// v1.5.4（#70）：自由视角，相机不随杆复位。
this.container.timeScale = 1
    const outcome = this.container.table.outcome
    this.container.recorder.updateBreak(outcome, false, false)
    if (this.shots.length > 0 && this.timer === undefined) {
      this.playNextShot(this.delay)
    }
    if (this.shots.length === 0 && this.timer === undefined) {
      // v1.2.11 #user：回放结束后先暂停，不弹「回放结束」按钮，
      // 保留进度条与「退出回放」按钮，让用户先自行拖动进度条回看本局。
      this.container.timeScale = 1
      // v1.5.8（#90）：整局播完 = 用户要看对局终局，直接 seek 到 100%。
      //
      // 病灶（三重叠加，实机 DIAG2 取证）：
      //   ① 末杆实跑普遍比预演短（末杆预演 7500ms、live 桌子提前静止），
      //      进度条按 `cum + table.time` 只算到 910/1000；
      //   ② 杆末时钟空转（已由 tickSeekUI 的上界修掉）；
      //   ③ 自然播放会少播最后一杆 —— 事件序列末尾形如
      //      `AIM, AIM, PLACEBALL, SCORE`，最后那个 AIM 的出杆迟迟不落地，
      //      播完时 currentShotIndex 停在 metaLen-2（14 杆的局停在 12），
      //      画面是倒数第二杆的台面，进度条也跟着缺一截。
      //
      // 拖动到尽头有 toEnd 分支兜住（v1.5.6 #81），自然播放到底这条路径
      // 从来没有对齐过 —— 用户报的「进度条最后依旧不是对局结束」就是它。
      // 这里复用同一条已验证的终局链路：播完即 seek 到 100%，末杆确定性
      // 重跑到静止，画面与进度条同时落到对局终局。
      if (!this.playFinished) {
        this.playFinished = true
        try {
          this.seekToFraction(1)
        } catch (e) {
          console.warn("[replay] seek to end on finish failed:", (e as Error)?.message)
        }
      }
      this.container.replayPaused = true
      // v1.3.75：整局回放播完后禁用暂停按钮 —— 此时物理已经走完，
      // 再点「继续」只会让空转的 timeScale 恢复，没有任何画面可看。
      if (this.pauseBtn) {
        this.pauseBtn.disabled = true
        this.pauseBtn.textContent = "暂停"
        this.pauseBtn.classList.remove("paused")
      }
      return this
    }
    return this
  }

  override handleInput(input: Input): Controller {
    this.commonKeyHandler(input)
    return this
  }

  override handleBreak(event: BreakEvent): Controller {
    this.container.table.updateFromShortSerialised(event.init)
    // v1.5.5（#77 同源）：换局重建球局后同样清零时间轴（语义：新局从 0 开始），
    // 与构造函数清零一致，避免空闲期空转累积叠加到新局进度条上。
    this.container.table.time = 0
    this.shots = [...event.shots]
    // v1.3.59：换局后事件序列整批替换，旧的 shotMeta / currentShotIndex 全部失效，
    // 必须一并重置，否则 shotEventOffsets 指向新序列、shotMeta 仍是旧局的，
    // 拖动进度条会定位到完全错误的杆。
    this.allShots = [...this.shots]
    this.shotEventOffsets = this.buildShotOffsets()
    this.currentShotIndex = -1
    this.shotMeta = []
    this.diagram = event.diagram
    this.container.table.showSpin(true)
    if (event.retry) {
      return this.retry()
    }
    this.playNextShot(this.delay)
    return this
  }

  override handleAbort(_: AbortEvent): Controller {
    clearTimeout(this.timer)
    this.timer = undefined
    // v1.2.6 #232：退出回放，恢复正常速度
    this.container.timeScale = 1
    // v1.2.9 #F5：隐藏回放进度条
    this.hideReplaySeek()
    return new End(this.container)
  }

  retry() {
    clearTimeout(this.timer)
    this.timer = undefined
    // v1.2.6 #232：转实时重打，恢复正常速度
    this.container.timeScale = 1
    // v1.2.9 #F5：隐藏回放进度条
    this.hideReplaySeek()
    this.container.table.updateFromShortSerialised(this.init)
    // v1.5.5（#77 同源）：重打重建球局后清零时间轴（语义：新局从 0 开始）。
    this.container.table.time = 0
    // v1.5.4（#71）：offTable 是上一杆物理动画留下的运行时标志（渲染层据此
    // 隐藏出界球），重打会完全重置球局，这里必须一并清掉，否则瞄准阶段
    // 白球会因残留标志而隐身。
    this.container.table.balls.forEach((b) => {
      b.offTable = false
      b.wasAirborne = false
    })
    const aim = AimEvent.fromJson(this.firstShot)
    this.container.table.cueball = this.container.table.balls[aim.i]
    this.container.rules.cueball = this.container.table.cueball
    this.container.table.cueball.pos.copy(aim.pos)
    this.container.table.cue.aim = aim
    this.container.view.camera.forceMode(this.container.view.camera.aimView)
    return new Aim(this.container)
  }
}
