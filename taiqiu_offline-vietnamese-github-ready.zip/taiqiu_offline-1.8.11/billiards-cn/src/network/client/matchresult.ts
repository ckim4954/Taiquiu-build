import { Container } from "../../container/container"
import { NotificationEvent } from "../../events/notificationevent"
import { ScoreEvent } from "../../events/scoreevent"
import { End } from "../../controller/end"
import { Session } from "./session"
import { gameOverButtons } from "../../utils/gameover"
import { VERSION } from "../../utils/version"
import { recordResult, seriesText } from "../../utils/series"
import { NotificationHighBreak, NotificationActionHandlers } from "../../view/notification"
import { t } from "../../utils/i18n"
import { downloadText } from "../../utils/download"
import { saveReplayToDB } from "../../utils/replay-store"
import { getUID } from "../../utils/uid"
import { storeReplayAndNavigate } from "../../utils/replay-nav"

export interface MatchResult {
  winner: string
  loser?: string
  /** v1.8.4：获胜方的网络身份。局域网对战时双方 playername 都叫「玩家」，
   * 只靠名字无法判断「我是赢家吗」，必须用 clientId 比较。 */
  winnerClientId?: string
  loserClientId?: string
  winnerScore: number
  loserScore?: number
  ruleType: string
  replayData?: string
  version?: string
  userAgent?: string
  bot?: boolean
}

export class MatchResultHelper {
  static presentGameEnd(
    container: Container,
    rulename: string,
    forcedAmIWinner?: boolean,
    endSubtext?: string
  ): End {
    container.recorder.wholeGameLink()

    const session = Session.getInstance()
    const amIWinner = this.determineWinner(
      session,
      rulename,
      forcedAmIWinner,
      endSubtext
    )
    const subtext = endSubtext ?? this.getScoreSubtext(container, rulename)

    // v1.3.65：人机对战时把「系列赛 你 X : Y 电脑」追加到结算文案末尾。
    // 「再来一局」走 location.reload()，URL 上的 ?bot=&ruletype= 参数原样带回，
    // 所以同一玩法连打会自动累加；换玩法或退回主菜单时清零（见 series.ts）。
    // 注意这里必须在 notifyEndState 之前记，否则面板读到的是上一局的比分。
    //
    // v1.3.83：判据从 `isBotMode()` 换成 `isSeriesMode()` —— 局域网对战同样
    // 「打完一局能接着开下一局」，此前被排除在外，导致局比分既不记也不显示
    // （用户反馈第 1 条）。局域网对手名用 Session.opponentName（initLanMode
    // 里设为「对手」）。
    let seriesLine = ""
    if (Session.isSeriesMode()) {
      recordResult(rulename, amIWinner)
      seriesLine = seriesText(rulename, this.seriesOpponentLabel())
    }
    const finalSubtext = seriesLine
      ? subtext
        ? `${subtext}\n${seriesLine}`
        : seriesLine
      : subtext

    this.notifyEndState(container, amIWinner, finalSubtext)

    const result = this.createMatchResult(rulename, session, amIWinner)

    return new End(container, result)
  }

  /**
   * v1.3.83：系列赛行末尾的对手称呼。
   *
   * 人机对战用比分栏同款的名字（含难度，如「电脑(专业)」，由 Session.opponentName
   * 在 BrowserContainer 里写入）；局域网对战的人是对面那位玩家，叫「电脑」显然
   * 不对，统一叫「对手」（initLanMode 也把 opponentName 设为「对手」）。
   */
  private static seriesOpponentLabel(): string {
    if (!Session.isBotMode()) return "对手"
    return Session.getInstance().opponentName ?? "电脑"
  }

  private static determineWinner(
    session: Session,
    rulename: string,
    forcedAmIWinner?: boolean,
    endSubtext?: string
  ): boolean {
    // v1.8.4：原来这里同时用了两套坐标 —— `orderedScoresForHud()` 返回的是
    // **本地视角**（p1 恒为「我」），却被拿去和**座位号** `session.playerIndex`
    // 比较（`winnerIndex === playerIndex`）。座位号 1 的从机因此永远判反：
    // 分高时 winnerIndex=0 ≠ 1 → 判输，分低时 1 === 1 → 判赢。
    // 局域网「主机输了却判赢」就是它。直接比较本地分数即可，不再掺座位号。
    const myScore = session.myScore()
    const opponentScore = session.opponentScore()
    const iHaveMore = myScore > opponentScore

    if (forcedAmIWinner !== undefined) {
      if (endSubtext?.toLowerCase().includes("conceded")) {
        return forcedAmIWinner
      }
      if (Session.isBotMode()) {
        // If it's a natural end (forcedAmIWinner came from rules), score should be considered
        // If it's a concession (forcedAmIWinner=false passed to rules), forcedAmIWinner should be respected.
        // Rules pass false to handleGameEnd when bot wins by score/legal pot.
        // But BotEventHandler should now be passing the correct winner based on score.
        return forcedAmIWinner
      }
      // For games like NineBall/EightBall, forcedAmIWinner (potting 9-ball/8-ball) is king.
      // For Snooker, score is king.
      if (rulename === "snooker") {
        return iHaveMore
      }
      return forcedAmIWinner
    }

    return iHaveMore
  }

  private static notifyEndState(
    container: Container,
    amIWinner: boolean,
    subtext: string
  ): void {
    if (amIWinner) {
      this.notifyWin(container, subtext)
      this.sendLossNotification(container)
    } else if (Session.isSpectator()) {
      this.notifySpectator(container, subtext)
    } else {
      this.notifyLoss(container, subtext)
      this.sendWinNotification(container)
    }
  }

  static isWinner(result: MatchResult): boolean {
    const session = Session.getInstance()
    // v1.8.4：局域网对战里双方 playername 都是「玩家」，用名字比较会让
    // 两边都判成赢家（各自上传战绩 + 放庆祝粒子）。优先用 clientId。
    if (result.winnerClientId && session.clientId) {
      return result.winnerClientId === session.clientId
    }
    return result.winner === session.playername
  }

  private static notifyWin(container: Container, subtext: string) {
    container.notifyLocal(
      {
        type: "GameOver",
        title: t("youWon"),
        subtext: subtext,
        highBreaks: this.getHighBreaks(container),
        icon: "🏆",
        extraClass: "is-winner",
        extra: this.getGameOverButtons(),
        duration: 0,
      },
      0,
      this.buildSaveReplayHandler(container)
    )
  }

  private static notifyLoss(container: Container, subtext: string) {
    container.notifyLocal(
      {
        type: "GameOver",
        title: t("youLost"),
        subtext: subtext,
        highBreaks: this.getHighBreaks(container),
        icon: "🥈",
        extraClass: "is-loser",
        extra: this.getGameOverButtons(),
        duration: 0,
      },
      0,
      this.buildSaveReplayHandler(container)
    )
  }

  /** v1.2.4：构建「保存回放」按钮的动作处理器。
   *  编码本局录制数据 → Blob 下载 + 写入本地 IndexedDB（「我的回放」），
   *  并在原结算面板的按钮上就地反馈，不替换结算面板。 */
  private static buildSaveReplayHandler(
    container: Container
  ): NotificationActionHandlers {
    return {
      viewReplay: () => {
        try {
          const compressed = container.recorder.getWholeGameCompressed()
          // 经 sessionStorage 传递完整回放数据，避开 WebView URL 长度上限
          // （之前 ?state= 超长被截断，只回放前几个球）。
          storeReplayAndNavigate(compressed, container.rules.rulename)
        } catch (e) {
          console.error("view replay failed", e)
        }
      },
      saveReplay: () => {
        // v1.5.4（#69）：「已保存 ✓」必须等 IndexedDB 真正落库后再显示。
        //
        // 病灶：saveReplayToDB 是 fire-and-forget（异步 open+put），旧代码在
        // **发起写入的同一帧**就把按钮置成「已保存 ✓」。真机（Android WebView）
        // 上 IndexedDB 事务的提交可能滞后几百毫秒 —— 用户看到成功提示后立刻
        // 「返回主菜单」，页面卸载时 put 尚未提交，写入被静默丢弃；用户却以
        // 为已保存。保存按钮 notification 层点击即 disabled + is-busy（转圈），
        // 这里顺势把「转圈 → 落库成功 → ✓」做成真实进度：转圈期间退出最多
        // 是记录没写进去（列表里不出现，无损），不会再出现「看似已保存、
        // 实际数据缺失/损坏」的中间态。
        try {
          const compressed = container.recorder.getWholeGameCompressed()
          const rule = container.rules.rulename
          const score = Session.getInstance().myScore()
          const ts = new Date()
            .toISOString()
            .replace(/[:.]/g, "-")
            .slice(0, 19)
          const filename = `奥特曼的台球_${rule}_${ts}.bcr`
          const ok = downloadText(filename, compressed, "application/octet-stream")
          saveReplayToDB({
            id: getUID() + "_" + Date.now(),
            rule,
            compressed,
            createdAt: Date.now(),
            score,
            label: `${this.ruleLabel(rule)} · ${score} 分`,
          })
            .then(() => {
              const btn = document.querySelector(
                '[data-notification-action="saveReplay"]'
              ) as HTMLButtonElement | null
              if (btn) {
                // is-busy 的 ::before 是无限转圈（见 v1.5.1 注释），完成时必须移除
                btn.classList.remove("is-busy")
                btn.textContent = ok ? "已保存 ✓" : "已存入回放 ✓"
                btn.disabled = true
                btn.classList.add("is-saved")
              }
            })
            .catch((e) => {
              console.error("saveReplayToDB failed", e)
              const btn = document.querySelector(
                '[data-notification-action="saveReplay"]'
              ) as HTMLButtonElement | null
              if (btn) {
                btn.classList.remove("is-busy")
                btn.textContent = "保存失败"
              }
            })
        } catch (e) {
          console.error("save replay failed", e)
          const btn = document.querySelector(
            '[data-notification-action="saveReplay"]'
          ) as HTMLButtonElement | null
          if (btn) {
            btn.classList.remove("is-busy")
            btn.textContent = "保存失败"
            btn.disabled = true
          }
        }
      },
    }
  }

  private static ruleLabel(rule: string): string {
    const m: Record<string, string> = {
      nineball: "九球",
      eightball: "八球",
      snooker: "斯诺克",
      threecushion: "三颗星",
      sagu: "沙古",
    }
    return m[rule] || rule
  }

  private static notifySpectator(container: Container, subtext: string) {
    container.notifyLocal({
      type: "GameOver",
      title: t("gameOver"),
      subtext: subtext,
      highBreaks: this.getHighBreaks(container),
      icon: "🏆",
      extraClass: "",
      extra: gameOverButtons.lobby,
      duration: 0,
    })
  }

  private static sendLossNotification(container: Container) {
    if (container.isSinglePlayer) return
    const session = Session.getInstance()
    const { p1, p2 } = session.orderedScoresForHud()
    container.sendScoreUpdate(p1, p2, 0)
    container.sendEvent(
      new NotificationEvent({
        type: "GameOver",
        title: t("youLost"),
        icon: "🥈",
        extraClass: "is-loser",
        extra: this.getRemoteGameOverButtons(),
        duration: 0,
      })
    )
  }

  private static sendWinNotification(container: Container) {
    if (container.isSinglePlayer) return
    const session = Session.getInstance()
    const { p1, p2 } = session.orderedScoresForHud()
    container.sendEvent(new ScoreEvent(p1, p2, 0))
    container.sendEvent(
      new NotificationEvent({
        type: "GameOver",
        title: t("youWon"),
        icon: "🏆",
        extraClass: "is-winner",
        extra: this.getRemoteGameOverButtons(),
        duration: 0,
      })
    )
  }

  private static getGameOverButtons(): string {
    // v1.3.65：人机对战时首个按钮显示「继续对战」（系列赛比分已在本局结算时累加）
    return gameOverButtons.forMode(Session.isBotMode())
  }

  /**
   * v1.3.83：局域网对战（远端对手）的结算按钮。
   *
   * 此前一律调 `forMode()` 无参 → 首个按钮是「再来一局」。但局域网同样是
   * 连续对局，局比分会在本局结算时累加，按钮语义与「继续对战」完全一致
   * （用户反馈里也一直称之为「继续对战」）。现按模式分派：人机沿用 forMode
   * 的结果，局域网走新的 forLan()。
   */
  private static getRemoteGameOverButtons(): string {
    if (Session.isSeriesMode() && !Session.isBotMode()) {
      return gameOverButtons.forLan()
    }
    return gameOverButtons.forMode()
  }

  private static calculateInningsStats(container: Container) {
    const entries = container.recorder.entries
    const shots = entries.filter((e) => e.event && e.event.type === "AIM")

    let whiteInnings = 0
    let yellowInnings = 0

    let previousCueBallIndex: number | null = null

    for (const entry of shots) {
      const currentCueBallIndex = (entry.event as any).i ?? 0

      if (currentCueBallIndex !== previousCueBallIndex) {
        if (currentCueBallIndex === 0) {
          whiteInnings++
        } else {
          yellowInnings++
        }
        previousCueBallIndex = currentCueBallIndex
      }
    }

    return {
      whiteInnings,
      yellowInnings,
    }
  }

  private static getScoreSubtext(
    container: Container,
    rulename: string
  ): string {
    if (rulename === "threecushion" || rulename === "sagu") {
      const stats = this.calculateInningsStats(container)
      if (container.isSinglePlayer) {
        const score = Session.getInstance().myScore()
        const totalInnings = stats.whiteInnings + stats.yellowInnings
        const avg =
          totalInnings > 0 ? (score / totalInnings).toFixed(2) : "0.00"
        return `得分：${score}（平均 ${avg}，共 ${totalInnings} 局回合）`
      } else {
        const { p1, p2 } = Session.getInstance().orderedScoresForHud()
        const names = Session.getInstance().orderedNamesForHud()
        const p1Name = names.p1Name || "玩家一"
        const p2Name = names.p2Name || "玩家二"

        const p1Innings = stats.whiteInnings
        const p2Innings = stats.yellowInnings

        const p1Avg = p1Innings > 0 ? (p1 / p1Innings).toFixed(2) : "0.00"
        const p2Avg = p2Innings > 0 ? (p2 / p2Innings).toFixed(2) : "0.00"

        return (
          `${p1Name}：${p1}（平均 ${p1Avg}／${p1Innings} 回合）\n` +
          `${p2Name}：${p2}（平均 ${p2Avg}／${p2Innings} 回合）`
        )
      }
    }

    if (container.isSinglePlayer) {
      return `得分：${Session.getInstance().myScore()}`
    }

    const { p1, p2 } = Session.getInstance().orderedScoresForHud()
    return `${p1} - ${p2}`
  }

  public static getHighBreaks(container: Container): NotificationHighBreak[] {
    return container.ballTray
      .getTopBreaks(3)
      .map(({ score, hiScoreUri }) => ({ score, url: hiScoreUri }))
  }

  private static createMatchResult(
    rulename: string,
    session: Session,
    iWon: boolean
  ): MatchResult {
    const myScore = session.myScore()
    const opponentScore = session.opponentScore()

    const winnerName = iWon
      ? session.playername || "玩家"
      : session.opponentName || "对手"
    const loserName = iWon
      ? session.opponentName || "对手"
      : session.playername || "玩家"
    const winnerScore = iWon ? myScore : opponentScore
    const loserScore = iWon ? opponentScore : myScore

    const result: MatchResult = {
      winner: winnerName,
      winnerClientId: iWon
        ? session.clientId
        : (session.opponentClientId ?? undefined),
      winnerScore: winnerScore,
      ruleType: rulename,
      bot: Session.isBotMode(),
    }

    if (session.opponentName) {
      result.loser = loserName
      result.loserClientId = iWon
        ? (session.opponentClientId ?? undefined)
        : session.clientId
      result.loserScore = loserScore
    }

    result.version = VERSION
    result.userAgent = navigator?.userAgent
    return result
  }
}
