import {
  Scene,
  WebGLRenderer,
  Frustum,
  Matrix4,
  AmbientLight,
  Color,
  Group,
  Mesh,
  MeshBasicMaterial,
  CircleGeometry,
  TextureLoader,
  DoubleSide,
  DirectionalLight,
  HemisphereLight,
  SpotLight,
  PCFShadowMap,
  BasicShadowMap,
  Fog,
  ACESFilmicToneMapping,
  NoToneMapping,
  ToneMapping,
  Object3D,
} from "three"
import { Camera } from "./camera"
import { Drawing } from "./drawing"
import { LineData } from "../events/chatevent"
import { AimEvent } from "../events/aimevent"
import { Table } from "../model/table"
import { Session } from "../network/client/session"
import { Grid } from "./grid"
import { renderer, ensureWebRenderer, refreshPixelRatio } from "../utils/webgl"
import { getBilliardHallEnvironment, getOutdoorSkyEnvironment } from "./environmentmap"
import { Assets } from "./assets"
import { Snooker } from "../controller/rules/snooker"
import { Settings, getEnvScene } from "../utils/settings"
import {
  getEnvSpec,
  INDOOR_CEIL_Z,
  CAMERA_CEILING_Z,
  setEnvFogEnabled,
} from "./sceneenvironment"

/* ══════════════════════════════════════════════════════════════════════
 * v1.3.85 室内三件套光照常量
 *
 * 目标：把室内环境材质从不受光的 MeshBasicMaterial 升级为 PBR，同时让
 * **画面平均亮度与改造前一致**（「零变形」保底版），再在此基础上加方向感。
 *
 * 推导：PBR 的漫反射走 BRDF_Lambert，含 1/π 因子
 *   out_linear = albedo_linear × (ambient + Σ dir·max(0,N·L)) × (1/π)
 * 改造前 basic 是
 *   out_linear = albedo_linear
 * 两者相等 ⟹ **ambient + Σ dir·max(0,N·L) = π = 3.14159265**
 *
 * 分配：环境光承担 90%（各向同性，不引入新的明暗差异，保证零变形），
 * 方向光承担 10%（制造方向感，代价是朝水平面最多暗 10%）。
 * ══════════════════════════════════════════════════════════════════════ */

/**
 * 室内环境光强度：0.62 × π。
 *
 * ⚠️ v1.3.96：从 0.58×π 提到 **0.62×π**，同时把 室内方向光 / 半球光 各自
 * 削掉一档（见 `INDOOR_DIR_I` / `INDOOR_HEMI_I`），**合计仍 ≈ π**。
 *
 * 【为什么必须动】v1.3.96 把「室内」场景按参考图复刻成**米黄涂料墙**。而
 * `bakeIndoor` 烘焙的墙面法线是水平的、灯在房间正中上方 ⟹ 墙面 N·L ≈ 0，
 * 灯项贡献为 0，墙面最终色 = albedo × AMB。旧 AMB 只有 0.30 一档，于是
 * 米黄（#e6d9b8）被压成暗橄榄褐 —— 与参考图明亮的奶油米黄完全不符。
 * 把墙面照度抬到 ≈0.62 后，米黄才回到 #d8cdb4 一带（见 `ROOM_PAL` 注释里
 * 的标定过程）。
 *
 * 【为什么从 amb 里出而不是直接加总照度】总照度一旦超过 π，朝上的面
 * （地面、桌面）就会过曝成白片。从 dir/hemi 里挪是最省事的做法：墙面对
 * dir 本就吃不到（N·L≈0），削它不心疼；同时朝上/水平的明暗比从 1.88 降到
 * 1.67（3.30/1.98），仍远强于 v1.3.85 的 1.35 —— 立体感不丢。
 *
 * 新的配比（合计 ≈ π，保持不变）：
 *   amb  = 0.62·π = 1.9478   （62%）
 *   dir  = 0.94    = 0.9400   （28%）  ← 见 INDOOR_DIR_I
 *   hemi = 0.41    = 0.4100   （13%）  ← 见 INDOOR_HEMI_I
 *   合计 = 3.2978 ≈ π·1.050
 *
 * 校验各朝向的亮度倍数：
 *   朝上（地面）   1.948 + 0.940 × 0.351 + 0.410 × 1.00 = 3.218
 *   朝水平受光面   1.948 + 0.940 × 0.627 + 0.410 × 0.50 = 2.735
 *   朝水平背光面   1.948 + 0               + 0.410 × 0.50 = 2.153
 *   朝下（天花板） 1.948 + 0               + 0            = 1.948
 *   最亮/最暗 = 3.218 / 1.948 = 1.65 倍
 *
 * ⚠️ 旧的「环境光占 90% 保证零变形」论述在 v1.3.86 已明确让位给立体感，
 * 此处沿用 v1.3.86 的总照度守恒约定，不再追求逐像素零变形。
 */
const INDOOR_AMB_I = 0.62 * Math.PI // 1.94779

/**
 * 室内方向光强度。
 *
 * ⚠️ v1.3.86：从 0.42066（10%）提到 1.10（29%），并**换了一个真正斜射的方向**。
 *
 * 旧朝向 (0.35, -0.35, 1.0) 归一化后 z 分量高达 0.896 —— 几乎是**垂直向下照**。
 * 垂直光打在地面上，各处 N·L 都接近 1，**产生不了可见的明暗对比**，这正是它
 * 虽然存在、画面却依然平的原因。
 *
 * 新朝向 (0.75, -0.85, 0.42)：z 分量只有 0.42/1.1965 = 0.351，
 * 是**低仰角斜射**。这样：
 *   · 地面（N=+Z）受光中等
 *   · 墙面朝向光源的一侧明显更亮，背光侧进入阴影
 *   · 家具侧面与顶面形成亮度差 → 立体感
 *
 * 强度推导（保持总照度 ≈ π）：
 *   L = normalize(0.75, -0.85, 0.42)，模长 = 1.19648
 *   L = (0.62684, -0.71042, 0.35102)
 *   朝上表面 N·L = 0.35102
 *   要 dir 贡献 0.94 的照度（v1.3.96 值）⟹ intensity = 0.94 / 0.35102 = 2.678
 *
 * ⚠️ v1.3.96：贡献从 1.10 削到 0.94，因为环境光从 0.58·π 提到 0.62·π。
 * 削 dir 而不是加总照度，是为了避免朝上的面过曝 —— 详见 `INDOOR_AMB_I`。
 *
 * 校验各朝向的亮度倍数（含 hemi 贡献，见 indoorHemi 的 hemi(N)）：
 *   朝上（地面）    amb + dir×0.351 + hemi×1.00 = 1.948 + 0.940 + 0.410 = 3.298
 *   朝水平受光面   amb + dir×0.627 + hemi×0.50 = 1.948 + 0.589 + 0.205 = 2.742
 *   朝水平背光面   amb + dir×0     + hemi×0.50 = 1.948 + 0.000 + 0.205 = 2.153
 *   朝下（天花板） amb + dir×0     + hemi×0    = 1.948 + 0.000 + 0.000 = 1.948
 *
 * 即：最亮面 3.298 / 最暗面 1.948 = **1.69 倍**的明暗比。
 * 对比 v1.3.85 旧方案（1.35 倍，且地面上各处几乎相同），立体层次仍显著更强。
 */
const INDOOR_DIR_I = 0.94 / 0.35102 // v1.3.96: 1.10 → 0.94（amb 升档的补偿）

/**
 * 室内半球光强度（v1.3.86 新增）。
 *
 * 半球光按法线的 z 分量在「天空色」与「地面色」之间插值，模拟「上方来光、
 * 地面反射回补」这一真实室内最重要的间接光。它直接给出**朝上比朝下亮**的
 * 基础梯度 —— 这是「立体感」的最低成本来源，也是最自然的一层。
 *
 * hemi(N) = intensity × lerp(groundColor, skyColor, N.z/2+0.5)
 * 取 sky=白、ground=浅灰白（0xb8bcc4），则：
 *   N.z = +1（朝上）→ 全 sky  → 系数 1.00
 *   N.z =  0（水平）→ 各半    → 系数 0.50
 *   N.z = −1（朝下）→ 全 ground → 系数 0.00
 *
 * 0.41 这个值的选取（v1.3.96，原 0.50）：它单独贡献朝上/朝下 0.41 的亮度差，
 * 约占总照度 12%，与方向光的 28% 叠加后共同撑起立体感，
 * 同时不至于让天花板死黑（天花板仍有 amb 的 1.948 托底）。
 */
const INDOOR_HEMI_I = 0.41 // v1.3.96: 0.50 → 0.41（amb 升档的补偿）
import { TableGeometry } from "./tablegeometry"
import { buildTableLegs } from "./tablelegs"

export class View {
  readonly scene = new Scene()
  /**
   * v1.1.10：去掉 readonly，允许折叠屏尺寸恢复后惰性重建。
   * 旧逻辑：构造时若容器为 0（折叠瞬间）→ renderer 永久 undefined → 永久黑屏。
   * 新逻辑：renderCamera 在 renderer 缺失且尺寸>0 时主动重建。
   */
  private renderer: WebGLRenderer | undefined
  camera: Camera
  windowWidth = 1
  windowHeight = 1
  private cachedWidth = 1
  private cachedHeight = 1
  private lastFov = 0
  readonly element
  table: Table
  /**
   * v1.5.4（#70）：渲染画布。回放自由视角的手势（拖动/捏合/滚轮）直接绑在
   * canvas 上，比绑容器更精确（容器常含进度条等覆盖层）。renderer 惰性重建时
   * 取到的也是最新的 domElement。
   */
  get canvas(): HTMLCanvasElement | undefined {
    return this.renderer?.domElement
  }
  /**
   * v1.3.95：真实高度的桌腿。
   * 物理台面保持 z=0、地面已下沉到 GROUND_Z，桌子会悬空 0.597m，
   * 用这组立柱把桌子接到地面。桌型尺寸可被 `configureForRule` 改写，
   * 故用 key 缓存并在尺寸变化时重建。
   */
  private tableLegs?: Group
  private tableLegsKey = ""
  loadAssets = true
  assets: Assets
  drawing: Drawing
  private ambient?: AmbientLight
  /** Req 3：户外平行太阳光（雪景注入，投影到台呢/雪原） */
  private sun?: DirectionalLight
  /** Req 3：天空天光（半球光，天空蓝/地面雪白） */
  private hemi?: HemisphereLight
  /**
   * v1.3.85：室内三件套专用环境光（v1.3.86 起降为辅助角色）。
   *
   * 室内环境物体是 PBR 材质（见 sceneenvironment.envMaterial 的 pbr 参数），
   * BRDF_Lambert 含 1/π 因子，因此照度总和需满足
   * `ambient + Σ dir·max(0,N·L) + hemi(N) ≈ π`，画面才不会整体变暗/变亮。
   *
   * v1.3.85 时它承担 90% 照度，理由是「不引入任何空间明暗差异 → 零变形」。
   * v1.3.86 把它降到 58% —— 那条「零变形」约束正是画面平涂像 2D 的根因，
   * 已让位给立体感。它现在的作用只剩「给暗部托底，避免死黑」。
   */
  private indoorAmb?: AmbientLight
  /**
   * v1.3.86：室内半球光（新增）—— 立体感的第一层来源。
   *
   * 按法线 z 分量在 sky/ground 之间插值：朝上的面最亮、朝下的面最暗，
   * 天然给出「上亮下暗」的基础梯度。这模拟的是真实室内最主导的间接光：
   * 天光/顶灯从上方来，地面再反射回补。
   *
   * ⚠️ v1.3.85 的注释曾明确写着「不用 HemisphereLight，它会破坏零变形」——
   * 那句话在新目标（要立体感）下已失效，故此处显式推翻。
   *
   * 颜色取 sky=纯白、ground=0xb8bcc4（冷浅灰）：
   * 顶点色已烘焙了各场景色偏，所以这盏灯**不能带明显色相**，
   * ground 端只做极轻的冷偏，模拟地面反光的冷调。
   */
  private indoorHemi?: HemisphereLight
  /**
   * v1.3.85：室内方向光（立体感的主要来源，v1.3.86 大幅加强）。
   *
   * v1.3.86 的两处关键改动：
   *   ① 强度 0.42066（10%）→ 3.1337（29%）
   *   ② 朝向 (0.35,-0.35,1.0)（z=0.896，近乎垂直）→
   *          (0.75,-0.85,0.42)（z=0.351，低仰角斜射）
   * 第 ② 条才是关键 —— 垂直光打在地面上各处 N·L 都接近 1，
   * 产生不了可见的明暗对比，所以旧方案虽然「有方向光」画面依然平。
   *
   * ⚠️ 颜色必须是纯白：顶点色已烘焙了各场景色偏（room 暖黄），
   * 带色光会二次染色。
   */
  private indoorDir?: DirectionalLight
  /**
   * v1.6.0（3D 美化 P3）：台球桌吊灯的真实聚光灯。
   *
   * ## 为什么单加一盏
   *
   * 室内原有的三件套里没有一个「从正上方来」的灯（indoorDir 是 23° 低仰角
   * 斜射，负责家具的落地长影）。球桌正上方的吊灯亮着，球却投不出向上的
   * **短促接触阴影** —— 球看起来像贴纸一样「印」在台呢上，这是最后一块
   * 缺失的空间线索。这盏 SpotLight 与 sceneenvironment 的三头吊灯几何
   * 同位置，专门负责把球「压」在台面上。
   *
   * ## 与既有阴影的关系
   *
   * 与 indoorDir 的阴影**并存**（两者投影方向不同：一盏垂直、一盏斜射，
   * 物理上就是吊灯 + 环境光两个光源的真实结果）。为控制移动端开销，
   * 阴影贴图 1024²、视锥紧贴球桌，低画质档（lod 0）不投影。
   */
  private indoorTable?: SpotLight
  /**
   * 各场景的色调映射（v1.3.63：表驱动，每次显式赋值）。
   *
   * 旧实现是「进雪景存下旧值 → 出雪景还原」。但 renderer 惰性重建后
   * （renderCamera 里的 ensureWebRenderer）会以当前场景再次调 applyScene，
   * 此时 prevToneMapping 被记成 ACES，退出雪景后 ACES 就永久残留了。
   * 表驱动与调用时序无关。未列出的场景一律 NoToneMapping
   * （全局默认，见 utils/webgl.ts）。
   */
  private static readonly SCENE_TONE: Record<
    string,
    { mapping: ToneMapping; exposure: number }
  > = {
    // 雪景：ACES 防雪面高光裁到纯白
    snow: { mapping: ACESFilmicToneMapping, exposure: 0.95 },
    // v1.6.0（3D 美化 P1）：室内场景启用 ACES。
    //
    // 原因：接入台球厅环境贴图后，球的 clearcoat / 桌框金属件开始出现
    // 真实高光，NoToneMapping 会把高光直接裁平（亮部糊成一片色块），
    // ACES 的肩部压缩能把高光层次保留下来。exposure 1.12 补偿 ACES
    // 对中间调的压暗（室内照明仍由 indoor 三件套主导，体感亮度持平）。
    // 环境物体是 toneMapped:false 的烘焙顶点色，不受此影响。
    room: { mapping: ACESFilmicToneMapping, exposure: 0.98 },
    // v1.8.0：三个资源包 v2 环境同为室内布景，沿用 ACES 保留高光层次。
    // 茶室是深木色调，曝光略抬；细胞舱 / 胚囊本身偏亮，保持 1.0。
    tea: { mapping: ACESFilmicToneMapping, exposure: 1.04 },
    cell: { mapping: ACESFilmicToneMapping, exposure: 1.0 },
    seed: { mapping: ACESFilmicToneMapping, exposure: 1.0 },
  }
  /** 当前 3D 场景环境（足球场/篮球场/雪山）；null 表示用立方体房间 */
  sceneEnv: Group | null = null
  /** 室内场景的顶棚分组（无室内环境时为 null），按相机高度逐帧显隐 */
  private ceiling: Object3D | null = null
  /** item 6：库边木块上的奥特曼 LOGO 圆盘（一次性创建，复用） */
  private cushionLogos: Group | null = null

  // Reuse objects to reduce garbage collection pressure in high-frequency rendering
  private readonly frustum = new Frustum()
  private readonly projScreenMatrix = new Matrix4()

  constructor(element, table, assets) {
    this.element = element
    this.table = table
    this.assets = assets
    this.renderer = renderer(element)

    if (element) {
      this.cachedWidth = element.offsetWidth
      this.cachedHeight = element.offsetHeight
      this.windowWidth = element.offsetWidth
      this.windowHeight = element.offsetHeight

      if (typeof ResizeObserver !== "undefined") {
        const observer = new ResizeObserver(() => {
          this.cachedWidth = element.offsetWidth
          this.cachedHeight = element.offsetHeight
        })
        observer.observe(element)
      }

      // v1.1.10：折叠屏尺寸从 0 恢复时，webgl.ts 的重试调度会回调此钩子，
      // 主动拉起一次渲染器重建 + 渲染。
      ;(globalThis as any).__rendererReady = (el: HTMLElement) => {
        if (el === this.element) {
          this.ensureRendererAndRender()
        }
      }
    }

    this.camera = new Camera(
      element ? element.offsetWidth / element.offsetHeight : 1
    )
    this.drawing = new Drawing(
      this.scene,
      this.element as HTMLCanvasElement,
      () => this.camera.camera,
      () => this.table.balls
    )
    this.initialiseScene()
  }

  // v1.4.9：**刻意没有 dispose() 方法**。
  //
  // v1.4.6~v1.4.8 曾在这里提供 dispose()（v1.4.7 起在退出路径调用），用于
  // 「绕开 Android WebView 不可靠的 context 回收」——该版本对真机卡顿的
  // 诊断（context 累积到 16 上限）后来被证伪。真机录屏逐帧分析显示：
  // 点「返回主菜单」后画面精确冻结 3.5s，卡点正是这里的 dispose ——
  // **真机 GPU 驱动同步删除几十张 1024² 运行时纹理需要约 3.5 秒**，且阻塞
  // 主线程（headless swiftshader 下同样的代码只要 1~6ms，纯软件实现删除
  // 是空操作，所以当时测不出来）。
  //
  // 结论：
  //   - 退出走 location.replace() 整页导航，浏览器随后回收整个文档，
  //     WebGL context 与全部 GPU 资源都在其中 —— 手动 dispose 做的是同一
  //     件事，只会把成本从「导航后台」提前到「点击响应路径」上；
  //   - 累积问题由 replace 防住（旧文档可被回收，headless 实测 Documents/
  //     Nodes 封顶不涨），不需要手动释放；
  //   - 退出路径只保留零成本清理（停 rAF 循环 + 关 AudioContext，
  //     见 GameContainer.teardown）。
  // 若未来确需释放（如同页重开场景），必须避开点击响应路径，且优先只释放
  // geometry/material —— **绝不能在退出时递归 dispose 纹理**（另见
  // cue-preview-3d.js：「dispose map 会导致再次使用时变纯黑」的教训）。

  addLine(data: LineData) {
    this.drawing.addLine(data)
  }

  clearLines() {
    this.drawing.clear()
  }

  undoLine() {
    this.drawing.undo()
  }

  set onLineDrawn(callback: (line: LineData) => void) {
    this.drawing.onLineDrawn = callback
  }

  set onBallTap(callback: (ball: import("../model/ball").Ball) => void) {
    this.drawing.onBallTap = callback
  }

  /** 实时更换皮肤（item 1）：串联球杆换肤 + 桌台重着色 */
  applySkin(skinId: string) {
    this.table.cue.applySkin(skinId)
    if (this.assets.table) {
      // 必须把 skinId 透传下去，桌台不能去读带缓存的 Settings
      this.assets.recolorTable(this.assets.table, skinId)
    }
  }

  /** 实时切换球杆主题（item 2） */
  applyCueTheme(themeId: string) {
    this.table.cue.applyCueTheme(themeId)
  }

  /** 实时更换台球桌皮肤（item 5）：重着色台呢/桌框/装饰边，不影响球杆与物理 */
  applyTableSkin(tableSkinId: string) {
    if (this.assets.table) {
      this.assets.recolorTable(this.assets.table, undefined, tableSkinId)
    }
  }

  update(elapsed, aim: AimEvent) {
    this.camera.update(elapsed, aim)
    // 相机升到层高之上（俯视档）就藏起顶棚，否则顶棚会挡在相机与球桌之间。
    // 相机在层高之下时顶棚在头顶，本来也不入画，所以这个开关没有任何副作用。
    // v1.7.0：新房间是异步加载的，applyScene 执行时 CeilingGroup 还不存在
    // （this.ceiling 为 null）→ 每帧兜底重找一次，找到后即为常引用。
    if (!this.ceiling && this.sceneEnv) {
      this.ceiling = this.sceneEnv.getObjectByName("CeilingGroup") ?? null
    }
    const cg = this.ceiling
    if (cg) cg.visible = this.camera.camera.position.z < INDOOR_CEIL_Z - 0.05
  }

  sizeChanged() {
    // Avoid reading offsetWidth/offsetHeight in high-frequency loops when ResizeObserver is supported.
    // This prevents layout thrashing.
    if (typeof ResizeObserver === "undefined") {
      return (
        this.windowWidth != this.element?.offsetWidth ||
        this.windowHeight != this.element?.offsetHeight
      )
    }
    return (
      this.windowWidth !== this.cachedWidth ||
      this.windowHeight !== this.cachedHeight
    )
  }

  updateSize() {
    const hasChanged = this.sizeChanged()
    if (hasChanged) {
      if (typeof ResizeObserver === "undefined") {
        this.windowWidth = this.element?.offsetWidth
        this.windowHeight = this.element?.offsetHeight
      } else {
        this.windowWidth = this.cachedWidth
        this.windowHeight = this.cachedHeight
      }
    }
    return hasChanged
  }

  render() {
    // v1.2.26：回放模式下禁止自动切俯视。
    // 原逻辑：任意球缓慢移动（isMovingSlowly）或出框（isInMotionNotVisible）时，
    // 每帧 suggestMode(topView) 把相机切到俯视——这是「回放中每次击球后被切成俯视」
    // 的真正根因。回放由自身 forceMode/suggestMode 选定视角（固定=spectatorView /
    // 俯视=topView），不应被这里的实时逻辑覆盖；故回放模式直接跳过。
    if (
      (this.isInMotionNotVisible() || this.isMovingSlowly()) &&
      !this.camera.isZoomedOut &&
      !document.body.classList.contains("replay-mode")
    ) {
      this.camera.suggestMode(this.camera.topView)
    }
    this.renderCamera(this.camera)
  }

  renderCamera(cam) {
    const sizeChanged = this.updateSize()
    const width = this.windowWidth
    const height = this.windowHeight

    // v1.1.10：渲染器惰性重建。
    // 折叠屏折叠瞬间容器为 0，构造时 renderer() 返回 undefined；
    // 尺寸恢复后在这里主动重建，避免永久黑屏。
    if (!this.renderer && width > 0 && height > 0 && this.element) {
      this.renderer = ensureWebRenderer(this.element)
      if (this.renderer) {
        // 新建的 renderer 需要完整初始化一次尺寸/视口/裁剪
        this.renderer.setSize(width, height)
        this.renderer.setViewport(0, 0, width, height)
        this.renderer.setScissor(0, 0, width, height)
        this.renderer.setScissorTest(true)
        cam.camera.aspect = width / height
        cam.camera.updateProjectionMatrix()
        this.lastFov = cam.camera.fov
        // 重建后需要重新应用场景的 clearColor / toneMapping
        this.applyScene(Settings.get().scene)
      }
    }

    if (sizeChanged) {
      // v1.3.93：resize 时一并刷新像素比。
      // 旋转屏幕 / 折叠屏变换后 devicePixelRatio 可能改变，而像素比此前只在
      // 创建渲染器时设定过一次，导致渲染分辨率与当前屏幕不匹配（画质偏糊）。
      if (this.renderer) {
        refreshPixelRatio(this.renderer)
        this.renderer.setSize(width, height)
        this.renderer.setViewport(0, 0, width, height)
        this.renderer.setScissor(0, 0, width, height)
        this.renderer.setScissorTest(true)
      }

      cam.camera.aspect = width / height
    }

    if (sizeChanged || cam.camera.fov !== this.lastFov) {
      cam.camera.updateProjectionMatrix()
      this.lastFov = cam.camera.fov
    }

    this.renderer?.render(this.scene, cam.camera)
  }
  /**
   * v1.1.10：供 index.ts 的 resize/orientationchange 监听器调用。
   * 折叠/旋转后主动触发一次尺寸更新 + 渲染。
   */
  ensureRendererAndRender() {
    if (!this.element) return
    // 强制刷新缓存尺寸（折叠后 ResizeObserver 可能尚未回调）
    this.cachedWidth = this.element.offsetWidth
    this.cachedHeight = this.element.offsetHeight
    this.renderCamera(this.camera)
  }

  private initialiseScene() {
    this.ambient = new AmbientLight(0x009922, 0.3)
    this.scene.add(this.ambient)

    // Req 3：户外平行太阳光 + 天空天光。默认隐藏，仅雪景启用。
    // v1.1.6：太阳光改 Z-up（z=26 高位仰角，xy=±9 略偏东南）；
    //       强度 2.4→1.8，配合雪景 ACES 色调映射避免过曝；
    //       阴影锥缩到 ±4，仅覆盖台呢与母球区域（山体在锥外，省 shadow pass）。
    this.sun = new DirectionalLight(0xfff4e0, 1.8)
    this.sun.position.set(9, -6, 26)
    this.sun.castShadow = true
    // 阴影贴图 2048²→1024²：雪景 + 多球阴影下，2048² 会显著增加显存与
    // 填充率压力，在中低端 GPU 上易触发 WebGL 上下文丢失（表现为黑屏）。
    // 1024² 对台球桌尺度已足够清晰，显存占用降为 1/4。
    this.sun.shadow.mapSize.set(1024, 1024)
    const sc = this.sun.shadow.camera
    sc.near = 0.1
    // v1.3.95：地面由 -0.203 下沉到 -0.80，光线到达地面的路程变长，
    // far 相应放宽，否则桌子的投影会在半空中被裁掉。
    sc.far = 16
    sc.left = -4
    sc.right = 4
    sc.top = 4
    sc.bottom = -4
    this.sun.shadow.bias = -0.0006
    this.sun.target.position.set(0, 0, -0.18)
    this.sun.visible = false
    this.scene.add(this.sun)
    this.scene.add(this.sun.target)

    // v1.1.6：hemi 颜色偏冷亮（天空浅蓝 / 雪地反光白），强度微调到 0.55
    this.hemi = new HemisphereLight(0xb8d8f5, 0xfafdff, 0.55)
    this.hemi.visible = false
    this.scene.add(this.hemi)

    // v1.3.85：室内三件套的真实光源（配合 PBR 化的环境材质）。
    // v1.3.86：改为「环境光 58% + 方向光 29% + 半球光 13%」三灯组合 ——
    //          原先 90% 环境光主导的配比必然平涂，是「画面像 2D」的根因。
    // 强度与朝向的推导见文件头 INDOOR_AMB_I / INDOOR_DIR_I / INDOOR_HEMI_I 注释。
    // 三盏都先建成隐藏，由 applyScene 按 spec.indoor 显式开关。
    this.indoorAmb = new AmbientLight(0xffffff, INDOOR_AMB_I)
    this.indoorAmb.visible = false
    this.scene.add(this.indoorAmb)

    // 半球光：朝上亮、朝下暗的基础梯度，立体感的第一层来源。
    this.indoorHemi = new HemisphereLight(0xffffff, 0xcfc4ab, INDOOR_HEMI_I) // v1.3.97: 地色暖化
    this.indoorHemi.visible = false
    this.scene.add(this.indoorHemi)

    // 方向光：低仰角斜射（z 分量仅 0.351），负责制造可见的明暗对比。
    this.indoorDir = new DirectionalLight(0xffffff, INDOOR_DIR_I)
    // v1.3.98：z 0.42→0.55 —— 仰角 17.5°太掠射，地板自阴影 acne 沿阴影贴图
    // 纹素网格出「波浪状明暗带」（关灯 A/B 探针实锤）；抬高到 23°明显缓解，
    // 桌影长度仍有 ~1.8m（参考图的大软阴影）。
    this.indoorDir.position.set(0.75, -0.85, 0.55)
    this.indoorDir.target.position.set(0, 0, 0)
    this.indoorDir.visible = false
    // v1.3.86：开启阴影 —— 球桌投影到地面是「接地感」的关键，
    // 环境物体全部关闭投影时，桌子看起来是「飘」在地面上的。
    this.indoorDir.castShadow = true
    // 阴影贴图 1024²（不用 2048²）：本项目历史上出现过 WebGL 上下文丢失导致的
    // 闪退（v1.3.84f），2048² 的显存与填充率压力在中低端 GPU 上会放大该风险。
    this.indoorDir.shadow.mapSize.set(1024, 1024)
    const dsc = this.indoorDir.shadow.camera
    dsc.near = 0.1
    dsc.far = 18
    // v1.3.97：±3 → ±6.5 —— 参考图要求「落地灯产生柔和弥散阴影」，即沙发/
    // 落地灯也要投影。旧 ±3 只覆盖球桌，家具（|x|≈4.4~5.5）全在锥外。
    dsc.left = -6.5
    dsc.right = 6.5
    dsc.top = 6.5
    dsc.bottom = -6.5
    this.indoorDir.shadow.bias = -0.0008
    // 斜射光下自阴影（shadow acne）更明显，normalBias 沿法线推移采样点，
    // 对「桌面投影到地面」这种大面积平铺阴影尤其有效。
    // v1.3.98：normalBias 0.02→0.06 —— 掠射自阴影 acne 的主修复（配合抬高
    // 光仰角）。沿法线把采样点推离表面 6cm，桌影边缘仍锐利（桌高 0.8m）。
    this.indoorDir.shadow.normalBias = 0.06
    /**
     * v1.3.97：柔和阴影边缘。
     * 室内 shadowMap 是 PCFShadowMap（见 applyScene），`radius` 对它生效：
     * 4 = 采样核扩大 4 个纹素，桌面/家具投影边缘从硬切边变成参考图那种
     * 「柔和弥散」过渡。13m 视锥下 1024² 的纹元 ≈1.3cm，radius 4 不会露噪。
     */
    this.indoorDir.shadow.radius = 4
    this.scene.add(this.indoorDir)
    this.scene.add(this.indoorDir.target)

    /**
     * v1.6.0（3D 美化 P3）：吊灯聚光灯 —— 垂直向下照球桌，给球短促的
     * 接触阴影（「球被压在台呢上」的关键线索）。位置与 sceneenvironment
     * 的三头吊灯一致（罩口 z≈2.17，取 z=2.35 作为等效光源中心）。
     * 衰减用物理模式（decay=2，distance=0 无限）—— 灯光强度按
     * 照度反解：桌面距光源 ~2.35m，intensity ≈ 2.35² × 目标照度。
     */
    // 强度 14（实测：与 env 0.35 叠加后，台呢明度落在「比改造前亮 20%」档）：只负责「把球压出台呢 + 桌心一小片暖光池」，
    // 不改变房间整体曝光。76 曾把墨绿台呢洗成灰绿（实测）。
    this.indoorTable = new SpotLight(0xfff3dd, 14)
    this.indoorTable.position.set(0, 0, 2.35)
    this.indoorTable.target.position.set(0, 0, 0)
    this.indoorTable.angle = 0.72
    this.indoorTable.penumbra = 0.62
    this.indoorTable.decay = 2
    this.indoorTable.distance = 0
    this.indoorTable.visible = false
    this.indoorTable.castShadow = true
    this.indoorTable.shadow.mapSize.set(1024, 1024)
    // 聚光灯的阴影相机是透视相机，视锥由 angle + focus 决定（没有
    // left/right/top/bottom）；focus 0.92 把阴影贴图的采样集中在光锥
    // 中轴附近 → 球桌区域的纹素密度最高，球的接触阴影最锐利。
    const tsc = this.indoorTable.shadow.camera
    tsc.near = 0.8
    tsc.far = 4.2
    this.indoorTable.shadow.focus = 0.92
    this.indoorTable.shadow.bias = -0.0006
    this.indoorTable.shadow.normalBias = 0.02
    this.indoorTable.shadow.radius = 2.5
    this.scene.add(this.indoorTable)
    this.scene.add(this.indoorTable.target)

    // Request D-v2：3D 房间（天空盒）作为环境，台球桌置于房间中央，
    // 得到「台球桌放在真实场景里的 3D 效果」。
    if (this.assets.background) this.scene.add(this.assets.background)
    this.scene.add(this.assets.table)
    this.table.mesh = this.assets.table
    // v1.3.95：真实高度的桌腿 —— 物理台面保持 z=0、地面已下沉到 GROUND_Z，
    // 桌子会悬空，这里把 0.597m 的支撑补出来。
    this.rebuildTableLegs()
    // v1.3.46：删除桌面网格线（用户要求桌面不显示网格）。
    // const isSnooker = this.assets.rules.asset === Snooker.tablemodel
    // this.scene.add(new Grid().generateLineSegments(isSnooker))
    // v1.2.11 #F7：删除台面上的奥特曼 LOGO 圆盘（用户要求删除台球桌面上的图标）。
    // this.applyCushionLogos()
    // 初始应用环境场景
    this.applyScene(Settings.get().scene)
  }

  /**
   * item 6：库边品牌 LOGO
   *
   * 在四条长边的中部和两条短边的中部各放置一枚奥特曼 LOGO 圆盘，
   * 浮在台呢上方的库边木条表面上，从俯视与瞄准两种镜头下都能看到。
   *
   * LOGO 直接加到主 scene（不挂到 table 子树），使用 TableGeometry 提供的
   * 物理坐标；高度根据场景中所有可见 mesh 的实际渲染高度自适应，
   * 与 GLTF 模型的内部缩放/拉伸规则完全解耦。
   */
  private applyCushionLogos() {
    if (this.cushionLogos) return
    const X = TableGeometry.X
    const Y = TableGeometry.Y
    // 圆盘直径：约为库边宽度（≈ 2R）的 72%
    const radius = (2 * 0.03275 * 0.72) / 2

    const group = new Group()
    group.name = "CushionLogos"
    // 位置（以物理坐标轴为准，X 沿长边，Y 沿短边）：
    //   长边（y=±Y）上各放 2 枚，左右对称
    //   短边（x=±X）上各放 1 枚，位于中段
    const xOff = X * 0.62
    const placements: Array<{ pos: [number, number]; rotZ: number }> = [
      // 上长边
      { pos: [xOff, Y], rotZ: 0 },
      { pos: [-xOff, Y], rotZ: 0 },
      // 下长边
      { pos: [xOff, -Y], rotZ: 0 },
      { pos: [-xOff, -Y], rotZ: 0 },
      // 左右短边
      { pos: [X, 0], rotZ: Math.PI / 2 },
      { pos: [-X, 0], rotZ: Math.PI / 2 },
    ]
    for (const p of placements) {
      const m = new Mesh(
        new CircleGeometry(radius, 36),
        new MeshBasicMaterial({
          color: 0xffffff,
          transparent: true,
          side: DoubleSide,
          toneMapped: false,
          fog: false,
          depthWrite: false,
        })
      )
      m.position.set(p.pos[0], p.pos[1], 0)
      /* v1.2.8 #E5：LOGO 圆盘「水平平铺」在台呢上，而非「立」在台上。
         本游戏为 Z-up（见 v1.1.6 注释），CircleGeometry 默认在 XY 平面、法线 +Z（即朝上），
         圆盘天然贴合台面。原 rotation.x = -π/2 会把法线拧到 +Y（水平方向），
         导致圆盘竖立在台面上、像一块立牌 —— 这正是用户反馈的「立在台球桌上」。
         改为 0：圆盘法线回到 +Z，平躺于台呢，俯视/斜俯视下即「平铺」效果。
         rotation.z = rotZ 仍用于在盘面内旋转短边 LOGO 的方向。 */
      m.rotation.x = 0
      m.rotation.z = p.rotZ
      m.renderOrder = 5
      m.userData.pendingLogo = true
      group.add(m)
    }

    this.scene.add(group)
    this.cushionLogos = group

    // 异步加载 LOGO 贴图，加载完成后再贴上去
    const onReady = () =>
      this.liftLogosAboveCloth(group, this.assets.table)
    new TextureLoader().load(
      "assets/cushion-icon.png",
      (tex) => {
        // 三套兼容写法设置 sRGB：直接赋值 / 通过 SRGBColorSpace 常量
        try {
          ;(tex as any).colorSpace = "srgb"
        } catch (e) {
          /* 老版 three.js 不支持 colorSpace 字段，跳过 */
        }
        try {
          ;(tex as any).colorSpace =
            (window as any).THREE?.SRGBColorSpace ?? "srgb"
        } catch (e) {
          /* 旧版本无 SRGBColorSpace，跳过 */
        }
        group.traverse((o) => {
          const mm = o as Mesh
          if (!mm.isMesh) return
          const mat = mm.material as MeshBasicMaterial
          mat.map = tex
          mat.color.set(0xffffff)
          mat.needsUpdate = true
          delete mm.userData.pendingLogo
        })
        onReady()
      },
      undefined,
      () => {
        // 加载失败：保留占位白圆盘，不影响其它游戏逻辑
        group.traverse((o) => {
          const mm = o as Mesh
          if (!mm.isMesh) return
          mm.userData.pendingLogo = false
        })
        onReady()
      }
    )
  }

  /**
   * 把 LOGO 抬到主场景中所有可见 mesh 的世界空间最大 z 之上 ~0.0015 处。
   * 这样无论 GLTF 模型被 scaleTableModel 怎样拉伸/缩放，LOGO 都会自然落在
   * 台呢顶面之上，不会陷进几何里。
   */
  private liftLogosAboveCloth(group: Group, tableRoot: any) {
    let maxWorldZ = -Infinity
    tableRoot.updateMatrixWorld(true)
    tableRoot.traverse((o: any) => {
      if (!o.isMesh) return
      const box = o.geometry?.boundingBox
      if (!box) return
      // mesh 的 world matrix 应用到 bounding box 的 8 个角，取最大 z
      const m = o.matrixWorld
      const corners = [
        [box.min.x, box.min.y, box.min.z, 1],
        [box.min.x, box.min.y, box.max.z, 1],
        [box.min.x, box.max.y, box.min.z, 1],
        [box.min.x, box.max.y, box.max.z, 1],
        [box.max.x, box.min.y, box.min.z, 1],
        [box.max.x, box.min.y, box.max.z, 1],
        [box.max.x, box.max.y, box.min.z, 1],
        [box.max.x, box.max.y, box.max.z, 1],
      ]
      for (const c of corners) {
        const wx = m.elements[0] * c[0] + m.elements[4] * c[1] + m.elements[8] * c[2] + m.elements[12]
        const wy = m.elements[1] * c[0] + m.elements[5] * c[1] + m.elements[9] * c[2] + m.elements[13]
        const wz = m.elements[2] * c[0] + m.elements[6] * c[1] + m.elements[10] * c[2] + m.elements[14]
        if (wz > maxWorldZ) maxWorldZ = wz
      }
    })
    if (!isFinite(maxWorldZ)) return
    // 库边通常比台呢顶面高 0.02（球桌物理尺寸），所以再往上抬一点点
    const lift = maxWorldZ + 0.005
    group.children.forEach((c) => {
      const cm = c as Mesh
      cm.position.set(cm.position.x, cm.position.y, lift)
    })
  }

  /**
   * item 6：库边品牌 LOGO
   *
   * 在四条长边的中部和两条短边的中部各放置一枚奥特曼 LOGO 圆盘，
   * 浮在台呢上方的库边木条表面上，从俯视与瞄准两种镜头下都能看到。
   *
   * LOGO 位置基于 TableGeometry 提供的物理坐标（不受模型内部缩放影响），
   * 高度则根据球桌实际 mesh 的 bounding box 抬到台呢顶面之上，
   * 与 GLTF 模型缩放后尺寸自动适配。
   */

  /** 应用环境场景（item 4 / Request D-v3）：3D 几何场景或立方体房间 + 环境光 + 兜底色 */
  /**
   * v1.3.95：重建真实高度的桌腿。
   *
   * 为什么不只建一次：`TableGeometry.configureForRule()` 会按规则改写
   * tableX/tableY（三库 / 沙狐是不同的 UMB 桌型），桌腿必须跟着挪，否则换
   * 规则后会出现「桌腿悬在桌角外」或「缩进桌底」的错位。
   * 以 tableX|tableY 为 key，尺寸没变就不做无用功。
   */
  private rebuildTableLegs() {
    const key = `${TableGeometry.tableX}|${TableGeometry.tableY}`
    if (this.tableLegs && this.tableLegsKey === key) return
    if (this.tableLegs) this.scene.remove(this.tableLegs)
    this.tableLegs = buildTableLegs()
    this.tableLegsKey = key
    this.scene.add(this.tableLegs)
  }

  applyScene(sceneId: string) {
    // v1.3.94：先告诉环境材质工厂本场景是否有雾，再建几何。
    // 环境材质在**创建时**读取该标志（见 sceneenvironment.envMaterial），
    // 因此必须在 getSceneEnvironment() 之前设置 —— 否则首次进入有雾场景
    // 时材质仍是旧标志。已缓存的环境 Group 材质不重建，仅当 LRU 淘汰后
    // 重新构建才会取到新值；由于每个场景的雾设定是固定的，切回同一场景
    // 时命中的缓存本身就是正确标志，无需失效。
    setEnvFogEnabled(!!getEnvSpec(sceneId).fog)
    // Request D-v3：足球场/篮球场/雪山用真正搭建的几何 3D 环境，
    // 其他场景继续用立方体房间（贴图天空盒）。
    if (this.sceneEnv) {
      this.scene.remove(this.sceneEnv)
      this.sceneEnv = null
    }
    const env = this.assets.getSceneEnvironment(sceneId)
    if (env) {
      this.scene.add(env)
      this.sceneEnv = env
      // 室内顶棚：俯视相机会升到层高之上，不藏起来就直接把房间看穿。
      // 按名字抓一次引用，之后每帧只需改一个 visible。
      this.ceiling = env.getObjectByName("CeilingGroup") ?? null
      if (this.ceiling) this.ceiling.visible =
        this.camera.camera.position.z < INDOOR_CEIL_Z - 0.05
      if (this.assets.background) this.assets.background.visible = false
    } else {
      this.assets.recolorScene(sceneId)
      if (this.assets.background) this.assets.background.visible = true
    }
    // 不再 scene.background = null —— 这会让 canvas 透出 body 背景色，
    // 表现为桌面外一片漆黑。改为设一个与 wallA 一致的纯色背景，雪山的
    // skyDome 会渲染在它之上。
    const def = getEnvScene(sceneId)
    this.scene.background = new Color(def.wallA)

    /**
     * v1.3.63：光照 / 雾 / 远裁剪面改由 ENV_SPECS 表驱动。
     *
     * 原先是 `if (sceneId === "snow")` 一个分支 —— 7 个新场景各来一遍
     * 就得复制 7 份，且 far 与天穹半径的自洽性只能靠注释约定。
     * 数值与 v1.3.62 完全一致（雪山 golden 验证通过）。
     */
    const spec = getEnvSpec(sceneId)

    // v1.8.9：把当前场景的天花板净空注入相机，约束全桌/回放自由机位的 z 上界，
    // 防止拖动视角抬高机位时穿进天花板白屏。室内新场景 room/tea 有明确高度，
    // 其余场景（户外 / 高顶棚）为 null → 相机保持原有行为。
    this.camera.setCeilingZ(CAMERA_CEILING_Z[sceneId] ?? null)

    if (this.sun) this.sun.visible = spec.outdoor
    if (this.hemi) this.hemi.visible = spec.outdoor

    /**
     * v1.3.85：室内三件套的真实光源开关。
     *
     * 同样必须「显式赋值」而非「存旧值再还原」—— 本方法会被调用两次
     * （构造后一次、renderer 惰性重建后一次），保存/还原的写法在第二次
     * 调用时会把旧值记成已修改后的状态，导致残留（sun/hemi 在 v1.3.63
     * 就是为了这个坑才改成表驱动）。
     */
    if (this.indoorAmb) this.indoorAmb.visible = spec.indoor
    if (this.indoorHemi) this.indoorHemi.visible = spec.indoor
    if (this.indoorDir) this.indoorDir.visible = spec.indoor
    if (this.indoorTable) {
      this.indoorTable.visible = spec.indoor
      // 低画质档（0 极速 / 1 流畅）不投影：吊灯阴影是氛围项，
      // 低端机优先保帧率（实测软件渲染下第二张 1024² 阴影图 +11% 帧时）。
      this.indoorTable.castShadow = Session.getLod() >= 2
    }

    /**
     * v1.3.86：阴影总开关。
     *
     * 户外（雪山）本来就有 sun.castShadow，靠 spec.outdoor 打开；
     * 室内现在也投阴影（indoorDir.castShadow），因此两者取「或」。
     * 其余场景（沙滩/足球/篮球/UFC）既无阳光也无室内方向光，
     * shadowMap 保持关闭 —— 不产生任何额外开销。
     */
    if (this.renderer) {
      const wantShadow = spec.outdoor || spec.indoor
      if (this.renderer.shadowMap.enabled !== wantShadow) {
        this.renderer.shadowMap.enabled = wantShadow
        // 切换开关后必须让所有材质重新编译着色器，否则阴影不会生效
        this.renderer.shadowMap.needsUpdate = true
      }
      this.renderer.shadowMap.type = spec.indoor
        ? PCFShadowMap
        : BasicShadowMap
    }

    // 远裁剪面：必须能容纳天穹（天穹半径 + 相机最大偏心 22.2）
    this.camera.camera.far = spec.far
    this.camera.camera.updateProjectionMatrix()

    this.scene.fog = spec.fog
      ? new Fog(spec.fog.color, spec.fog.near, spec.fog.far)
      : null

    if (this.ambient) {
      const amb = spec.amb ?? { color: def.amb, intensity: def.ambI }
      this.ambient.color.setHex(amb.color)
      this.ambient.intensity = amb.intensity
    }

    // 真实太阳阴影与程序化接触阴影互斥（避免双重阴影）
    this.setBallsFakeShadow(!spec.realShadow)

    // 色调映射：表驱动显式赋值（v1.3.63，见 View.SCENE_TONE）
    if (this.renderer) {
      const tone = View.SCENE_TONE[sceneId]
      this.renderer.toneMapping = tone ? tone.mapping : NoToneMapping
      this.renderer.toneMappingExposure = tone ? tone.exposure : 1

      /**
       * v1.6.0（3D 美化 P1）：室内场景挂程序化台球厅环境贴图。
       *
       * PBR 材质（球的 clearcoat、桌框木纹/金属件、球杆漆面）的高光
       * 需要一个环境去反射；没有 environment 时 clearcoat 反射一片黑，
       * 球像哑光塑料珠。environmentIntensity 0.55 是「能映出吊灯长条
       * 高光、又不至于把台呢色洗掉」的实测定值。
       *
       * 户外场景（雪山/沙滩/球场）保持 null —— 它们的明暗全部烘焙在
       * 顶点色里（bakeSun 假想太阳），挂室内反射会穿帮。
       * renderer 惰性重建后本方法会再跑一次，WeakMap 缓存保证不重复烘焙。
       */
      if (spec.indoor) {
        this.scene.environment = getBilliardHallEnvironment(this.renderer)
        this.scene.environmentIntensity = 0.35
      } else {
        // v1.6.0（P4）：户外场景给一张极简天空环境 —— 球/球杆的 PBR 高光
        // 在户外同样需要反射出处（原先只有室内有）。强度 0.3 且户外明暗
        // 是烘焙顶点色，故不改变已标定的场景观感，只补上球的反射层。
        this.scene.environment = getOutdoorSkyEnvironment(this.renderer)
        this.scene.environmentIntensity = 0.3
      }
    }

    // 非黑兜底色
    this.renderer?.setClearColor(new Color(def.wallA), 1)

    // v1.3.95：桌腿跟着桌型尺寸走 —— 换规则 / 换场景后 configureForRule
    // 可能已经改写过 tableX/tableY。
    this.rebuildTableLegs()
  }

  /** 切换所有球的程序化接触阴影显隐（雪景隐藏，改用真实太阳光阴影） */
  private setBallsFakeShadow(visible: boolean): void {
    const balls = this.table?.balls
    if (!balls) return
    for (const b of balls) {
      const bm = (b as any).ballmesh
      if (bm && bm.shadow) bm.shadow.visible = visible
    }
  }

  ballToCheck = 0

  isInMotionNotVisible() {
    const frustum = this.viewFrustum()
    const b = this.table.balls[this.ballToCheck++ % this.table.balls.length]
    // 守卫：若某球尚未完成网格初始化（ballmesh 未就绪），直接返回 false，
    // 避免访问 undefined 抛出未捕获异常——否则在重场景（多球）下可能杀掉
    // 整个动画循环，表现为永久黑屏。
    const bm = (b as any).ballmesh
    if (!bm || !bm.mesh) return false
    return b.inMotion() && !frustum.intersectsObject(bm.mesh)
  }

  isMovingSlowly() {
    // 白球击球后，球缓慢移动时切换上帝视角
    const slowThreshold = 0.15
    return this.table.balls.some(
      (b) => b.inMotion() && b.vel.length() > 0 && b.vel.length() < slowThreshold
    )
  }

  viewFrustum() {
    const c = this.camera.camera
    this.frustum.setFromProjectionMatrix(
      this.projScreenMatrix.multiplyMatrices(
        c.projectionMatrix,
        c.matrixWorldInverse
      )
    )
    return this.frustum
  }
}
