import { id } from "../utils/dom"
import type { Table } from "../model/table"
import type { Ball } from "../model/ball"
import { Session } from "../network/client/session"
import { getSeries } from "../utils/series"

export class Hud {
  p1Element: HTMLElement | null
  p2Element: HTMLElement | null
  middleElement: HTMLElement | null
  breakElement: HTMLElement | null
  /** v1.2.6：v2 计分板——选手列容器 + 标签 + 已进球行 */
  private readonly p1PlayerEl: HTMLElement | null
  private readonly p2PlayerEl: HTMLElement | null
  private readonly p1LabelEl: HTMLElement | null
  private readonly p2LabelEl: HTMLElement | null
  private readonly p1BallsEl: HTMLElement | null
  private readonly p2BallsEl: HTMLElement | null
  /** 系列赛总比分行（仅人机对战显示）：「系列赛 你 X : Y 电脑」 */
  private readonly scSeriesEl: HTMLElement | null
  /**
   * 是否「连续对局」模式（决定局比分行是否显示）。
   * v1.3.75：不再在构造时把 `Session.isBotMode()` 缓存成只读常量 —— 一旦 Hud
   * 的构造时序早于 `Session.init()`，这里就会永久锁死成 false，系列赛行整局
   * 都不显示。改为运行时实时读取，任何时序下都安全。
   * v1.3.83：判据换成 `Session.isSeriesMode()` —— 局域网对战也属于连续对局，
   * 同样要显示「局比分」（用户反馈第 1 条）。
   */
  private get isSeriesMode(): boolean {
    return Session.isSeriesMode()
  }
  /** 当前玩法名（rulename），用于读取系列赛累计 */
  private readonly ruleName: string
  /** 顶部「break」分（老 HUD 兼容），新 v2 比分栏不展示 */
  breakScoreElement: HTMLElement | null
  timeTextElement: HTMLElement | null

  /**
   * v1.2.6：每位玩家已进球球号集合。在 advance() 每帧调用 updatePocketedBalls 时，
   * 通过对比前后落袋集合，把新增的球号归到「当前回合选手」（setActivePlayer 设置）。
   * 这样进球归属准确：球在 shot 动画期间落袋，active 仍是出杆选手，不会被算到下一杆。
   */
  private readonly playerPocketed: { 1: Set<number>; 2: Set<number> } = {
    1: new Set(),
    2: new Set(),
  }
  private prevPocketedAll = new Set<number>()
  private activePlayer: 1 | 2 = 1

  // 训练模式判定
  private readonly isTrainMode: boolean = false
  private timerId: number | null = null
  private timerStart: number = 0

  constructor() {
    this.p1Element = id("p1Score")
    this.p2Element = id("p2Score")
    this.breakScoreElement = id("breakScore")
    this.p1PlayerEl = document.querySelector<HTMLElement>(".sc-player[data-player='1']")
    this.p2PlayerEl = document.querySelector<HTMLElement>(".sc-player[data-player='2']")
    this.p1LabelEl = id("scP1Label")
    this.p2LabelEl = id("scP2Label")
    this.p1BallsEl = id("p1Balls")
    this.p2BallsEl = id("p2Balls")

    // v1.3.66：系列赛总比分行。仅在人机对战（系列赛）模式下显示，
    // 每局开局即展示「你 0 : 0 电脑」，随结算累加。
    this.scSeriesEl = id("scSeries")
    try {
      this.ruleName =
        new URLSearchParams(location.search).get("ruletype") ?? ""
    } catch {
      this.ruleName = ""
    }
    if (this.scSeriesEl && this.isSeriesMode) {
      this.refreshSeries()
    }

    this.middleElement = id("hudMiddle")

    this.timeTextElement = id("scTimeText")

    // v1.2.6：根据模式设置选手标签：p1 永远是「玩家」，p2 在电脑对战时为「电脑」，其他为「对手」
    // v1.3.19：标签随界面语言切换（中文 / English），读取与主菜单共用的 localStorage 设置
    const isEn = (() => {
      try {
        const raw = localStorage.getItem("billiards_cn_settings_v1")
        if (raw) {
          const s = JSON.parse(raw)
          if (s) return false
        }
      } catch (_) {}
      return false
    })()
    if (this.p1LabelEl) this.p1LabelEl.textContent = "Người chơi"
    if (this.p2LabelEl) {
      // 比分栏 p2 名字由 updateScoreHud → orderedNamesForHud().p2Name
      // （即 Session.opponentName）决定，此处仅作构造时的初始值；
      // 难度已随 opponentName 写入「电脑(稳健)」等格式（见 BrowserContainer）。
      if (Session.isBotMode()) {
        this.p2LabelEl.textContent =
          Session.getInstance().opponentName ?? ("Máy")
      } else {
        this.p2LabelEl.textContent = "Đối thủ"
      }
    }

    // 训练模式 → body.train-mode（CSS 隐藏 p2 列与共享已进球区）
    try {
      const params = new URLSearchParams(location.search)
      const ruleType = params.get("ruletype") ?? ""
      const isPractice = params.get("practice") === "true"
      if (
        ruleType === "train" ||
        ruleType === "training" ||
        ruleType === "practice" ||
        isPractice
      ) {
        document.body.classList.add("train-mode")
      }
    } catch (_) {
      // 忽略 URL 解析失败
    }
    this.isTrainMode = document.body.classList.contains("train-mode")

    if (this.timeTextElement) {
      this.startTimer()
    }
  }

  setActivePlayer(active: 0 | 1 | 2) {
    const p = active === 2 ? 2 : 1
    this.activePlayer = p
    this.p1PlayerEl?.classList.toggle("is-active", active === 1)
    this.p2PlayerEl?.classList.toggle("is-active", active === 2)
  }

  /** v1.1.18：启动用时计时（mm:ss） */
  private startTimer() {
    if (this.timerId !== null) return
    this.timerStart = performance.now()
    const render = () => {
      if (!this.timeTextElement) return
      const elapsedSec = Math.floor((performance.now() - this.timerStart) / 1000)
      const mm = Math.floor(elapsedSec / 60).toString().padStart(2, "0")
      const ss = (elapsedSec % 60).toString().padStart(2, "0")
      this.timeTextElement.textContent = `${mm}:${ss}`
    }
    render()
    this.timerId = window.setInterval(render, 1000)
    window.addEventListener("beforeunload", () => {
      if (this.timerId !== null) {
        clearInterval(this.timerId)
        this.timerId = null
      }
    })
  }

  private setText(element: HTMLElement | null, text: string) {
    if (element) {
      element.textContent = text
    }
  }

  /**
   * v1.2.6：刷新比分栏 + 按选手拆分已进球。
   * - p1Score / p2Score 写入大号进球数（去掉旧的 name+value HTML，标签在专用元素）。
   * - updatePocketedBalls 每帧调用：diff 前后落袋集合 → 新增球号归到「当前回合选手」。
   * - 重开局（桌面无球落袋）时复位双方集合。
   */
  updateScores(
    p1: number,
    p2: number,
    _p1Name?: string,
    _p2Name?: string,
    b: number = 0,
    hideScore: boolean = false,
    _p1Star: boolean = false,
    _p2Star: boolean = false
  ) {
    if (hideScore) {
      // 兼容老调用：练习模式隐藏分数，仅写 p1 占位
      this.setText(this.p1Element, "")
      this.setText(this.p2Element, "")
      return
    }
    this.setText(this.p1Element, String(p1))
    this.setText(this.p2Element, String(p2))
    // v1.3.48：比分栏选手名（含电脑难度「电脑(稳健)」等）此前由 Hud 构造时设置一次，
    // 而 Hud 在 BrowserContainer.super() 中早于 opponentName 写入，名字停在未带难度的初值；
    // 且 updateScoreHud 传入的 p2Name 原被 updateScores 直接忽略。此处随每次得分刷新写入，
    // 确保电脑难度稳定显示，不依赖构造时序。
    if (_p1Name && this.p1LabelEl) this.p1LabelEl.textContent = _p1Name
    if (_p2Name && this.p2LabelEl) this.p2LabelEl.textContent = _p2Name
    // v1.3.66：每局得分刷新时同步系列赛总比分（人机对战下）
    this.refreshSeries()
  }

  /**
   * v1.3.66：刷新系列赛总比分显示。
   * 仅人机对战（series 模式）显示「系列赛 你 X : Y 电脑」；
   * 比分栏的 p2 名字由 opponentName 决定（含难度如「电脑(专业)」）。
   * 当前这一局尚未结算，故显示的是此前各局累计——本局结束后下一局会自动 +1。
   *
   * v1.3.76：**第一局不显示这一行**。用户明确要求比分栏的系列赛行只在
   * 「已经打完一局、并点了继续对战」之后才出现；开局 0:0 时这一行纯属噪音，
   * 而且会让玩家误以为「这局已经算进去了」。判定条件就是「你/电脑至少
   * 有一方已经赢过至少一局」——recordResult 只在结算时写入，因此 0:0
   * 必然等价于「本轮还没打完任何一局」。
   */
  private refreshSeries(): void {
    if (!this.scSeriesEl) return
    if (!this.isSeriesMode) {
      this.scSeriesEl.hidden = true
      return
    }
    const s = getSeries(this.ruleName)
    // 一局都没打完（0:0）→ 不显示局比分行
    if (s.you === 0 && s.cpu === 0) {
      this.scSeriesEl.hidden = true
      this.scSeriesEl.textContent = ""
      return
    }
    // v1.3.83：局域网对战的对手是对面玩家，不能叫「电脑」。
    const label = Session.isBotMode()
      ? (Session.getInstance().opponentName ?? "电脑")
      : "对手"
    this.scSeriesEl.textContent = `局比分　你 ${s.you} : ${s.cpu} ${label}`
    this.scSeriesEl.hidden = false
  }

  /**
   * 每帧调用：刷新每位选手已进球的颜色球行。
   * 关键：球在 advance 动画期间落袋，active 仍是出杆选手，
   * 因此把新增球号归到 activePlayer 是正确的。
   */
  updatePocketedBalls(table: Table) {
    const pocketed = table.balls
      .filter(
        (b): b is Ball =>
          typeof b.label === "number" && b.label >= 1 && !b.onTable()
      )
    const currentSet = new Set<number>(pocketed.map((b) => b.label as number))

    // 重开局检测：桌面所有球归位 → 复位双方归因
    if (currentSet.size === 0 && this.prevPocketedAll.size > 0) {
      this.playerPocketed[1].clear()
      this.playerPocketed[2].clear()
    }

    // diff：把新增球号归到当前回合选手
    for (const label of currentSet) {
      if (!this.prevPocketedAll.has(label)) {
        this.playerPocketed[this.activePlayer].add(label)
      }
    }
    this.prevPocketedAll = currentSet

    this.renderPlayerBalls(this.p1BallsEl, this.playerPocketed[1], table)
    this.renderPlayerBalls(this.p2BallsEl, this.playerPocketed[2], table)
  }

  private renderPlayerBalls(
    container: HTMLElement | null,
    labels: Set<number>,
    table: Table
  ) {
    if (!container) return
    // v1.4.0：按实际进球顺序展示 —— Set 迭代序 = 插入序（JS 规范保证），
    // 球落袋时按时间先后 add 进 playerPocketed，直接遍历即为进球顺序。
    // 旧实现 sort((a,b)=>a-b) 按球号重排，用户反馈「比分栏球体排列要
    // 以实际进球顺序为准，不要以球号大小排序」。
    const ordered = Array.from(labels)
    // 仅在内容变化时重建（按进球顺序序列作为 key）
    const key = ordered.join(",")
    if (container.dataset.key === key) return
    container.dataset.key = key
    container.innerHTML = ""
    for (const label of ordered) {
      const ball = table.balls.find((b) => b.label === label)
      const hex = ball?.ballmesh?.color
        ? "#" + ball.ballmesh.color.getHexString()
        : "#cccccc"
      const striped = label > 8
      const div = document.createElement("div")
      div.className = "sc-ball" + (striped ? " striped" : "")
      div.style.background = hex
      div.title = String(label)
      const num = document.createElement("span")
      num.className = "sc-ball-num"
      num.textContent = String(label)
      div.appendChild(num)
      container.appendChild(div)
    }
  }

  /** v1.2.6：新局开始时复位双方归因（Hud 重建时也会经构造函数重新初始化） */
  resetPocketedAttribution() {
    this.playerPocketed[1].clear()
    this.playerPocketed[2].clear()
    this.prevPocketedAll.clear()
    if (this.p1BallsEl) {
      this.p1BallsEl.innerHTML = ""
      delete this.p1BallsEl.dataset.key
    }
    if (this.p2BallsEl) {
      this.p2BallsEl.innerHTML = ""
      delete this.p2BallsEl.dataset.key
    }
  }
}