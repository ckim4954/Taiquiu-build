/**
 * 中英文案集中管理（v1.3.22 起支持运行时中英切换）
 *
 * 所有面向用户的文字统一在此维护，便于校对与调整。
 * 旧导出 `T` 保留为「默认中文」以保证向后兼容；新代码请用 `t("xxx")`。
 */

import { Settings } from "./settings"

/** 规则名：键→中文（不变，规则名本身就是中文） */
export const RULE_NAMES: Record<string, string> = {
  nineball: "9 bi",
  eightball: "8 bi",
  snooker: "Snooker",
  threecushion: "Carom 3 băng",
  sagu: "Carom 4 bi",
  "threecushion-drill": "Luyện tập Carom",
  drill: "Chế độ luyện tập",
}

export function ruleName(key: string | undefined): string {
  if (!key) return "Bi-a"
  return RULE_NAMES[key] ?? key
}

/** 犯规原因翻译表：把引擎产生的英文原因映射为中文 */
const FOUL_REASONS: Record<string, string> = {
  "Cue ball potted": "Bi cái rơi lỗ",
  "No ball hit": "Cú đánh trượt: không chạm bi nào",
  "Wrong ball hit first": "Chạm sai bi mục tiêu đầu tiên",
  "No cushion after contact": "Sau va chạm, không có bi nào chạm băng",
  "Cue ball hit nothing": "Bi cái không chạm bi nào",
  "Potted opponent ball": "Đánh bi của đối thủ xuống lỗ",
  "Hit opponent ball first": "Chạm bi của đối thủ trước",
  "Potted black ball": "Bi số 8 rơi lỗ quá sớm",
  "No rail after contact": "Sau cú đánh không có bi nào chạm băng",
  // v1.3.95：跳台犯规（球飞出台面）
  "Ball off table": "Bi văng khỏi bàn",
  球跳出台面: "Lỗi bi văng khỏi bàn",
}

export function foulReason(reason: string | undefined): string {
  if (!reason) return "Phạm lỗi"
  const hit = FOUL_REASONS[reason.trim()]
  if (hit) return hit
  return translateFoulHeuristic(reason)
}

/** 兜底：对包含常见英文关键词的原因做启发式翻译 */
function translateFoulHeuristic(reason: string): string {
  const r = reason.toLowerCase()
  if (r.includes("cue ball") && r.includes("pot")) return "Bi cái rơi lỗ"
  if (r.includes("no ball hit") || r.includes("hit nothing"))
    return "Cú đánh trượt: không chạm bi nào"
  if (r.includes("wrong ball")) return "Chạm sai bi mục tiêu đầu tiên"
  if (r.includes("cushion") || r.includes("rail")) return "Sau va chạm, không có bi nào chạm băng"
  if (r.includes("foul")) {
    const m = /\((\d+)\s*points?\)/i.exec(reason)
    if (m) return `Phạm lỗi (đối thủ được cộng ${m[1]} điểm)`
    return "Phạm lỗi"
  }
  return reason
}

/** v1.3.22：双语文案表。键名沿用旧 T 字段名，值为 { zh, en }。 */
const STRINGS: Record<string, { zh: string; en: string; vi: string }> = {
  // 通用
  foul: { zh: "犯规", en: "Foul" , vi: "Phạm lỗi" },
  ballInHand: { zh: "自由球（可任意摆放母球）", en: "Ball in hand (place the cue ball anywhere)" , vi: "Được đặt bi cái" },
  gameOver: { zh: "本局结束", en: "Game Over" , vi: "Kết thúc ván" },
  youWon: { zh: "你赢了", en: "You Won" , vi: "Bạn thắng" },
  youLost: { zh: "你输了", en: "You Lost" , vi: "Bạn thua" },
  newGame: { zh: "再来一局", en: "New Game" , vi: "Chơi ván mới" },
  backToMenu: { zh: "返回主菜单", en: "Back to Menu" , vi: "Về màn hình chính" },
  replay: { zh: "回放本局", en: "Replay" , vi: "Xem lại ván đấu" },
  close: { zh: "关闭", en: "Close" , vi: "Đóng" },
  confirm: { zh: "确定", en: "Confirm" , vi: "Xác nhận" },
  cancel: { zh: "取消", en: "Cancel" , vi: "Hủy" },

  // 局面提示
  breakTitle: { zh: "开球", en: "Break" , vi: "Khai cuộc" },
  yourTurn: { zh: "轮到你出杆", en: "Your Turn" , vi: "Đến lượt bạn đánh" },
  placeCueBall: { zh: "请摆放母球", en: "Place the Cue Ball" , vi: "Đặt bi cái" },
  systemError: { zh: "系统错误", en: "System Error" , vi: "Lỗi hệ thống" },
  replayComplete: { zh: "回放结束", en: "Replay Complete" , vi: "Đã phát lại xong" },

  // 对局信息
  vsBot: { zh: "对战电脑", en: "vs CPU" , vi: "Đấu với máy" },
  practice: { zh: "自由练习", en: "Practice" , vi: "Luyện tập tự do" },

  // 得分板
  player: { zh: "玩家", en: "You" , vi: "Người chơi" },
  opponent: { zh: "对手", en: "Opponent" , vi: "Đối thủ" },
  computer: { zh: "电脑", en: "CPU" , vi: "Máy" },
  breakScore: { zh: "连续得分", en: "Run" , vi: "Chuỗi điểm" },
  solids: { zh: "全色球", en: "Solids" , vi: "Bi trơn" },
  stripes: { zh: "花色球", en: "Stripes" , vi: "Bi sọc" },

  // 击球按钮
  hitButton: { zh: "击球", en: "Shoot" , vi: "Đánh bi" },
  placeBallButton: { zh: "摆球", en: "Place" , vi: "Đặt bi" },
  placeWhite: { zh: "摆白球", en: "Place White" , vi: "Đặt bi cái" },
  placeYellow: { zh: "摆黄球", en: "Place Yellow" , vi: "Đặt bi vàng" },
  placeRed: { zh: "摆红球", en: "Place Red" , vi: "Đặt bi đỏ" },
  continueButton: { zh: "继续", en: "Continue" , vi: "Tiếp tục" },
}

/**
 * 取得当前界面语言下的文案。
 * 取值失败时优雅降级为中文（保证旧调用方永远拿到非空字符串）。
 */
export function t(key: keyof typeof STRINGS): string {
  const entry = STRINGS[key]
  return entry ? entry.vi : String(key)
}

/** 旧导出：保持向后兼容（始终为中文）。新代码请改用 t()。 */
export const T: { [K in keyof typeof STRINGS]: string } = new Proxy(
  {} as { [K in keyof typeof STRINGS]: string },
  {
    get(_t, key: string) {
      const entry = STRINGS[key]
      return entry ? entry.vi : String(key)
    },
  }
)