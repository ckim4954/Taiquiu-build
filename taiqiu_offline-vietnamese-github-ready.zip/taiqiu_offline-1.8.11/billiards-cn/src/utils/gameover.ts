/**
 * 结算面板按钮（离线单机版）
 *
 * 原版的“返回大厅 / 再战一局（联机约战）”按钮已改为本地行为：
 * - menu：回到中文主菜单
 * - reload：原地重开一局
 * - replay：回放本局
 */
export const gameOverButtons = {
  lobby: `<button type="button" class="notification-btn" data-notification-action="menu">返回主菜单</button>`,
  newGame: `<button type="button" class="notification-btn" data-notification-action="reload">再来一局</button>`,
  /** v1.3.65：人机对战时的「再来一局」——这局打完系列赛比分已累加，
   *  点它就是「继续与电脑对战下一局」，文案对应改掉。 */
  continueSeries: `<button type="button" class="notification-btn" data-notification-action="reload">继续对战</button>`,
  replay: `<button type="button" class="notification-btn" data-notification-action="replay">回放本局</button>`,
  /** v1.2.4：游戏结束后保存本局回放（编码下载 + 写入本地「我的回放」） */
  saveReplay: `<button type="button" class="notification-btn" data-notification-action="saveReplay">保存回放</button>`,
  /** v1.2.5：游戏结束后直接回放本局（整局）。点击经 sessionStorage 传完整数据，
   *  规避 Android WebView 对 URL 长度的限制，避免只回放前几个球。 */
  viewReplay: `<button type="button" class="notification-btn" data-notification-action="viewReplay">查看回放</button>`,

  rematch(): string {
    return ""
  },

  /**
   * 结算面板按钮组。
   * @param botMode 人机对战。为 true 时首个按钮用「继续对战」而非「再来一局」。
   */
  forMode(botMode = false): string {
    const next = botMode ? this.continueSeries : this.newGame
    return next + " " + this.viewReplay + " " + this.saveReplay + " " + this.lobby
  },

  /**
   * v1.3.83：局域网对战的结算按钮组 —— 首个按钮用「继续对战」。
   *
   * 局域网也是连续对局（打完一局能接着开下一局，局比分累计），语义与
   * 人机对战的 `continueSeries` 完全一致，故复用同一按钮（同一个
   * `reload` 动作，走 restartGame 重载并保留 ?lan=/?peer= 参数）。
   * 此前局域网走 `forMode()` 无参 → 显示「再来一局」，与用户的说法不一致。
   */
  forLan(): string {
    return (
      this.continueSeries +
      " " +
      this.viewReplay +
      " " +
      this.saveReplay +
      " " +
      this.lobby
    )
  },
}
