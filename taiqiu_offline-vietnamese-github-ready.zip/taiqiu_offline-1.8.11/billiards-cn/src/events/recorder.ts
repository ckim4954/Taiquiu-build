import { Container } from "../container/container"
import { Outcome } from "../model/outcome"
import { EventType } from "./eventtype"
import { HitEvent } from "./hitevent"
import { GameEvent } from "./gameevent"
import { LinkFormatter } from "../view/link-formatter"
import { ReplayEncoder } from "../utils/replay-encoder"
import { Session } from "../network/client/session"
import { TableConfig } from "../view/tableconfig"
import { RecordEntry } from "./recordentry"

export class Recorder {
  container: Container
  linkFormatter: LinkFormatter
  entries: RecordEntry[] = []
  start = Date.now()
  breakStart: number | undefined
  breakStartTime: number | undefined

  constructor(container: Container, linkFormatter: LinkFormatter) {
    this.container = container
    this.linkFormatter = linkFormatter
  }

  get shots(): GameEvent[] {
    return this.entries.map((e) => e.event)
  }

  get states(): number[][] {
    return this.entries.map((e) => e.state)
  }

  record(event: GameEvent, recordOrigin: "local" | "remote" = "local") {
    let recordedEvent = event
    if (event.type === EventType.HIT) {
      recordedEvent = this.recordHitEvent(event as HitEvent, recordOrigin)
    }

    if (
      event.type === EventType.HIT ||
      event.type === EventType.RERACK ||
      event.type === EventType.PLACEBALL ||
      event.type === EventType.SCORE
    ) {
      this.entries.push({
        state: this.container.table.shortSerialise(),
        event: recordedEvent,
        pots: 0,
        isPartOfBreak: false,
        time: Date.now(),
      })
    }
  }

  private recordHitEvent(hitEvent: HitEvent, recordOrigin: "local" | "remote") {
    const tablejson = hitEvent.tablejson
    // recordedAim is tablejson.aim which never contains stateCheck,
    // so recordings are inherently lean without explicit stripping
    const recordedAim = tablejson.aim ?? tablejson
    if (!recordedAim?.pos) {
      throw new Error("HitEvent missing aim position")
    }

    // v1.5.4（#70）：给每杆打「归属」标记，回放进度条的进球点据此分色
    // （蓝 = 保存者本人，红 = 对手/AI）。
    // 来源判定在 Container 侧完成：本地玩家的 HIT 由 sendEvent 直发（local），
    // 对手/电脑的 HIT 经 eventQueue 中继进来（remote）。只标记 remote ——
    // 缺省（无 ow 或 ow≠2）一律视为玩家杆，旧回放数据因此自然兼容。
    if (recordOrigin === "remote") {
      ;(recordedAim as { ow?: number }).ow = 2
    }
    return recordedAim
  }

  private findLastIndex(
    skipTypes: EventType[] = [EventType.RERACK, EventType.SCORE]
  ): number {
    let last = this.entries.length - 1
    while (last >= 0 && skipTypes.includes(this.entries[last].event.type)) {
      last--
    }
    return last
  }

  getPlayerNames(): { player1: string; player2: string } {
    const orderedNames = Session.getInstance().orderedNamesForHud()
    return {
      player1: orderedNames.p1Name || "玩家",
      player2: orderedNames.p2Name || "对手",
    }
  }

  wholeGame() {
    // v1.2.6 #233：回放必须「从开球开始」。
    // 偶发情况下 entries[0] 并非开球那一杆，而是开球前的引导事件
    // （如开球摆白球的 PLACEBALL、或上一局残留的 SCORE/RERACK），
    // 若直接以 entries[0] 为起点，回放会先从「摆球 / 记分」开始，
    // 而非真正的第一杆开球。这里以「第一条 HIT 事件」作为真正的起点：
    //   - init 用该 HIT 记录时桌子序列化的状态（即开球前的正确球局）；
    //   - events 从该 HIT 起向后切片（丢弃开球前的引导事件）。
    // 正常情况（entries[0] 就是开球 HIT）下 startIndex=0，行为与之前完全一致。
    const startIndex = this.entries.findIndex(
      (e) => e.event.type === EventType.HIT
    )
    const start = startIndex >= 0 ? startIndex : 0
    return ReplayEncoder.createState(
      this.entries[start]?.state,
      this.entries.slice(start).map((e) => e.event),
      this.start,
      Session.getInstance().myScore(),
      true,
      this.getPlayerNames(),
      this.getTableSize()
    )
  }

  getWholeGameCompressed(): string {
    const game = this.wholeGame()
    return ReplayEncoder.crush(JSON.stringify(game))
  }

  last() {
    return this.findLastIndex()
  }

  lastShot() {
    const last = this.last()
    if (last < 0) {
      return undefined
    }
    const entry = this.entries[last]
    const events: GameEvent[] = [entry.event]
    for (let i = last + 1; i < this.entries.length; i++) {
      if (this.entries[i].event.type === EventType.SCORE) {
        events.push(this.entries[i].event)
      }
    }
    return ReplayEncoder.createState(
      entry.state,
      events,
      0,
      0,
      false,
      this.getPlayerNames(),
      this.getTableSize()
    )
  }

  currentBreak() {
    if (this.breakStart !== undefined) {
      const breakEntries = this.entries.slice(this.breakStart)
      return ReplayEncoder.createState(
        this.entries[this.breakStart].state,
        breakEntries.map((e) => e.event),
        this.breakStartTime,
        this.container.rules.previousBreak,
        false,
        this.getPlayerNames(),
        this.getTableSize()
      )
    }
    return undefined
  }

  updateBreak(
    outcome: Outcome[],
    isPartOfBreak: boolean,
    isEndOfGame: boolean
  ) {
    const potCount = Outcome.potCount(outcome)
    const lastIndex = this.last()
    if (lastIndex >= 0) {
      this.entries[lastIndex].pots = potCount
      this.entries[lastIndex].isPartOfBreak = isPartOfBreak
    }

    if (!isPartOfBreak) {
      this.addBreakToTray(isEndOfGame)
    }

    this.addShotToTray(
      isPartOfBreak || isEndOfGame,
      potCount,
      Outcome.pots(outcome)
    )

    if (isEndOfGame) {
      this.addBreakToTray(isEndOfGame)
    }

    if (!isPartOfBreak) {
      this.breakStart = undefined
      return
    }

    if (this.breakStart === undefined) {
      this.breakStart = lastIndex
      this.breakStartTime = Date.now()
    }
  }

  addShotToTray(isPartOfBreak, potCount, balls) {
    const lastShot = this.lastShot()
    if (lastShot) {
      this.container.ballTray.addShot(isPartOfBreak, potCount, balls, lastShot)
    }
  }

  addBreakToTray(includeLastShot: boolean) {
    const currentBreak = this.currentBreak()
    if (!currentBreak) {
      return
    }

    const breakScore =
      this.container.rules.currentBreak === 0
        ? this.container.rules.previousBreak
        : this.container.rules.currentBreak

    if (includeLastShot) {
      this.container.ballTray.addBreak(currentBreak, breakScore)
      return
    }

    const trimmedShots = (currentBreak.shots as GameEvent[]).slice()
    while (
      trimmedShots.length > 0 &&
      (trimmedShots[trimmedShots.length - 1].type === EventType.SCORE ||
        trimmedShots[trimmedShots.length - 1].type === EventType.RERACK)
    ) {
      trimmedShots.pop()
    }

    if (trimmedShots.length === 0) {
      return
    }

    const trimmedBreak = {
      ...currentBreak,
      shots: trimmedShots,
    }
    this.container.ballTray.addBreak(trimmedBreak, breakScore)
  }

  wholeGameLink() {
    this.linkFormatter.wholeGameLink(this.wholeGame())
  }

  getPastShots(
    n: number,
    skipTypes: EventType[] = [EventType.RERACK, EventType.SCORE]
  ) {
    const shots: RecordEntry[] = []

    for (let i = this.entries.length - 1; i >= 0 && shots.length < n; i--) {
      if (!skipTypes.includes(this.entries[i].event.type)) {
        shots.unshift(this.entries[i])
      }
    }

    return shots
  }

  /**
   * v1.3.59：改用 TableConfig 读取，带上当前玩法名。
   *
   * 此前这里独立于 TableConfig 自己解析 URL、写死默认 10。斯诺克默认尺寸改成
   * 12 之后，若此处仍返回 10，回放状态里记录的 tableSize 会与实际建表尺寸不符，
   * 载入回放时会用错误的尺寸重建台面。
   */
  private getTableSize(): number {
    return TableConfig.tableSizeFromUrl(this.container?.rules?.rulename)
  }
}
