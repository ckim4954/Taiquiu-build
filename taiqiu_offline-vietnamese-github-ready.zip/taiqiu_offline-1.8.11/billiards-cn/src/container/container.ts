import { Input } from "../events/input"
import { GameEvent } from "../events/gameevent"
import { Session } from "../network/client/session"
import { StationaryEvent } from "../events/stationaryevent"
import { Table } from "../model/table"
import { View } from "../view/view"
import { Init } from "../controller/init"
import { AimInputs } from "../view/dom/aiminputs"
import { Keyboard } from "../events/keyboard"
import { Sound } from "../view/sound"
import { Chat } from "../view/chat"
import { ChatEvent } from "../events/chatevent"
import { Throttle } from "../events/throttle"
import { Sliders } from "../view/sliders"
import { Recorder } from "../events/recorder"
import { LinkFormatter } from "../view/link-formatter"
import { Rules } from "../controller/rules/rules"
import { RuleFactory } from "../controller/rules/rulefactory"
import { ThreeCushionConfig } from "../utils/threecushionconfig"
import { Menu } from "../view/menu"
import { Comment } from "../view/comment"
import { Hud } from "../view/hud"
import { NotificationEvent } from "../events/notificationevent"
import { LobbyIndicator } from "../view/lobbyindicator"
import { TableConfig } from "../view/tableconfig"
import { MessageRelay } from "../network/client/messagerelay"
import { ScoreReporter } from "../network/client/scorereporter"
import {
  Notification,
  NotificationData,
  NotificationActionHandlers,
} from "../view/notification"
import { ScoreEvent } from "../events/scoreevent"
import { ContainerConfig } from "./containerconfig"
import { Controller } from "../controller/controller"
import { ParticleSystem } from "../view/particle-system"
import { End } from "../controller/end"
import { Replay } from "../controller/replay"
import { Aim } from "../controller/aim"
import { PlaceBall } from "../controller/placeball"
import { PlayShot } from "../controller/playshot"
import { WatchAim } from "../controller/watchaim"
import { WatchShot } from "../controller/watchshot"
import { BallTray } from "../view/ball-tray"
import { ExportUtils } from "../utils/export-utils"
import { TurnTimer } from "../utils/turntimer"
import { ConcedeEvent } from "../events/concedeevent"
import { setupFarGestures } from "../view/far-gestures"
import { BallReturn } from "../view/ball-return"

type ActivePlayer = 0 | 1 | 2

/**
 * Model, View, Controller container.
 */
export class Container {
  table: Table
  particles: ParticleSystem
  view: View
  controller: Controller
  inputQueue: Input[] = []
  eventQueue: GameEvent[] = []
  keyboard?: Keyboard
  sound: Sound
  chat: Chat
  sliders: Sliders
  recorder: Recorder
  linkFormatter: LinkFormatter
  ballTray: BallTray
  id: string
  isSinglePlayer: boolean = true
  rules: Rules
  menu: Menu
  comment: Comment
  hud: Hud
  notification: Notification
  lobbyIndicator: LobbyIndicator
  replayMode: boolean = false
  examMode: boolean = false
  relay: MessageRelay | null = null
  scoreReporter: ScoreReporter | null = null
  frame: (timestamp: number) => void
  ballReturn: BallReturn
  turnTimer: TurnTimer = new TurnTimer()
  /** 标记上一次 updateController 时玩家是否在场上（用于启停计时器） */
  private wasPlayerTurn: boolean = false
  /** Multiplier applied to real elapsed time before it's converted to physics
   * steps in `advance()`. 1 everywhere except the shot-analysis view, which
   * sets this higher so shot playback feels snappier without changing the
   * fixed physics step (`this.step`) and therefore without affecting
   * simulation accuracy. */
  timeScale = 1

  /**
   * v1.2.9 #F3 / #F5：回放模式专用状态。
   * - replayPaused：用户正在拖动进度条（seek）时为 true，强制 timeScale=0
   *   冻结物理，避免与拖动冲突；松手后复位由 Replay 控制器恢复。
   * - replayTimeScaleHook：每帧由 Replay 控制器回调，返回本帧应使用的 timeScale
   *   （#F3 依据本杆「最后碰撞/进袋 + 提前量」动态决定 1 或 REPLAY_FAST）。
   * - replayFrameHook：每帧由 Replay 控制器回调，用于刷新进度条 UI（#F5）。
   * 三者均由 Replay 在 onFirst 内挂载、退出回放时清空。
   */
  replayPaused = false
  replayTimeScaleHook: (() => number) | null = null
  replayFrameHook: (() => void) | null = null

  private hudScores = {
    p1: 0,
    p2: 0,
  }
  private hudActivePlayer: ActivePlayer = 0
  private wasReplay: boolean = false

  lastShotInit?: string
  lastShotData?: string

  last = performance.now()
  readonly step = 0.001953125 * 1

  broadcast: (event: GameEvent) => void = () => {}
  log: (text: string) => void

  constructor(config: ContainerConfig) {
    const {
      element,
      log,
      assets,
      ruletype,
      keyboard,
      id,
      relay = null,
      scoreReporter = null,
      replayMode = false,
      isSinglePlayer = true,
    } = config
    this.log = log
    this.replayMode = replayMode
    this.examMode = config.examMode ?? false
    this.isSinglePlayer = isSinglePlayer
    this.rules = RuleFactory.create(ruletype, this)
    this.table = this.rules.table()
    this.view = new View(element, this.table, assets)
    // v1.1.25：View 已建（renderer 已 OK），后续 setup（Hud/Notification/Menu/
// LobbyIndicator 等 DOM 依赖 + 资源相关）任一行抛异常都会让 createContainer()
// throw、this.container 没赋值、animate() 永远跑不到。整块包 try/catch，
// 错误上报诊断浮层，构造器总能返回，至少能跑渲染循环看到画面。
try {
    this.table.cue.aimInputs = new AimInputs(this)
    if (keyboard) {
      this.keyboard = keyboard
      // item 1：画布拖动的按下/松手直接驱动辅助线显隐
      keyboard.onDragStart = () => {
        const cue = this.table.cue
        if (!cue.aimInputs || cue.aimInputs.isDisabled()) return
        // v1.3.20：白球击球点展开面板打开时，屏蔽画布拖拽瞄准，
        // 防止调整打点时滑动屏幕误触旋转瞄准方向。
        if (cue.aimInputs.isCueBallPopupOpen()) return
        // v1.3.76：这次按下刚把打点面板收起来 —— 本次手势只用来关面板，
        // 不改瞄准。真正吞事件的是 Keyboard.shouldIgnoreDrag（连 movement
        // 都不攒），这里再挡一道，保证辅助线也不会闪一下。
        if (cue.aimInputs.isAimSuppressed()) return
        cue.beginAimInteraction()
      }
      keyboard.onDragEnd = () => {
        this.table.cue.endAimInteraction()
      }
      // v1.3.76：打点面板刚被这次按下收起时，整段拖拽手势都不产生瞄准输入。
      // v1.8.2：全桌机位下拖屏是「转相机」，绝不能顺手改瞄准角 —— 复用
      // 同一条已验证的屏蔽链（比在 far-gestures 里 stopPropagation 更保险，
      // interact.js 的 start/move 不一定都走 element 的冒泡阶段）。
      keyboard.shouldIgnoreDrag = () =>
        !!this.table.cue.aimInputs?.isAimSuppressed() ||
        this.view.camera.mode === this.view.camera.farView
    }
    this.sound = assets.sound
    this.chat = new Chat(this.sendChat)
    this.sliders = new Sliders()
    this.linkFormatter = new LinkFormatter(this)
    this.ballTray = new BallTray(this)
    this.recorder = new Recorder(this, this.linkFormatter)
    this.id = id ?? ""
    this.menu = new Menu(this)
    this.comment = new Comment(this)
    this.table.addToScene(this.view.scene)

    // v1.8.2：全桌机位自由化（旋转 + 缩放）与落袋回球通道，都是纯视觉/输入层。
    // 手势常驻绑容器，按机位门控；回球动画挂 advance 首行的每帧 hook。
    this.ballReturn = new BallReturn(this.view.scene)
    setupFarGestures(
      this.view.element as HTMLElement,
      this.view.camera,
      () => this.view.canvas,
      () => { this.lastEventTime = performance.now() }
    )
    this.frame = (dt: number) => {
      if (this.ballReturn.update(dt, this.table.balls, this.replayMode)) {
        // 球全静止后容器 60s 会停 render；动画期间必须持续续命，否则会冻结
        this.lastEventTime = performance.now()
      }
    }
    this.view.onLineDrawn = (line) => {
      this.sendEvent(new ChatEvent(this.id, "", line))
    }
    this.view.onBallTap = (ball) => {
      const cue = this.table.cue
      if (!cue.aimInputs || cue.aimInputs.isDisabled()) return
      // v1.3.20：白球击球点展开面板打开时，屏蔽点球瞄准（同拖拽瞄准互斥）。
      if (cue.aimInputs.isCueBallPopupOpen()) return
      // v1.3.76：这次点击只是把打点面板收起来（含 pointerup 之后才派发的
      // tap），不要顺手把瞄准对准到被点的球上。
      if (cue.aimInputs.isAimTapSuppressed()) return
      cue.aimAtNext(this.table.cueball, ball)
      // 点球对准是瞬时操作，没有松手事件，给一个短暂的辅助线可见窗口
      cue.flashAimInteraction()
      cue.rotateAim(0, this.table)
      cue.updateAimInput()
      this.lastEventTime = performance.now()
    }
    // 让球杆能访问 View（用于判断相机模式，控制辅助线显示 / 实时换肤）
    this.table.cue.view = this.view
    // v1.3.59：改用 TableConfig 读取并带上玩法名。此前写死默认 10，
    // 斯诺克默认改成 12 之后粒子平面的尺寸会跟不上（内部按 88R × 44R 硬编码），
    // 台面变大而粒子层没跟着变大就会露出边缘。
    const tableSize = TableConfig.tableSizeFromUrl(this.rules?.rulename)
    this.particles = new ParticleSystem({ tableSize })
    this.hud = new Hud()
    this.notification = new Notification()
    this.relay = relay
    this.scoreReporter = scoreReporter
    this.lobbyIndicator = new LobbyIndicator(
      Session.getInstance().botMode,
      this.replayMode,
      this.rules,
      (msg) => this.chat.showMessage(msg),
      config.messagingUrl,
      (url) => this.menu.showOverlay(url)
    )
    this.updateController(new Init(this))
    //  this.updateController(new End(this))
} catch (e) {
    const msg = e instanceof Error ? e.message : String(e)
    const stack = e instanceof Error ? e.stack : ""
    console.error("[Container] post-view setup failed:", msg, stack)
}
  }

  init() {
    if (location.port !== "8081" && this.lobbyIndicator) {
      this.lobbyIndicator.init()
    }
  }

  sendChat = (msg) => {
    this.sendEvent(new ChatEvent(this.id, msg))
  }

  throttle = new Throttle(250, (event) => {
    this.broadcast(event)
  })

  sendEvent(event) {
    // v1.5.4（#70）：本地玩家直接发出的事件标记为 local（回放归属=玩家）。
    this.recorder.record(event, "local")
    this.throttle.send(event)
  }

  private myHudSlot(): 1 | 2 {
    return Session.getInstance().playerIndex === 1 ? 2 : 1
  }

  private opponentHudSlot(): 1 | 2 {
    return this.myHudSlot() === 1 ? 2 : 1
  }

  inferActivePlayer(controller: Controller = this.controller): ActivePlayer {
    if (
      controller instanceof Aim ||
      controller instanceof PlaceBall ||
      controller instanceof PlayShot
    ) {
      return this.myHudSlot()
    }
    if (controller instanceof WatchAim || controller instanceof WatchShot) {
      return this.opponentHudSlot()
    }
    return 0
  }

  setHudActivePlayer(active: ActivePlayer) {
    this.hudActivePlayer = active
    this.hud.setActivePlayer(active)
  }

  updateScoreHud(p1: number, p2: number, b: number, active?: ActivePlayer) {
    const session = Session.getInstance()
    session.updateScoresFromNetwork(p1, p2, b)
    const orderedScores = session.orderedScoresForHud()
    this.hudScores = orderedScores
    const orderedNames = session.orderedNamesForHud()

    // Format handicap append next to player names
    const isHandicapRule =
      this.rules.rulename === "sagu" || this.rules.rulename === "threecushion"
    const handicaps = session.getHandicaps()
    const hasHandicaps = isHandicapRule && Object.keys(handicaps).length > 0

    let p1Target = ThreeCushionConfig.raceTo
    let p2Target = ThreeCushionConfig.raceTo

    if (hasHandicaps) {
      const p1ClientId =
        session.playerIndex === 0
          ? session.clientId
          : (session.opponentClientId ?? "opponent")
      const p2ClientId =
        session.playerIndex === 0
          ? (session.opponentClientId ?? "opponent")
          : session.clientId

      p1Target = session.getRaceTargetForPlayer(p1ClientId)
      p2Target = session.getRaceTargetForPlayer(p2ClientId)

      if (orderedNames.p1Name) {
        orderedNames.p1Name = `${orderedNames.p1Name}(${p1Target})`
      }
      if (orderedNames.p2Name) {
        orderedNames.p2Name = `${orderedNames.p2Name}(${p2Target})`
      }
    }

    // v1.3.57：删除玩家名旁的 (solids)/(stripes) 花色标注。
    // v1.2.x 曾在八球分完花色后往自己名字后追加硬编码英文标注，形如
    // 「玩家(stripes)」——一是中英文混排突兀，二是 HUD 左上角的进球托盘
    // 已经直观显示了本方分到的球，这行标注纯属冗余。电脑名称不受影响
    // （标注只加在 orderedNames 的玩家槽位上，电脑名本来就没挂过）。

    const hideScore = this.rules.hideScoreHud?.() ?? false
    const isSagu = this.rules.rulename === "sagu"
    const p1Star = isSagu && orderedScores.p1 === p1Target - 1
    const p2Star = isSagu && orderedScores.p2 === p2Target - 1

    this.hud.updateScores(
      orderedScores.p1,
      orderedScores.p2,
      orderedNames.p1Name,
      orderedNames.p2Name,
      hideScore ? 0 : b,
      hideScore,
      p1Star,
      p2Star
    )
    this.setHudActivePlayer(active ?? this.inferActivePlayer())
  }

  sendScoreUpdate(p1: number, p2: number, b: number, active?: ActivePlayer) {
    const activePlayer = active ?? this.inferActivePlayer()
    const changed =
      this.hudScores.p1 !== p1 ||
      this.hudScores.p2 !== p2 ||
      Session.getInstance().currentBreak !== b ||
      this.hudActivePlayer !== activePlayer
    this.updateScoreHud(p1, p2, b, activePlayer)
    if (changed) {
      this.sendEvent(new ScoreEvent(p1, p2, b, activePlayer))
    }
  }

  notify(data: NotificationData | string, duration?: number) {
    this.notification.show(data, duration)
    this.sendEvent(new NotificationEvent(data, duration))
  }

  notifyLocal(
    data: NotificationData | string,
    duration?: number,
    actionHandlers?: NotificationActionHandlers
  ) {
    this.notification.show(data, duration, actionHandlers)
  }

  advance(elapsed) {
    this.frame?.(elapsed)

    // v1.2.9 #F3 / #F5：回放模式下每帧决定 timeScale。
    // - 用户拖动进度条（seek）时冻结物理（timeScale=0）；
    // - 否则由 Replay 控制器回调给出本杆的动态倍速（常速 → 最后碰撞/进袋后倍速）；
    // - 非回放时保持 timeScale 原值（实时对局恒为 1）。
    if (this.replayMode) {
      if (this.replayPaused) {
        this.timeScale = 0
      } else if (this.replayTimeScaleHook) {
        this.timeScale = this.replayTimeScaleHook()
      } else {
        this.timeScale = 1
      }
    }

    const steps = Math.floor((elapsed * this.timeScale) / this.step)
    const computedElapsed = steps * this.step
    const stateBefore = this.table.allStationary()
    for (let i = 0; i < steps; i++) {
      this.table.advance(this.step)
    }
    this.table.updateBallMesh(computedElapsed)
    this.view.update(computedElapsed, this.table.cue.aim)
    // v1.2.2：刷新积分牌下方的「已进球」整颗球（仅在落袋集合变化时重建 DOM）
    this.hud.updatePocketedBalls(this.table)
    this.table.cue.update(computedElapsed)
    this.particles.update(computedElapsed)
    if (!stateBefore && this.table.allStationary()) {
      this.eventQueue.push(new StationaryEvent())
      this.table.cue.hittingAnimation = false
    }
    // v1.3.20：每帧把监听者同步到相机，实现 3D 空间音频随视角变化
    this.sound.updateListener(this.view.camera?.camera)
    this.sound.processOutcomes(this.table.outcome)

    // v1.2.9 #F5：回放每帧刷新进度条 UI（仅回放模式、由 Replay 控制器提供回调）
    if (this.replayMode) {
      this.replayFrameHook?.()
    }
  }

  processEvents() {
    if (this.keyboard) {
      const inputs = this.keyboard.getEvents()
      inputs.forEach((i) => this.inputQueue.push(i))
    }

    while (this.inputQueue.length > 0) {
      this.lastEventTime = this.last
      const input = this.inputQueue.shift()
      input && this.updateController(this.controller.handleInput(input))
    }

    // only process events when stationary
    if (this.table.allStationary()) {
      const event = this.eventQueue.shift()
      if (event) {
        this.lastEventTime = performance.now()
        // v1.5.4（#70）：eventQueue 里的事件来自网络/本地 Bot 中继（对手侧），
        // 标记为 remote（回放归属=AI/对手）。本地玩家的 HIT 不走这条队列，
        // 而是经 sendEvent 直发，两者正好构成回放进度条分色的依据。
        this.recorder.record(event, "remote")
        this.updateController(event.applyToController(this.controller))
      }
    }
  }

  /** v1.4.8：teardown 后为 true，用于停止渲染循环（见 animate）。 */
  private tornDown = false

  lastEventTime = performance.now()

  animate(timestamp): void {
    // v1.4.8：teardown 后不再调度下一帧 —— 退出主菜单时必须停掉渲染循环，
    // 否则页面若被 bfcache 保留，rAF 仍会持续唤醒并占用主线程（真机表现为
    // 「退出后卡几秒」）。
    if (this.tornDown) return
    // 关键：先调度下一帧，再执行业务。否则一旦本帧 render()/物理/相机更新
    // 抛出未捕获异常，requestAnimationFrame 就不会再被调用，动画循环永久死亡，
    // 画面冻结为黑屏。先调度可保证任何单帧异常都不会中断渲染循环。
    requestAnimationFrame((t) => {
      this.animate(t)
    })

    try {
      const dt = (timestamp - this.last) / 1000
      this.advance(dt)
      this.last = timestamp
      this.processEvents()
      const needsRender =
        timestamp < this.lastEventTime + 60000 ||
        !this.table.allStationary() ||
        this.view.sizeChanged()
      if (needsRender) {
        this.view.render()
      }
      // 电脑对战每回合倒计时（仅 vs 电脑 + 配置了 timer 时生效）
      if (this.turnTimer.enabled()) {
        const r = this.turnTimer.tick(dt)
        if (r.justExpired) {
          this.notification.show(
            {
              type: "Info",
              title: "本回合超时",
              subtext: "系统判本局负",
              duration: 2200,
            },
            0,
            {}
          )
          this.eventQueue.push(new ConcedeEvent())
        }
      }
    } catch (e) {
      // 单帧异常不应中断循环（否则会表现为「永久黑屏」）。
      // 错误仅打印到 console（v1.1.28 已移除诊断浮层）。
      const msg = e instanceof Error ? e.message : String(e)
      console.error("animate loop error:", msg, e)
    }
  }

  updateLastShot() {
    const snapshot = ExportUtils.captureSnapshot(this.table)
    this.lastShotInit = snapshot.init
    this.lastShotData = snapshot.shot
  }

  /**
   * v1.4.6 引入、v1.4.9 收敛：游戏卸载（返回主菜单 / 关闭页面）时的统一清理。
   * 只做**零成本**的纯 JS 清理（停渲染循环 + 关 AudioContext）；
   * WebGL 资源一律交给浏览器随导航回收 —— 真机实测手动 dispose 会同步阻塞
   * 主线程约 3.5 秒（GPU 驱动删纹理），根因与数据见方法内注释。
   */
  teardown() {
    // v1.4.9：teardown 收敛为**纯 JS 轻量清理**，绝不做任何 WebGL 释放。
    //
    // 血泪教训（真机录屏逐帧分析，两次退出都精确冻结 3.5s）：
    //   v1.4.7 加了 renderer.dispose()、v1.4.8 又加了场景 geometry/material/
    //   texture 递归释放 —— 在 headless（swiftshader 软件渲染）下这些删除是
    //   空操作（实测 1~6ms），但**真机 GPU 驱动同步删除几十张 1024² 运行时
    //   纹理需要约 3.5 秒**，且阻塞主线程 —— 用户点「返回主菜单」后画面
    //   冻住 3.5 秒才跳转，「严重影响游戏体验」。
    //
    // 为什么可以不做：退出走 location.replace() 整页导航（v1.4.8 已改），
    // 浏览器随后会回收整个文档 —— 包括 WebGL context 与其全部 GPU 资源。
    // 手动 dispose 与浏览器回收做的是同一件事，只会把回收成本从「导航的
    // 后台阶段」提前到「点击响应路径」上，让用户白白多等 3.5 秒。
    // 累积问题由 replace 防住（旧文档可被回收），而不是靠手动释放。
    //
    // 这里只保留两件**零成本**且有益的事：
    //   1. tornDown = true 停掉渲染循环（页面被保留时 rAF 不再唤醒主线程）；
    //   2. 关闭 AudioContext（纯 JS 层操作，无 GPU 参与）。
    this.tornDown = true
    try {
      const actx = (this.sound as any)?.actx
      if (actx && typeof actx.close === "function" && actx.state !== "closed") {
        actx.close()
      }
    } catch (e) {}
  }

  updateController(controller: Controller) {
    this.wasReplay = this.wasReplay || controller instanceof Replay
    if (controller !== this.controller) {
      // a     const playerName = Session.getInstance().playername
      // b     this.log(`${playerName}: Transition to ${controller.name}`)
      this.controller = controller
      const active = this.inferActivePlayer(controller)
      if (
        active !== 0 ||
        controller instanceof Init ||
        controller instanceof End
      ) {
        this.setHudActivePlayer(active)
      }
      // 离线版：分享/图解/分析都依赖外部网站，一律隐藏
      this.menu?.setShareVisible(false)
      this.menu?.setDiagramVisible(false)
      this.menu?.setAnalysisVisible(false)
      // 人机对战时允许认输，练习和回放模式不需要
      this.menu?.setConcedeVisible(Session.isBotMode() && !this.replayMode)
      // 离线版没有聊天对象
      this.comment?.setVisible(false)

      this.controller.onFirst()

      // 电脑对战每回合倒计时：根据 controller 启停
      this.applyTurnTimerForController(controller)
    }
  }

  /**
   * 当 controller 是「玩家在打」的阶段时启动倒计时，其它阶段停止。
   * 玩家回合包括 Aim（瞄准 / 击球）与 PlaceBall（自由球摆位）。
   */
  private applyTurnTimerForController(controller: Controller) {
    if (!this.turnTimer.enabled()) {
      this.turnTimer.stop()
      this.wasPlayerTurn = false
      return
    }
    const isPlayerTurn =
      controller instanceof Aim ||
      controller instanceof PlaceBall ||
      (controller as any).constructor?.name === "Aim"
    if (isPlayerTurn && !this.wasPlayerTurn) {
      this.turnTimer.start()
      this.wasPlayerTurn = true
    } else if (!isPlayerTurn && this.wasPlayerTurn) {
      this.turnTimer.stop()
      this.wasPlayerTurn = false
    }
  }
}
