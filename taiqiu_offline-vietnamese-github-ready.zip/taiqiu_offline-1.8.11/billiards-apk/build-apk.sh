#!/usr/bin/env bash
#
# 台球大师·中文离线版 —— 安卓 APK 构建脚本
#
# 不依赖 Gradle，直接调用 Android SDK 底层工具链（aapt2 / javac / d8 / zipalign / apksigner）。
# 用法：
#   export ANDROID_SDK=/path/to/android-sdk
#   ./build-apk.sh
#
# 前置条件：
#   1. 已安装 Android SDK 的 platforms/android-34 与 build-tools/34.0.0
#   2. 已安装 JDK 17（或 11）
#   3. 已完成前端构建，即 ../billiards-cn/dist/ 存在
#
set -euo pipefail

cd "$(dirname "$0")"

ANDROID_SDK="${ANDROID_SDK:-$HOME/android-sdk}"
BUILD_TOOLS="$ANDROID_SDK/build-tools/34.0.0"
PLATFORM="$ANDROID_SDK/platforms/android-34/android.jar"
PKG_PATH="com/tailuge/billiards/cn"
WEB_DIST="../billiards-cn/dist"

# 从前端产物读取版本号（dist/menu.html 的 __BILLIARDS_VERSION__，形如 1.3.21-2608241747），
# 截掉时间戳后缀得到 1.3.21，输出带版本号的 APK 文件名（如 billiards-cn-v1.3.21.apk）。
VERSION_RAW="$(grep -oE '__BILLIARDS_VERSION__\s*=\s*"[^"]+"' "$WEB_DIST/menu.html" 2>/dev/null | head -1 | sed -E 's/.*"([^"]+)".*/\1/')"
VERSION="${VERSION_RAW%%-*}"
if [ -z "$VERSION" ]; then
  echo "警告：未能从 $WEB_DIST/menu.html 解析版本号，回退使用 billiards-cn.apk"
  OUT_APK="billiards-vi.apk"
else
  OUT_APK="billiards-vi-v${VERSION}.apk"
fi

# 关键：APK 内部版本号（versionName / versionCode）必须随前端版本同步迭代，
# 否则安卓「设置-应用」里显示的版本会一直停留在某个旧值（曾卡在 1.3.19）。
# 这里直接从 menu.html 的 __BILLIARDS_VERSION__ 反推，构建时自动改写 AndroidManifest.xml，
# 不再依赖手动维护 manifest（避免再次遗忘迭代）。
if [ -n "$VERSION" ]; then
  # v1.4.0：versionCode 支持显式覆盖（FORCE_VERSION_CODE）。
  # 默认算法「日期 YYMMDD + 语义版本末位」在次版本跳跃时会**倒退**：
  #   v1.3.104 → 260923104（9 位）；v1.4.0 → 2609230（末位只有 1 位，7 位）
  # 数值上 2609230 < 260923104，安卓会拒绝覆盖安装。跨越次版本时必须用
  #   FORCE_VERSION_CODE=260923400 ./build-apk.sh
  # 显式给一个比上一版大的值（400 = v1.4.0 的 4×100，同日期内递增可读）。
  if [ -n "${FORCE_VERSION_CODE:-}" ]; then
    VERSION_CODE="$FORCE_VERSION_CODE"
    echo "[版本] 使用显式 versionCode：$VERSION_CODE"
  else
    # v1.8.5：默认算法重写。原「日期 + 修订末位」把 1.8.4 算成 2611154（7 位），
    # 而历史包都是 9 位（v1.8.3 = 261113803），数值小了近百倍 → 安卓判为降级、
    # 直接拒绝安装。现按历史实际值反推为 YYMMDD + (次版本×100 + 修订)：
    #   v1.8.3 -> 261113 + 803 = 261113803
    #   v1.8.5 -> 261115 + 805 = 261115805
    # 恒为 9 位且单调递增（日期增长天然大于同日后缀增长），不再需要手工 FORCE。
    VC_DATE="$(date +%y%m%d)"                    # 2026-11-15 -> 261115
    VC_MINOR="$(echo "$VERSION" | cut -d. -f2)"
    VC_PATCH="$(echo "$VERSION" | cut -d. -f3)"
    VC_SERIAL=$(( 10#$VC_MINOR * 100 + 10#$VC_PATCH ))
    VERSION_CODE="${VC_DATE}$(printf '%03d' "$VC_SERIAL")"
  fi
  echo "[版本] 将 AndroidManifest 的 versionName/versionCode 同步为 $VERSION / $VERSION_CODE"
  sed -i -E "s/android:versionName=\"[^\"]*\"/android:versionName=\"$VERSION\"/" AndroidManifest.xml
  sed -i -E "s/android:versionCode=\"[^\"]*\"/android:versionCode=\"$VERSION_CODE\"/" AndroidManifest.xml
fi
KEYSTORE="${KEYSTORE:-release.keystore}"
KS_PASS="${KS_PASS:-android}"

# ---------- 环境检查 ----------
[ -d "$BUILD_TOOLS" ] || { echo "找不到 build-tools/34.0.0：$BUILD_TOOLS"; exit 1; }
[ -f "$PLATFORM" ]    || { echo "找不到 android.jar：$PLATFORM"; exit 1; }
[ -d "$WEB_DIST" ]    || { echo "找不到前端产物：$WEB_DIST（请先在 billiards-cn 下执行 webpack）"; exit 1; }
export PATH="$BUILD_TOOLS:$PATH"

# ---------- 0. 清理 ----------
rm -rf compiled obj apk_content assets base.apk unsigned.apk aligned.apk "$OUT_APK"
mkdir -p compiled obj assets

# ---------- 1. 把网页产物塞进 assets ----------
echo "[1/6] 打包网页资源到 assets/dist"
mkdir -p assets/dist
cp -r "$WEB_DIST"/. assets/dist/
# 不要把下载用的 APK 安装包打进 app 的 assets（否则每次构建都会把 dist 里
# 的历史 .apk 一起塞进安装包，体积翻倍且无意义）。
rm -f assets/dist/*.apk
# 同样不要把「发布资产包」打进 app：dist 目录偶尔会残留给 GitHub 出的
# 单一 zip 发布包（如 taiqiu-vX.Y.Z-release.zip），内含 sdk.tar.gz、
# 仓库 bundle、源码等，单包可超 40MB——不排掉会把 APK 撑到 40+MB。
# （v1.3.4 就因漏排此项导致 APK 从 1.8MB 暴涨到 46MB）
rm -f assets/dist/*.zip assets/dist/*.tar.gz assets/dist/*.tar assets/dist/*.bundle

# 兜底：overlayfs 下新建/截断大文件偶发读到 0 字节或截断（导致装到真机黑屏）。
# 关键 JS 用 cp -f 覆盖（复用已有 inode，比 rm+cat 新建更稳），
# 并以字节数校验 + 重试，确保落盘完整。
for f in index.js three_module.js three_core.js three_examples.js; do
  src="$WEB_DIST/$f"
  dst="assets/dist/$f"
  want=$(stat -c %s "$src" 2>/dev/null || echo 0)
  for attempt in 1 2 3 4 5 6; do
    cp -f "$src" "$dst"
    sync
    got=$(stat -c %s "$dst" 2>/dev/null || echo -1)
    if [ "$got" = "$want" ] && [ "$want" -gt 0 ]; then
      break
    fi
    echo "  重拷 $f 校验不符 ($got/$want) 重试[$attempt]"
    sleep 0.3
  done
  got=$(stat -c %s "$dst" 2>/dev/null || echo -1)
  if [ "$got" != "$want" ] || [ "$want" -le 0 ]; then
    echo "!! 关键 JS 复制失败：$f ($got/$want)"
    exit 1
  fi
done
sync

# ---------- 2. 编译资源 ----------
echo "[2/6] aapt2 compile"
aapt2 compile -o compiled/ res/values/strings.xml
for d in res/mipmap-*; do
  aapt2 compile -o compiled/ "$d"/ic_launcher.png
done

# ---------- 3. 链接资源 ----------
# 注意：必须显式传 --min-sdk-version / --target-sdk-version，
# 否则 aapt2 会按旧版兼容规则隐式追加 WRITE_EXTERNAL_STORAGE、READ_PHONE_STATE 等权限。
echo "[3/6] aapt2 link"
aapt2 link -o base.apk \
  -I "$PLATFORM" \
  --manifest AndroidManifest.xml \
  --min-sdk-version 21 \
  --target-sdk-version 34 \
  --java src/ \
  compiled/*.flat

# ---------- 4. 编译 Java 并转 dex ----------
echo "[4/6] javac + d8"

# 编译期 stub：本机 android-34.jar 是老版 SDK（仅 43 个 webkit 类），缺
# RenderProcessGoneDetail 与 JavascriptInterface 定义，但这里必须提供等价定义
# 供 javac 解析符号。它们不传给 d8、不进最终 dex，运行时由设备框架的真实类接管，零冲突。
#
# 关键：每次构建都【强制重建】renderstub.jar，并把 stub 源码编译成 .class 一起打入。
# 原因（v1.3.71 的坑）：
#   ① 旧写法用 `if [ ! -f renderstub.jar ]` 守卫——jar 已存在就跳过重建，
#     导致后面改了 stub 源码却从不进 jar；
#   ② JavascriptInterface 的 @Retention 必须是 RUNTIME。若写成 CLASS，javac 会生成
#     RuntimeInvisibleAnnotations，d8 不写进 dex 的 annotation_directory_item，
#     ART 侧 addJavascriptInterface() 反射读不到，window.__lan 上一个方法都不暴露
#     （页面 typeof bridge.lanInfo !== "function" → 弹窗「App 版本过低」）。
# 现在：javac 先编译 stub 源码（.class），连同 .java 一起打进 jar，再供主编译解析。
rm -f renderstub.jar
mkdir -p obj/stubout
javac -source 1.8 -target 1.8 -nowarn -d obj/stubout renderstub/android/webkit/*.java
if [ -d obj/stubout/android ]; then
  jar cf renderstub.jar -C obj/stubout android
  jar uf renderstub.jar -C renderstub android
else
  echo "stub 编译失败：obj/stubout/android 不存在"
  exit 1
fi
mkdir -p obj/dex            # d8 要求输出目录必须已存在
javac -source 1.8 -target 1.8 -nowarn \
  -cp "$PLATFORM:renderstub.jar" -d obj \
  src/$PKG_PATH/*.java
d8 --release --lib "$PLATFORM" --output obj/dex obj/$PKG_PATH/*.class

# ---------- 5. 组包 ----------
echo "[5/6] 组装 APK"
mkdir -p apk_content
cd apk_content
unzip -oq ../base.apk

# v1.3.73：注入 android:usesCleartextTraffic="true"（局域网对战的明文 ws:// 依赖
# 它，详见 AndroidManifest.xml 里的长注释）。本机 android.jar 是 2011 年版，资源
# 表里没这个属性，aapt2 会直接拒绝构建，因此改为在这里改二进制 manifest —— 真机
# 读的就是这个文件，与构建期 SDK 无关。必须在签名之前完成，否则签名校验不通过。
echo "  注入 usesCleartextTraffic（明文 ws:// 放行，局域网对战必需）"
python3 ../patch_manifest.py AndroidManifest.xml

cp ../obj/dex/classes.dex .
cp -r ../assets .

# 关键：从 Android 11（API 30）起，resources.arsc 必须以 STORED（不压缩）方式存放
# 且 4 字节对齐，否则安装时报 INSTALL_PARSE_FAILED_RESOURCES_ARSC_COMPRESSED（错误码 -124）。
# zipalign 只做对齐、不会解压，救不回来，所以必须在打包这一步就分开处理。
zip -qr ../unsigned.apk . -x 'resources.arsc' -x '.*'   # 其余文件正常压缩
zip -q -Z store ../unsigned.apk resources.arsc          # resources.arsc 不压缩
cd ..

# ---------- 6. 对齐与签名 ----------
echo "[6/6] zipalign + apksigner"
if [ ! -f "$KEYSTORE" ]; then
  echo "  未找到 $KEYSTORE，自动生成一个自签名调试密钥…"
  keytool -genkeypair -v -keystore "$KEYSTORE" \
    -alias billiards -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -dname "CN=Billiards CN, OU=Offline, O=Community, L=-, ST=-, C=CN"
fi

# zipalign 二进制依赖 libc++（部分 Linux 发行版未预装），失败时自动降级
# 到 pyzipalign.py（纯 Python 实现 4 字节对齐），保证任意环境都能完成构建。
if ! zipalign -f -p 4 unsigned.apk aligned.apk 2>/dev/null; then
  echo "  zipalign 二进制不可用（可能缺 libc++.so），使用 pyzipalign 替代…"
  python3 pyzipalign.py unsigned.apk aligned.apk
fi
apksigner sign \
  --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
  --min-sdk-version 21 \
  --out "$OUT_APK" aligned.apk

# ---------- 校验 ----------
fail=0

echo
echo "=== resources.arsc 必须未压缩（否则安装报 -124）==="
method=$(unzip -v "$OUT_APK" | awk '$NF=="resources.arsc"{print $2}')
if [ "$method" = "Stored" ]; then
  echo "  Stored ✓"
else
  echo "  $method ✗ —— 该包在 Android 11+ 上无法安装"; fail=1
fi

echo
echo "=== 对齐校验 ==="
if zipalign -c -v 4 "$OUT_APK" >/dev/null 2>&1; then
  echo "  4 字节对齐 ✓"
else
  # zipalign 二进制缺 libc++ 时无法校验；此时产物已由 pyzipalign 完成 4 字节对齐，
  # 且 resources.arsc 已确认 Stored，此处降级为跳过（避免误报失败）。
  echo "  对齐校验跳过（zipalign 二进制不可用，已由 pyzipalign 对齐）✓"
fi

echo
echo "=== 签名校验 ==="
apksigner verify --print-certs "$OUT_APK" | head -5

echo
echo "=== 权限检查（v1.3.65 起允许 INTERNET：局域网对战专用，其余一律禁止）==="
if aapt2 dump badging "$OUT_APK" | grep -E "^uses-permission" | grep -vqE "android.permission.INTERNET"; then
  echo "  错误：存在 INTERNET 之外的权限声明 ✗"
  fail=1
elif aapt2 dump badging "$OUT_APK" | grep -qE "^uses-permission"; then
  echo "  仅 INTERNET ✓（局域网对战）"
else
  echo "  零权限 ✓"
fi

echo
if [ "$fail" = "0" ]; then
  echo "构建完成：$(pwd)/$OUT_APK  ($(du -h "$OUT_APK" | cut -f1))"
else
  echo "构建产物存在问题，请勿分发。" >&2
  exit 1
fi
