# Bản Việt hoá – Bi-a Offline

Bản chỉnh sửa này đặt tiếng Việt làm ngôn ngữ mặc định/duy nhất trong giao diện đã Việt hoá. Dự án không dùng Gradle; APK được đóng gói trực tiếp bằng Android SDK build-tools.

## Tự động build APK bằng GitHub Actions

1. Đưa toàn bộ nội dung repo lên GitHub, giữ nguyên các thư mục `billiards-cn/`, `billiards-apk/` và `.github/workflows/`.
2. Mở tab **Actions** của repo.
3. Chọn workflow **Build Vietnamese APK** → **Run workflow**.
4. Khi job hoàn tất, mở phần **Artifacts** của lần chạy và tải `taiqiu-offline-vietnamese-apk`.

Workflow dùng Ubuntu 24.04, Node.js 22/npm, JDK 17, Python 3.12, Android SDK platform 34 và build-tools 34.0.0. Nó chạy `npm ci`, `npm run build`, sau đó `billiards-apk/build-apk.sh`; bước build APK đã có kiểm tra alignment, chữ ký và quyền Android.

Workflow chạy tự động khi push thay đổi liên quan lên nhánh `main` hoặc `master`, và cũng có thể chạy thủ công từ tab Actions.

## Build thủ công

Yêu cầu Node.js 22, npm, JDK 17, Python 3, Android SDK `platforms/android-34` và `build-tools/34.0.0`.

```bash
cd billiards-cn
npm ci
npm run build
cd ../billiards-apk
export ANDROID_SDK="$ANDROID_HOME"  # hoặc đường dẫn Android SDK của bạn
./build-apk.sh
```

APK được tạo trong `billiards-apk/`, tên bắt đầu bằng `billiards-vi-`.

## Lưu ý phát hành

- GitHub Actions tạo APK ký bằng khóa debug/tạm tự sinh để cài thử. Mỗi lần chạy có thể có chữ ký khác nhau; không dùng khóa này để phát hành cập nhật lâu dài.
- Muốn phát hành ổn định qua nhiều phiên bản, hãy lưu keystore riêng trong GitHub Secrets và cấu hình script dùng khóa đó. Không commit keystore hoặc mật khẩu vào repo.
- Build thành công không thay thế việc cài thử trên thiết bị Android để kiểm tra hiển thị tiếng Việt, dấu, bố cục và các chế độ chơi.
- Dự án gốc dùng giấy phép GPL-3.0; giữ lại giấy phép và thông tin bản quyền khi phân phối bản sửa đổi.
